<?php
defined('TYPO3_MODE') or die();

/** Add "title & alternative" field in Build-Element  **/
$columns = [
    'title' => [
        'l10n_mode' => 'prefixLangTitle',
        'exclude' => true,
        'label' => 'LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:sys_file_reference.title',
        'config' => [
            'type' => 'input',
            'size' => 20,
            'max' => 255,
            'eval' => 'null,Tbs\\TbsArticlesystem\\Evaluation\\TitleEvaluation',
            'placeholder' => '__row|uid_local|metadata|title',
            'mode' => 'useOrOverridePlaceholder',
            'default' => null,
        ]
    ],
    'alternative' => [
        'l10n_mode' => 'prefixLangTitle',
        'exclude' => true,
        'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.alternative',
        'config' => [
            'type' => 'input',
            'size' => 20,
            'max' => 255,
            'eval' => 'null,Tbs\\TbsArticlesystem\\Evaluation\\AlternativeEvaluation',
            'placeholder' => '__row|uid_local|metadata|alternative',
            'mode' => 'useOrOverridePlaceholder',
            'default' => null,
        ]
    ],

];

TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns('sys_file_reference',$columns,1);
//TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addFieldsToPalette('sys_file_reference', 'imageoverlayPalette','--linebreak--,title','after:description');



