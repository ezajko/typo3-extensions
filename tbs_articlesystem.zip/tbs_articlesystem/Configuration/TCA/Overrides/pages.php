<?php
defined('TYPO3_MODE') || die();

call_user_func(function (){

    $extKey = 'tbs_articlesystem';

    /**
     * Default PageTS for Tbs Article System
     */
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::registerPageTSConfigFile(
        $extKey,
        'Configuration/TsConfig/Page/All.tsconfig',
        'Tbs Article System'
    );
});

call_user_func(function($extKey, $table) {
    $langFile = 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf';

    $pidHashtags = 54;

    // set all Doktypes to add
    $doktypes = array(
        array( // Standard Article
            $langFile . ':backend_layout.standard.article',
            150,
            'EXT:tbs_articlesystem/Resources/Public/Icons/Article/bkk__icon_standardartikel.svg',
        ),
        array( // SEO Article
            $langFile . ':backend_layout.seo.article',
            153,
            'EXT:tbs_articlesystem/Resources/Public/Icons/Article/bkk__icon_seo.svg',
        ),
        array( // Media Article
            $langFile . ':backend_layout.media.article',
            151,
            'EXT:tbs_articlesystem/Resources/Public/Icons/Article/bkk__icon_medienartikel.svg',
        ),
        array( // Magazine Article
            $langFile . ':backend_layout.magazine.article',
            152,
            'EXT:tbs_articlesystem/Resources/Public/Icons/Article/bkk__icon_bkk_magazin.svg',
        ),
        array( // PP Article
            $langFile . ':backend_layout.positionpaper.article',
            154,
            'EXT:tbs_articlesystem/Resources/Public/Icons/Article/bkk__icon_standardartikel.svg',
        ),
        array( // Lense Article
            $langFile . ':backend_layout.lense.article',
            155,
            'EXT:tbs_articlesystem/Resources/Public/Icons/Article/bkk__icon_standardartikel.svg',
        ),
        array( // Statistic Article
            $langFile . ':backend_layout.statistic.article',
            156,
            'EXT:tbs_articlesystem/Resources/Public/Icons/Article/bkk__icon_statistik.svg',
        ),
    );
    foreach ($doktypes as $key => $doktype) {
        // Add new page type as possible select item:
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTcaSelectItem(
            $table,
            'doktype',
            [
                $doktype[0],
                $doktype[1],
                $doktype[2],
            ],
            '1',
            'after'
        );

        // Add icon for new page type:
        \TYPO3\CMS\Core\Utility\ArrayUtility::mergeRecursiveWithOverrule(
            $GLOBALS['TCA']['pages'],
            [
                'ctrl' => [
                    // add standard icon and 'hide in menu' (nav_hide) icon
                    'typeicon_classes' => [
                        $doktype[1] => 'apps-pagetree-' . $doktype[1],
                        (string) $doktype[1] . '-hideinmenu' => 'apps-pagetree-' . $doktype[1] . '-hideinmenu',
                    ],
                ],
            ]
        );

        // Configure TCA for new doktype
        $GLOBALS['TCA']['pages']['types'][$doktype[1]] = ['showitem' => ''];
    }

    /*
     * add new fields to doktypes
     */
    // TCA Configuration for images
    $imageConfig = [
        'appearance' => [
            'createNewRelationLinkTitle' =>
                'LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:images.addFileReference',
            'collapseAll' => 0,
            'expandSingle' => 1,
            'useSortable' => false,
            'enabledControls' => [
                'dragdrop' => false,
                'sort' => false,
                'hide' => false,
                'info' => true,
                'delete' => true,
                'localize' => false,
            ],
        ],
        'overrideChildTca' => [
            'types' => [
                \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                    'showitem' => ' --palette--;LLL:EXT:lang/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;basicoverlayPalette,--linebreak--,alternative,
                                    --palette--;;filePalette',
                ],
            ],
        ],
        'maxitems' => 1,
        'minitems' => 1,
    ];

    // allowed filetypes
    $allowedImages = 'jpg,jpeg,png';

    // allowed filetypes Position papier
    $imageAllowedFileExtensions = 'gif,jpg,jpeg,bmp,png,svg';


    /*
    * add new fields to TCA Columns
    */
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns(
        'pages',
        [
            'tx_tbs_articlesystem_roof_line' => [
                'label' => $langFile . ':pages.doktypes.roof.line',
                'config' => [
                    'type' => 'input',
                    'size' => 30,
                    'eval' => 'trim'
                ],
            ],
            'tx_tbs_articlesystem_sub_headline' => [
                'label' => $langFile . ':pages.doktypes.sub.headline',
                'config' => [
                    'type' => 'input',
                    'size' => 30,
                    'eval' => 'trim'
                ],
            ],
            'tx_tbs_articlesystem_lead_text' => [
                'label' => $langFile . ':pages.doktypes.lead.text',
                'config' => [
                    'type' => 'text',
                    'cols' => '40',
                    'rows' => '5',
                    'eval' => 'required',
                ],
            ],
            'tx_tbs_articlesystem_teaser_text' => [
                'label' => $langFile . ':pages.doktypes.teaser.text',
                'config' => [
                    'type' => 'text',
                    'cols' => '40',
                    'rows' => '5',
                    'eval' => '',
                ],
            ],
            'tx_tbs_articlesystem_teaser_image' => [
                'label' => $langFile . ':pages.doktypes.teaser.image',
                'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
                    'tx_tbs_articlesystem_teaser_image',
                    $imageConfig,
                    $allowedImages
                ),
            ],
            'tx_tbs_articlesystem_date' => [
                'exclude' => true,
                'label' =>  $langFile . ':pages.doktypes.date',
                'config' => [
                    'type' => 'input',
                    'renderType' => 'inputDateTime',
                    'size' => 10,
                    'eval' => 'date,required',
                    'default' => time()
                ],
            ],
            'tx_tbs_articlesystem_is_revision' => [
                'exclude' => true,
                'label' => $langFile . ':pages.doktypes.is_revision',
                'config' => [
                    'type' => 'check',
                    'items' => [
                        '1' => [
                            '0' => 'LLL:EXT:lang/Resources/Private/Language/locallang_core.xlf:labels.enabled'
                        ]
                    ],
                    'default' => 0,
                ]

            ],
            'tx_tbs_articlesystem_is_rss' => [
                'exclude' => true,
                'label' => $langFile . ':pages.doktypes.is_rss ',
                'config' => [
                    'type' => 'check',
                    'items' => [
                        '1' => [
                            '0' => 'LLL:EXT:lang/Resources/Private/Language/locallang_core.xlf:labels.enabled'
                        ]
                    ],
                    'default' => 0,
                ]

            ],
            'tx_tbs_articlesystem_download' => [
                'exclude' => 1,
                'label' => $langFile . ':pages.doktypes.download',
                'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
                    'tx_tbs_articlesystem_download',
                    [
                        'minitems' => 0,
                        'maxitems' => 9999,
                        'appearance' => [
                            'createNewRelationLinkTitle' =>
                                $langFile . ':pages.doktypes.download.add',
                        ],
                        'foreign_match_fields' => [
                            'fieldname' => 'tx_tbs_articlesystem_download',
                            'tablenames' => 'pages',
                            'table_local' => 'sys_file',
                        ],

                    ],
                    'pdf'
                ),
            ],
            'tx_tbs_articlesystem_download_record' => [
                'exclude' => 1,
                'label' => $langFile . ':pages.doktypes.download',
                'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
                    'tx_tbs_articlesystem_download_record',
                    [
                        'minitems' => 1,
                        'maxitems' => 9999,
                        'appearance' => [
                            'createNewRelationLinkTitle' =>
                                $langFile . ':pages.doktypes.download.add',
                        ],
                        'foreign_match_fields' => [
                            'fieldname' => 'tx_tbs_articlesystem_download_record',
                            'tablenames' => 'pages',
                            'table_local' => 'sys_file',
                        ],

                    ],
                    'pdf'
                ),
            ],
            'tx_tbs_articlesystem_keywords' => [
                'exclude' => true,
                'label' => $langFile . ':pages.doktypes.keywords',
                'config' => [
                    'type' => 'select',
                    'renderType' => 'selectTree',
                    'treeConfig' => [
                        'parentField' => 'parent',
                        'appearance' => [
                            'showHeader' => true,
                            'expandAll' => true,
                            'maxLevels' => 99,
                        ],
                    ],
                    'MM' => 'sys_category_record_mm',
                    'MM_match_fields' => [
                        'fieldname' => 'tx_tbs_articlesystem_keywords',
                        'tablenames' => 'pages',
                    ],
                    'MM_opposite_field' => 'items',
                    'foreign_table' => 'sys_category',
                    'foreign_table_where' => ' AND pid = ' . $pidHashtags . ' AND hidden = 0 AND (sys_category.sys_language_uid = 0 OR sys_category.l10n_parent = 0) ORDER BY sys_category.sorting',
                    'size' => 10,
                    'minitems' => 0,
                    'maxitems' => 99,
                    'behaviour' => [
                        'allowLanguageSynchronization' => true,
                    ],
                ]
            ],
            //---- Only One Data
            'tx_tbs_articlesystem_media_data' => [
                'label' => $langFile . ':media.data.items',
                'l10n_mode' => 'mergeIfNotBlank',
                'exclude' => true,
                'config' => [
                    'type' => 'inline',
                    'allowed' => 'tx_tbs_articlesystem_media_data',
                    'foreign_table' => 'tx_tbs_articlesystem_media_data',
                    'foreign_sortby' => 'sorting',
                    'foreign_field' => 'parent',
                    'minitems' => 1,
                ],

            ],
            // magazine newsletter footer Image
            'tx_tbs_articlesystem_magazine_teaser_image' => [
                'label' => $langFile . ':pages.doktypes.magazine.teaser.image',
                'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
                    'tx_tbs_articlesystem_magazine_teaser_image',
                    $imageConfig,
                    $allowedImages
                ),
            ],
            'tx_tbs_articlesystem_images' => [
                'exclude' => true,
                'label' => 'LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:tx_tbsarticlesystem_domain_model_positionpaper.tabs.images',
                'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig('tx_tbs_articlesystem_images', [
                    'overrideChildTca' => [
                        'types' => [
                            \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                                'showitem' => 'LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette;--linebreak--,title,alternative,description,after:description,
                             --palette--;;filePalette'
                            ],
                        ],
                    ],
                    'minitems' => 0,
                    'maxitems' => 99999,
                ],$imageAllowedFileExtensions),
            ],
            'tx_tbs_articlesystem_statistic' => [
                'exclude' => true,
                'l10n_mode' => 'mergeIfNotBlank',
                'label' =>
                    $langFile . ':pages.tab.article.statistic',
                'config' => [
                    'type' => 'select',
                    'renderType' => 'selectMultipleSideBySide',
                    'foreign_table' => 'tx_charts_domain_model_chartdata',
                    'foreign_table_where' => 'AND tx_charts_domain_model_chartdata.sys_language_uid IN (-1,0)',
                    'default' => 0,
                    'maxitems' => 1
                ],
            ],
        ]
    );


    // Page Configuration for Standard Doktype
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
        'pages',
        '--palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.standard;standard,
         --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.layout;layout,
    tx_tbs_articlesystem_roof_line,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.title;title,
    tx_tbs_articlesystem_sub_headline,
    tx_tbs_articlesystem_teaser_text,
    tx_tbs_articlesystem_teaser_image,
    tx_tbs_articlesystem_lead_text,
    tx_tbs_articlesystem_date,
    starttime;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.doktypes.start_date, 
    endtime;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.doktypes.end_date,
    tx_tbs_articlesystem_is_revision,
    tx_tbs_articlesystem_is_rss,
    --div--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.tabs.downloads,
    tx_tbs_articlesystem_download,
     --div--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.tabs.keywords,
    tx_tbs_articlesystem_keywords,
    --div--;LLL:EXT:seo/Resources/Private/Language/locallang_tca.xlf:pages.tabs.seo, --palette--;;seo, --palette--;;robots, --palette--;;canonical, --palette--;;sitemap, 
    --div--;LLL:EXT:seo/Resources/Private/Language/locallang_tca.xlf:pages.tabs.socialmedia,
        --palette--;;opengraph,
        --palette--;;twittercards, 
    --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.tabs.access,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.visibility;visibility,
    --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.tabs.behaviour,
     --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.links;links,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.caching;caching,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.language;language,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.module;module,
    --palette--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.palettes.tracking;tracking,
    --div--;LLL:EXT:ke_search/Resources/Private/Language/locallang_db.xml:pages.tx_kesearch_label, no_search;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.no_search_formlabel',
        '150,153'
    );


    // Page Configuration for Standard Doktype
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
        'pages',
        '--palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.standard;standard,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.layout;layout,
    tx_tbs_articlesystem_roof_line,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.title;title,
    tx_tbs_articlesystem_sub_headline,
    tx_tbs_articlesystem_teaser_text,
    tx_tbs_articlesystem_teaser_image,
    tx_tbs_articlesystem_lead_text,
    tx_tbs_articlesystem_date,
    starttime;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.doktypes.start_date, 
    endtime;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.doktypes.end_date,
    tx_tbs_articlesystem_is_revision,
    tx_tbs_articlesystem_is_rss,
    --div--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.tab.article.media,
    tx_tbs_articlesystem_media_data,
     --div--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.tabs.keywords,
    tx_tbs_articlesystem_keywords,
    --div--;LLL:EXT:seo/Resources/Private/Language/locallang_tca.xlf:pages.tabs.seo, --palette--;;seo, --palette--;;robots, --palette--;;canonical, --palette--;;sitemap, 
    --div--;LLL:EXT:seo/Resources/Private/Language/locallang_tca.xlf:pages.tabs.socialmedia,
        --palette--;;opengraph,
        --palette--;;twittercards, 
    --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.tabs.access,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.visibility;visibility,
    --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.tabs.behaviour,
     --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.links;links,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.caching;caching,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.language;language,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.module;module,
    --palette--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.palettes.tracking;tracking,
    --div--;LLL:EXT:ke_search/Resources/Private/Language/locallang_db.xml:pages.tx_kesearch_label, no_search;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.no_search_formlabel',
        '151'
    );

    // Page Configuration for Magazine Doktype
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
        'pages',
        '--palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.standard;standard,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.layout;layout,
    tx_tbs_articlesystem_roof_line,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.title;title,
    tx_tbs_articlesystem_sub_headline,
    tx_tbs_articlesystem_teaser_text,
    tx_tbs_articlesystem_teaser_image,
    tx_tbs_articlesystem_lead_text,
    tx_tbs_articlesystem_date,
    starttime;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.doktypes.start_date, 
    endtime;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.doktypes.end_date,
    tx_tbs_articlesystem_is_revision,
    tx_tbs_articlesystem_is_rss,
    tx_tbs_articlesystem_magazine_teaser_image,
    --div--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.tabs.downloads,
    tx_tbs_articlesystem_download,
     --div--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.tabs.keywords,
    tx_tbs_articlesystem_keywords,
    --div--;LLL:EXT:seo/Resources/Private/Language/locallang_tca.xlf:pages.tabs.seo, --palette--;;seo, --palette--;;robots, --palette--;;canonical, --palette--;;sitemap, 
    --div--;LLL:EXT:seo/Resources/Private/Language/locallang_tca.xlf:pages.tabs.socialmedia,
        --palette--;;opengraph,
        --palette--;;twittercards, 
    --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.tabs.access,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.visibility;visibility,
    --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.tabs.behaviour,
     --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.links;links,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.caching;caching,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.language;language,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.module;module,
    --palette--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.palettes.tracking;tracking,
    --div--;LLL:EXT:ke_search/Resources/Private/Language/locallang_db.xml:pages.tx_kesearch_label, no_search;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.no_search_formlabel',
        '152'
    );

    // Page Configuration for pp Doktype
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
        'pages',
        '--palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.standard;standard,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.layout;layout,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.title;title,
    tx_tbs_articlesystem_sub_headline,
    tx_tbs_articlesystem_teaser_text,
    tx_tbs_articlesystem_lead_text,
    tx_tbs_articlesystem_date,
    starttime;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.doktypes.start_date, 
    endtime;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.doktypes.end_date,
    tx_tbs_articlesystem_is_revision,
    tx_tbs_articlesystem_is_rss,
    --div--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:tx_tbsarticlesystem_domain_model_positionpaper.tabs.images,
    tx_tbs_articlesystem_images,
    --div--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.tabs.downloads,
    tx_tbs_articlesystem_download_record,
     --div--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.tabs.keywords,
    tx_tbs_articlesystem_keywords,
    --div--;LLL:EXT:seo/Resources/Private/Language/locallang_tca.xlf:pages.tabs.seo, --palette--;;seo, --palette--;;robots, --palette--;;canonical, --palette--;;sitemap,
    --div--;LLL:EXT:seo/Resources/Private/Language/locallang_tca.xlf:pages.tabs.socialmedia,
        --palette--;;opengraph,
        --palette--;;twittercards, 
    --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.tabs.access,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.visibility;visibility,
    --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.tabs.behaviour,
     --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.links;links,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.caching;caching,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.language;language,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.module;module,
    --palette--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.palettes.tracking;tracking,
    --div--;LLL:EXT:ke_search/Resources/Private/Language/locallang_db.xml:pages.tx_kesearch_label, no_search;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.no_search_formlabel',
        '154,155'
    );

    // Page Configuration for Statistic Doktype
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes(
        'pages',
        '--palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.standard;standard,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.layout;layout,
    tx_tbs_articlesystem_roof_line,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.title;title,
    tx_tbs_articlesystem_sub_headline,
    tx_tbs_articlesystem_teaser_text,
    tx_tbs_articlesystem_teaser_image,
    tx_tbs_articlesystem_lead_text,
    tx_tbs_articlesystem_date,
    starttime;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.doktypes.start_date, 
    endtime;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.doktypes.end_date,
    tx_tbs_articlesystem_is_revision,
    tx_tbs_articlesystem_is_rss,
    --div--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.tab.article.statistic,
    tx_tbs_articlesystem_statistic,
     --div--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.tabs.keywords,
    tx_tbs_articlesystem_keywords,
    --div--;LLL:EXT:seo/Resources/Private/Language/locallang_tca.xlf:pages.tabs.seo, --palette--;;seo, --palette--;;robots, --palette--;;canonical, --palette--;;sitemap, 
    --div--;LLL:EXT:seo/Resources/Private/Language/locallang_tca.xlf:pages.tabs.socialmedia,
        --palette--;;opengraph,
        --palette--;;twittercards, 
    --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.tabs.access,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.visibility;visibility,
    --div--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.tabs.behaviour,
     --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.links;links,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.caching;caching,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.language;language,
    --palette--;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.palettes.module;module,
    --palette--;LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf:pages.palettes.tracking;tracking,
    --div--;LLL:EXT:ke_search/Resources/Private/Language/locallang_db.xml:pages.tx_kesearch_label, no_search;LLL:EXT:frontend/Resources/Private/Language/locallang_tca.xlf:pages.no_search_formlabel',
        '156'
    );

},'tbs_articlesystem','pages');
