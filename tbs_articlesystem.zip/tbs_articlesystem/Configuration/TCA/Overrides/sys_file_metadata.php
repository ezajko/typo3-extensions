<?php
defined('TYPO3_MODE') or die();

$tca = [

    'columns' => [
        'title' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:sys_file_reference.title',
            'config' => [
                'type' => 'text',
                'cols' => 20,
                'rows' => 1,
            ],
        ],
        'description' => [
            'exclude' => true,
            'label' => 'LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:sys_file_reference.description',
            'config' => [
                'type' => 'text',
                'cols' => 20,
                'rows' => 5,
            ],
        ],
    ],
];
$GLOBALS['TCA']['sys_file_metadata'] = array_replace_recursive($GLOBALS['TCA']['sys_file_metadata'], $tca);
