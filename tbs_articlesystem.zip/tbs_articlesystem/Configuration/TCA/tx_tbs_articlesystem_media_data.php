<?php
defined('TYPO3_MODE') or die();
$imageAllowedFileExtensions = 'gif,jpg,jpeg,bmp,png,svg';
$imageDisallowedFileExtensions = 'tif,tiff,pcx,pdf,ai';
$videoAllowedFileExtensions = 'youtube,vimeo,mp4';
$audioAllowedFileExtensions = 'mp3';

$ll = 'LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf';
return [
    'ctrl' => [
        'title' => $ll . 'media.data.items',
        'label' => 'tx_tbs_articlesystem_media_type',
        'tstamp' => 'tstamp',
        'crdate' => 'crdate',
        'cruser_id' => 'cruser_id',
        'languageField' => 'sys_language_uid',
        'transOrigPointerField' => 'l10n_parent',
        'transOrigDiffSourceField' => 'l10n_diffsource',
        'versioningWS' => true,
        'origUid' => 't3_origuid',
        'default_sortby' => 'ORDER BY sorting',
        'sortby' => 'sorting',
        'delete' => 'deleted',
        'iconfile' => 'EXT:tbs_articlesystem/Resources/Public/Icons/Relation/Extension.png',
        'enablecolumns' => [
            'disabled' => 'hidden',
        ],
        'hideTable' => true,
    ],
    'interface' => [
        'showRecordFieldList' => 'hidden'
    ],
    'columns' => [
        'pid' => [
            'label' => 'pid',
            'config' => [
                'type' => 'passthrough'
            ]
        ],
        'crdate' => [
            'label' => 'crdate',
            'config' => [
                'type' => 'passthrough',
            ]
        ],
        'tstamp' => [
            'label' => 'tstamp',
            'config' => [
                'type' => 'passthrough',
            ]
        ],
        'sys_language_uid' => [
            'exclude' => true,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.language',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'special' => 'languages',
                'items' => [
                    [
                        'LLL:EXT:lang/locallang_general.xlf:LGL.allLanguages',
                        -1,
                        'flags-multiple'
                    ],
                ],
                'default' => 0,
            ]
        ],
        'l10n_parent' => [
            'displayCond' => 'FIELD:sys_language_uid:>:0',
            'exclude' => true,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.l18n_parent',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    ['', 0],
                ],
                'foreign_table' => 'tx_tbs_articlesystem_media_data',
                'foreign_table_where' => 'AND tx_tbs_articlesystem_media_data.pid=###CURRENT_PID### AND tx_tbs_articlesystem_media_data.sys_language_uid IN (-1,0)',
                'default' => 0,
            ]
        ],
        'l10n_diffsource' => [
            'config' => [
                'type' => 'passthrough',
                'default' => ''
            ]
        ],
        'hidden' => [
            'exclude' => true,
            'label' => 'LLL:EXT:lang/locallang_general.xlf:LGL.hidden',
            'config' => [
                'type' => 'check',
                'default' => 0
            ]
        ],
        'tx_tbs_articlesystem_media_type' => [
            'label' => $ll . ':media.type',
            'description' => 'Publikationen (PDFs), Galleries (Fotoserien), Präsentationen (PPTs als Galleries), Videos, Podcasts, Fotos oder Grafiken',
            'onChange' => 'reload',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    ['Dokumente', '--div--'],
                    ['Publikation (PDF,PPT)', 1],
                    ['Media', '--div--'],
                    ['Gallery (Fotoserien)', 2],
                    ['Audio/Podcast', 3],
                    ['Video', 4],
                    ['Bilder', 5],
                ],
                'default' => 1,
            ],
        ],
        // --- Download Content ---
        'tx_tbs_articlesystem_media_download' => [
            'exclude' => true,
            'label' => $ll . ':pages.doktypes.download',
            'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig(
                'tx_tbs_articlesystem_media_download',
                [
                    'minitems' => 1,
                    'appearance' => [
                        'createNewRelationLinkTitle' =>
                            $ll . ':pages.download.add',
                    ],
                    'foreign_match_fields' => [
                        'fieldname' => 'tx_tbs_articlesystem_media_download',
                        'tablenames' => 'tx_tbs_articlesystem_media_data',
                        'table_local' => 'sys_file',
                    ],

                ],
                'pdf,ppt'
            ),
            'displayCond' => 'FIELD:tx_tbs_articlesystem_media_type:=:1',
        ],
        // --- Gallery Content ---
        'tx_tbs_articlesystem_media_gallery_image' =>[
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.images',
            'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig('tx_tbs_articlesystem_media_gallery_image', [
                'overrideChildTca' => [
                    'types' => [
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                            'showitem' => 'LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette;--linebreak--,title,alternative,description,crop,
                             --palette--;;filePalette'
                        ],
                    ],
                    'columns' => [
                        'crop' => [
                            'config' => [
                                'cropVariants' => [
                                    'galerie' => [
                                        'title' => 'Galerie',
                                        'allowedAspectRatios' => [
                                            '3:2' => [
                                                'title' => '3:2',
                                                'value' => 1.5
                                            ],
                                        ]
                                    ],
                                ],
                            ],
                        ],
                    ],
                ],
                'minitems' => 1,
            ],$imageAllowedFileExtensions,$imageDisallowedFileExtensions),
            'displayCond' => 'FIELD:tx_tbs_articlesystem_media_type:=:2',
        ],
        // --- Video Content ---
        'tx_tbs_articlesystem_media_video' =>[
            'label' => 'LLL:EXT:frontend/Resources/Private/Language/locallang_ttc.xlf:media',
            'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig('tx_tbs_articlesystem_media_video', [
                'overrideChildTca' => [
                    'types' => [
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_VIDEO => [
                            'showitem' => 'LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette;--linebreak--,
                             --palette--;;filePalette'
                        ],
                    ],
                ],
                'minitems' => 1,
                'maxitems' => 1,
            ],$videoAllowedFileExtensions),
            'displayCond' => 'FIELD:tx_tbs_articlesystem_media_type:=:4',
        ],
        'tx_tbs_articlesystem_media_video_poster' =>[
            'label' => 'LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_video.poster',
            'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig('tx_tbs_articlesystem_media_video_poster', [
                'overrideChildTca' => [
                    'types' => [
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                            'showitem' => 'LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette;--linebreak--,title,alternative,
                             --palette--;;filePalette'
                        ],
                    ],
                ],
            ],$imageAllowedFileExtensions,$imageDisallowedFileExtensions),
            'displayCond' => 'FIELD:tx_tbs_articlesystem_media_type:=:4',
        ],
        'tx_tbs_articlesystem_media_video_has_subtitle' =>[
            'label' => 'LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_video.video_has_subtitle',
            'exclude' => 1,
            'onChange' => 'reload',
            'config' => [
                'type' => 'check',
                'items' => [
                    '1' => [
                        '0' => 'LLL:EXT:lang/Resources/Private/Language/locallang_core.xlf:labels.enabled'
                    ]
                ],
                'default' => 0,
            ],
            'displayCond' => 'FIELD:tx_tbs_articlesystem_media_type:=:4',
        ],
        'tx_tbs_articlesystem_media_video_transcript' => [
            'label' => $ll . ':media.transcript',
            'config' => [
                'type' => 'text',
                'enableRichtext' => false,
                'cols' => 80,
                'rows' => 15,
                'eval' => 'required,trim',
            ],
           'displayCond' => [
                'AND' => [
                    'FIELD:tx_tbs_articlesystem_media_type:=:4',
                    'FIELD:tx_tbs_articlesystem_media_video_has_subtitle:=:0',
                ],
            ]
        ],
        // --- Images Content ---
        'tx_tbs_articlesystem_media_image' =>[
            'label' => 'LLL:EXT:core/Resources/Private/Language/locallang_general.xlf:LGL.images',
            'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig('tx_tbs_articlesystem_media_image', [
                'overrideChildTca' => [
                    'types' => [
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_IMAGE => [
                            'showitem' => 'LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette;--linebreak--,title,alternative,description,after:description,
                             --palette--;;filePalette'
                        ],
                    ],
                ],
                'minitems' => 1,
            ],$imageAllowedFileExtensions,$imageDisallowedFileExtensions),
            'displayCond' => 'FIELD:tx_tbs_articlesystem_media_type:=:5',
        ],
        // --- Audio Content ---
        'tx_tbs_articlesystem_media_audio_type' => array(
            'label' => 'Media',
            'exclude' => true,
            'onChange' => 'reload',
            'config' => [
                'type' => 'select',
                'renderType' => 'selectSingle',
                'items' => [
                    ['LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_audio.select.file', 1],
                    ['LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_audio.select.embeded', 2],
                ],
                'default' => 1,
            ],
            'displayCond' => 'FIELD:tx_tbs_articlesystem_media_type:=:3',
        ),
        'tx_tbs_articlesystem_media_audio' =>[
            'label' => 'LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_audio.audio',
            'config' => \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::getFileFieldTCAConfig('tx_tbs_articlesystem_media_audio', [
                'overrideChildTca' => [
                    'types' => [
                        \TYPO3\CMS\Core\Resource\File::FILETYPE_AUDIO => [
                            'showitem' => 'LLL:EXT:lang/Resources/Private/Language/locallang_tca.xlf:sys_file_reference.imageoverlayPalette;imageoverlayPalette;--linebreak--,title,
                             --palette--;;filePalette'
                        ],
                    ],
                ],
                'minitems' => 1,
                'maxitems' => 1,
            ],$audioAllowedFileExtensions),
            'displayCond' => [
                'AND' => [
                    'FIELD:tx_tbs_articlesystem_media_type:=:3',
                    'FIELD:tx_tbs_articlesystem_media_audio_type:=:1',
                ],
            ],
        ],
        'tx_tbs_articlesystem_media_audio_transcript' => [
            'label' => $ll . ':media.transcript',
            'config' => [
                'type' => 'text',
                'cols' => 40,
                'rows' => 30,
                'eval' => 'required,trim',
            ],
            'displayCond' => 'FIELD:tx_tbs_articlesystem_media_type:=:3',
        ],
        'tx_tbs_articlesystem_media_audio_embeded' => array(
            'label' => 'LLL:EXT:tbs_content_elements/Resources/Private/Language/locallang.xlf:tx_tbs_contentelements_audio.embeded',
            'config' => [
                'type' => 'text',
                'renderType' => 't3editor',
                'format' => 'html',
                'rows' => 7,
            ],
            'displayCond' => [
                'AND' => [
                    'FIELD:tx_tbs_articlesystem_media_audio_type:=:2',
                    'FIELD:tx_tbs_articlesystem_media_type:=:3',
                ],
            ],
        ),
    ],
    'types' => [
        0 => [
            'showitem' => 'tx_tbs_articlesystem_media_type,tx_tbs_articlesystem_media_download,tx_tbs_articlesystem_media_gallery_image,tx_tbs_articlesystem_media_video,
                           tx_tbs_articlesystem_media_video_poster,tx_tbs_articlesystem_media_video_has_subtitle,tx_tbs_articlesystem_media_video_transcript,tx_tbs_articlesystem_media_image,
                           tx_tbs_articlesystem_media_audio_type,tx_tbs_articlesystem_media_audio,tx_tbs_articlesystem_media_audio_embeded,tx_tbs_articlesystem_media_audio_transcript'
            ],
    ],
    'palettes' => [ ],
];
