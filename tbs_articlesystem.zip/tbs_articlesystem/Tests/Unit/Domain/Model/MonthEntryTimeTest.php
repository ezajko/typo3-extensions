<?php
namespace Tbs\TbsTimePlanning\Tests\Unit\Domain\Model;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class MonthEntryTimeTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = new \Tbs\TbsTimePlanning\Domain\Model\MonthEntryTime();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function getInfoTextReturnsInitialValueForString()
    {
        self::assertSame(
            '',
            $this->subject->getInfoText()
        );
    }

    /**
     * @test
     */
    public function setInfoTextForStringSetsInfoText()
    {
        $this->subject->setInfoText('Conceived at T3CON10');

        self::assertAttributeEquals(
            'Conceived at T3CON10',
            'infoText',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getStartDayReturnsInitialValueForDateTime()
    {
        self::assertEquals(
            null,
            $this->subject->getStartDay()
        );
    }

    /**
     * @test
     */
    public function setStartDayForDateTimeSetsStartDay()
    {
        $dateTimeFixture = new \DateTime();
        $this->subject->setStartDay($dateTimeFixture);

        self::assertAttributeEquals(
            $dateTimeFixture,
            'startDay',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getEndDayReturnsInitialValueForDateTime()
    {
        self::assertEquals(
            null,
            $this->subject->getEndDay()
        );
    }

    /**
     * @test
     */
    public function setEndDayForDateTimeSetsEndDay()
    {
        $dateTimeFixture = new \DateTime();
        $this->subject->setEndDay($dateTimeFixture);

        self::assertAttributeEquals(
            $dateTimeFixture,
            'endDay',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getOpenTimeStartReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getOpenTimeStart()
        );
    }

    /**
     * @test
     */
    public function setOpenTimeStartForIntSetsOpenTimeStart()
    {
        $this->subject->setOpenTimeStart(12);

        self::assertAttributeEquals(
            12,
            'openTimeStart',
            $this->subject
        );
    }

    /**
     * @test
     */
    public function getOpenTimeEndReturnsInitialValueForInt()
    {
        self::assertSame(
            0,
            $this->subject->getOpenTimeEnd()
        );
    }

    /**
     * @test
     */
    public function setOpenTimeEndForIntSetsOpenTimeEnd()
    {
        $this->subject->setOpenTimeEnd(12);

        self::assertAttributeEquals(
            12,
            'openTimeEnd',
            $this->subject
        );
    }
}
