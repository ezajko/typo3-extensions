<?php
namespace Tbs\TbsTimePlanning\Tests\Unit\Controller;

/**
 * Test case.
 *
 * @author Tarang Patel <info@brettingham.de>
 */
class OpeningTimeControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{
    /**
     * @var \Tbs\TbsTimePlanning\Controller\OpeningTimeController
     */
    protected $subject = null;

    protected function setUp()
    {
        parent::setUp();
        $this->subject = $this->getMockBuilder(\Tbs\TbsTimePlanning\Controller\OpeningTimeController::class)
            ->setMethods(['redirect', 'forward', 'addFlashMessage'])
            ->disableOriginalConstructor()
            ->getMock();
    }

    protected function tearDown()
    {
        parent::tearDown();
    }

    /**
     * @test
     */
    public function listActionFetchesAllOpeningTimesFromRepositoryAndAssignsThemToView()
    {

        $allOpeningTimes = $this->getMockBuilder(\TYPO3\CMS\Extbase\Persistence\ObjectStorage::class)
            ->disableOriginalConstructor()
            ->getMock();

        $openingTimeRepository = $this->getMockBuilder(\Tbs\TbsTimePlanning\Domain\Repository\OpeningTimeRepository::class)
            ->setMethods(['findAll'])
            ->disableOriginalConstructor()
            ->getMock();
        $openingTimeRepository->expects(self::once())->method('findAll')->will(self::returnValue($allOpeningTimes));
        $this->inject($this->subject, 'openingTimeRepository', $openingTimeRepository);

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $view->expects(self::once())->method('assign')->with('openingTimes', $allOpeningTimes);
        $this->inject($this->subject, 'view', $view);

        $this->subject->listAction();
    }

    /**
     * @test
     */
    public function showActionAssignsTheGivenOpeningTimeToView()
    {
        $openingTime = new \Tbs\TbsTimePlanning\Domain\Model\OpeningTime();

        $view = $this->getMockBuilder(\TYPO3\CMS\Extbase\Mvc\View\ViewInterface::class)->getMock();
        $this->inject($this->subject, 'view', $view);
        $view->expects(self::once())->method('assign')->with('openingTime', $openingTime);

        $this->subject->showAction($openingTime);
    }
}
