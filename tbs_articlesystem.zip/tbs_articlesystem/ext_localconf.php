<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Tbs.TbsArticlesystem',
            'Tbsdatarecordsystemcurrent',
            [
                'CurrentDataRecords' => 'latest,latestPageType',
            ],
            // non-cacheable actions
            [

            ]
        );

        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Tbs.TbsArticlesystem',
            'TbsRubricOverview',
            [
                'Rubric' => 'overview',
            ],
            // non-cacheable actions
            [

            ]
        );


        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Tbs.TbsArticlesystem',
            'TbsDashboardArticleFunctions',
            array(
                'ArticleDashboard' => 'dashboardArticleFunctions',
            ),
            // non-cacheable actions
            array(

            ),
            \TYPO3\CMS\Extbase\Utility\ExtensionUtility::PLUGIN_TYPE_PLUGIN
        );


        // wizards
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
            'mod {
            wizards.newContentElement.wizardItems.plugins {
                elements {    
                    tbsdatarecordsystemcurrent {
                        iconIdentifier = tbs_articlesystem-plugin-tbsdatarecordsystemcurrent
                        title = LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:tx_tbs_articlesystem_tbsdatarecordsystemcurrent.name
                        description = LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:tx_tbs_articlesystem_tbsdatarecordsystemcurrent.description
                        tt_content_defValues {
                            CType = list
                            list_type = tbsarticlesystem_tbsdatarecordsystemcurrent
                        }
                    }
                    TbsRubricOverview {
                        iconIdentifier = tbs_articlesystem-plugin-tbsrubricoverview
                        title = LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:tx_tbs_articlesystem_rubric_overview.name
                        description = LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:tx_tbs_articlesystem_rubric_overview.description
                        tt_content_defValues {
                            CType = list
                            list_type = tbsarticlesystem_tbsrubricoverview
                        }
                    }
                }
                show = *
            }
       }'
        );
        $iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);

        $iconRegistry->registerIcon(
            'tbs_articlesystem-plugin-tbsdatarecordsystemcurrent',
            \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
            ['source' => 'EXT:tbs_articlesystem/Resources/Public/Icons/Extension.svg']
        );
        $iconRegistry->registerIcon(
            'tbs_articlesystem-plugin-tbsrubricoverview',
            \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
            ['source' => 'EXT:tbs_articlesystem/Resources/Public/Icons/Extension.svg']
        );

    }
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig('<INCLUDE_TYPOSCRIPT: source="FILE:EXT:tbs_articlesystem/Configuration/TsConfig/Page/All.tsconfig">');

// Register the class to be available in 'eval' of TCA
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['tce']['formevals']['Tbs\\TbsArticlesystem\\Evaluation\\TitleEvaluation'] = '';
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['tce']['formevals']['Tbs\\TbsArticlesystem\\Evaluation\\AlternativeEvaluation'] = '';


// register SaveHook
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['t3lib/class.t3lib_tcemain.php']['processDatamapClass'][] = \Tbs\TbsArticlesystem\Hooks\SaveHook::class;
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['t3lib/class.t3lib_tcemain.php']['processCmdmapClass'][] = \Tbs\TbsArticlesystem\Hooks\SaveHook::class;


// Register for hook to show preview of tt_content element of CType="tbscontentelements_textcontent" in page module
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['cms/layout/class.tx_cms_layout.php']['tt_content_drawItem']['tbsarticlesystem_tbsdatarecordsystemlist'] =
    \Tbs\TbsArticlesystem\Hooks\PageLayoutView\NewContentElementPreviewRenderer::class;