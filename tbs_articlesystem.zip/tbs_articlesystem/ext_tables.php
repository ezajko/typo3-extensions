<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function($extKey)
    {

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('tbs_articlesystem', 'Configuration/TypoScript', 'TBS Article System');

        ## Articles list view frontend plugin
        ## this Plugin is not needed
        /**
         * @todo tbs_be check if we removed now is hidden bceause you can't add datarecord to any page outside the dashboard
         */
        /*
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Tbs.TbsArticlesystem',
            'Tbsdatarecordsystemlist',
            'LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:tx_tbs_articlesystem_tbsdatarecordsystemlist.name'
        );*/

        ## Articles detail view frontend plugin
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Tbs.TbsArticlesystem',
            'Tbsdatarecordsystemdetail',
            'LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:tx_tbs_articlesystem_tbsdatarecordsystemdetail.name'
        );

        ## Articles latest view frontend plugin
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Tbs.TbsArticlesystem',
            'Tbsdatarecordsystemcurrent',
            'LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:tx_tbs_articlesystem_tbsdatarecordsystemcurrent.name'
        );

        ## Child Article overview frontend plugin
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Tbs.TbsArticlesystem',
            'TbsRubricOverview',
            'LLL:EXT:tbs_articlesystem/Resources/Private/Language/locallang_db.xlf:tx_tbs_articlesystem_rubric_overview.name'
        );

        ## allow table on standard pages
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_tbs_articlesystem_media_data');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_tbsarticlesystem_domain_model_pressrelease');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_tbsarticlesystem_domain_model_statement');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_tbsarticlesystem_domain_model_positionpaper');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_tbsarticlesystem_domain_model_comment');
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::allowTableOnStandardPages('tx_tbsarticlesystem_domain_model_lense');

        ## Article types
        $langFile = 'LLL:EXT:' . $extKey . '/Resources/Private/Language/locallang_db.xlf';

        // set all Doktypes to add
        $doktypes = array(
            array( // Standard Article
                $langFile . ':backend_layout.standard.article',
                150,
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_standardartikel.svg', // default icon
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_standardartikel_grau.svg'  // Icon for option 'Hide in menu (nav_hide)'
            ),
            array( // SEO Article
                $langFile . ':backend_layout.seo.article',
                153,
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_seo.svg', // default icon
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_seo_grau.svg', // Icon for option 'Hide in menu (nav_hide)'
            ),
            array( // Media Article
                $langFile . ':backend_layout.media.article',
                151,
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_medienartikel.svg', // default icon
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_medienartikel_grau.svg', // Icon for option 'Hide in menu (nav_hide)'
            ),
            array( // Magazin Article
                $langFile . ':backend_layout.magazine.article',
                152,
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_bkk_magazin.svg', // default icon
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_bkk_magazin_grau.svg', // Icon for option 'Hide in menu (nav_hide)'
            ),
            array( // PP Article
                $langFile . ':backend_layout.positionpaper.article',
                154,
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_standardartikel.svg', // default icon
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_standardartikel_grau.svg'  // Icon for option 'Hide in menu (nav_hide)'
            ),
            array( // Unter der Lupe: KV45
                $langFile . ':backend_layout.lense.article',
                155,
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_standardartikel.svg', // default icon
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_standardartikel_grau.svg'  // Icon for option 'Hide in menu (nav_hide)'
            ),
            array( // Statistic Article
                $langFile . ':backend_layout.statistic.article',
                156,
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_statistik.svg', // default icon
                'EXT:' . $extKey . '/Resources/Public/Icons/Article/bkk__icon_statistik_grau.svg', // Icon for option 'Hide in menu (nav_hide)'
            ),
        );

        foreach (array_reverse($doktypes) as $key => $doktype) {
            // Add new page type:
            $GLOBALS['PAGES_TYPES'][$doktype[1]] = [
                'type' => 'web',
                'allowedTables' => '*',
            ];

            // Provide icon for page tree, list view, ... :
            \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class)
                ->registerIcon(
                    'apps-pagetree-' . $doktype[1],
                    TYPO3\CMS\Core\Imaging\IconProvider\BitmapIconProvider::class,
                    [
                        'source' => $doktype[2],
                    ]
                );

            // Provide icon for page tree, list view, ... : (Icon for option 'Hide in menu (nav_hide)')
            \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class)
                ->registerIcon(
                    'apps-pagetree-' . $doktype[1] . '-hideinmenu',
                    TYPO3\CMS\Core\Imaging\IconProvider\BitmapIconProvider::class,
                    [
                        'source' => $doktype[3],
                    ]
                );

            // Allow backend users to drag and drop the new page type:
            \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addUserTSConfig(
                'options.pageTree.doktypesToShowInNewPageDragArea := prependString(' . $doktype[1] . ',)'
            );
        }
    },
    'tbs_articlesystem'
);

// BE flexform for the data records system latest
$pluginSignature = 'tbsarticlesystem_tbsdatarecordsystemcurrent';
$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue(
    $pluginSignature,
    'FILE:EXT:tbs_articlesystem/Configuration/FlexForms/flexform_data_records_system_current.xml'
);

// BE flexform for Rubric overview
$pluginSignature = 'tbsarticlesystem_tbsrubricoverview';
$GLOBALS['TCA']['tt_content']['types']['list']['subtypes_addlist'][$pluginSignature] = 'pi_flexform';
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPiFlexFormValue(
    $pluginSignature,
    'FILE:EXT:tbs_articlesystem/Configuration/FlexForms/flexform_rubric_overview.xml'
);