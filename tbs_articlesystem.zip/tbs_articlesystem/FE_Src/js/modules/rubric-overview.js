/**
 * @module rubric-overview
 *
 * @author Uwe Kiefer
 */
const Helpers = require('../../../../tbs_provider/FE_Src/js/utils/helpers.js').default;


class RubricOverview {
    constructor($el, obj = {}) {
        this.$el = $el;
        this.options = obj;
    }

    initialize() {
        this.$teaser = this.$el.find('.rubric-overview__teaser');

        this.bindEvents();
        this.setInitialMinHeight();

        console.log('initialized module rubric-overview');
    }

    bindEvents() {
        $(window).on('resize', Helpers.debounce(this, this.onResize, 250));
    }

    setInitialMinHeight() {
        let counter = [];
        let loops = 0;
        const ival = setInterval(() => {
            this.$teaser.each((i, teaser) => {
                const $teaser = $(teaser);
                const $img = $teaser.find('.image img');
                const h = $img[0].naturalHeight;

                if (counter.indexOf(i) === -1 && h) {
                    $teaser.css('min-height', `${$teaser.find('.image').height()}px`);
                    counter.push(i);
                }

                if (counter.length >= this.$teaser.length || loops > 200) {
                    clearInterval(ival);
                }
            });
            loops += 1;
        }, 100);
    }

    onResize() {
        // set min height of each teaser
        this.$teaser.each((i, teaser) => {
            const $teaser = $(teaser);
            $teaser.css('min-height', `${$teaser.find('.image').height()}px`);
        });
    }
}

// Returns the constructor
export default RubricOverview;
