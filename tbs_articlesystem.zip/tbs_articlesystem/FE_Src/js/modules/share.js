/**
 * @module share
 *
 * @author Uwe Kiefer
 */

class Share {
    constructor($el, obj = {}) {
        this.$el = $el;
        this.options = obj;
    }

    initialize() {
        this.$app = $('#app');
        this.$button = this.$el.prev();

        if (window._isMobile) {
            this.$el.find('[data-href-mobile]').each((i, item) => {
                const $item = $(item);
                $item.attr('href', $item.attr('data-href-mobile'));
            });
        }

        this.bindEvents();

        console.log('initialized module share');
    }

    bindEvents() {
        this.$button.on('blur', () => {
            this.checkForClose();
        });

        this.$el.on('blur', 'a', () => {
            this.checkForClose();
        });

        $(window).on('scroll', () => {
            if (this.$button.attr('aria-expanded') === 'true' && !this.$el.isInViewport()) {
                this.$app.trigger('closeoverlay');
            }
        });
    }

    checkForClose() {
        if (this.$app.is('[data-open=share]')) {
            setTimeout(() => {
                if (!(this.$button.is(':focus') || this.$el.find(':focus').length)) {
                    this.$app.trigger('closeoverlay');
                }
            }, 10);
        }
    }
}

// Returns the constructor
export default Share;
