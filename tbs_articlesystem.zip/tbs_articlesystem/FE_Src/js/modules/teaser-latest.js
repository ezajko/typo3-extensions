/**
 * @module teaser-latest
 *
 * @author Uwe Kiefer
 */
const Helpers = require('../../../../tbs_provider/FE_Src/js/utils/helpers.js').default;


class TeaserLatest {
    constructor($el, obj = {}) {
        this.$el = $el;
        this.options = obj;
    }

    initialize() {
        this.$teaserItems = this.$el.find('.teaser-latest-article__item');
        this.$teaseSurlines = this.$el.find('.teaser-latest-article__surline');

        this.bindEvents();
        this.setInitialMinHeight();

        console.log('initialized module teaser-latest');
    }

    bindEvents() {
        $(window).on('resize', Helpers.debounce(this, this.onResize, 250));
    }

    setInitialMinHeight() {
        if (Helpers.isTablet()) {
            let counter = [];
            let loops = 0;
            const ival = setInterval(() => {
                this.$teaserItems.each((i, item) => {
                    const $item = $(item);
                    const $img = $item.find('img');
                    const h = $img[0].naturalHeight;

                    if (counter.indexOf(i) === -1 && h) {
                        $item.css('minHeight', `${$item.find('.image').height()}px`);
                        counter.push(i);
                    }

                    if (counter.length >= this.$teaser.length || loops > 200) {
                        clearInterval(ival);
                    }
                });
                loops += 1;
            }, 100);
        }

        this.onResize();
    }

    onResize() {
        if (Helpers.isTablet()) {
            // list view
            this.$teaseSurlines.css('borderTop', '0');

            // set teaser min-height
            this.$teaserItems.each((i, item) => {
                const $item = $(item);
                $item.css('minHeight', `${$item.find('.image').height()}px`);
            });
        } else {
            // column view
            let max = 0;

            // get max heigt
            this.$teaseSurlines.each((i, surline) => {
                const $surline = $(surline);
                max = Math.max(max, $surline.innerHeight());
            });

            // set border top of lower surlines
            this.$teaseSurlines.each((i, surline) => {
                const $surline = $(surline);
                const h = $surline.innerHeight();
                $surline.css('borderTop', `${Math.max(0, max - h)}px solid transparent`);
            });

            // remove teaser min-height
            this.$teaserItems.css('minHeight', '0');
        }
    }
}

// Returns the constructor
export default TeaserLatest;
