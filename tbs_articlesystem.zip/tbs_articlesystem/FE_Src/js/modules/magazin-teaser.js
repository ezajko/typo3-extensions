/**
 * @module magazin-teaser
 *
 * @author Uwe Kiefer
 */

class MagazinTeaser {
    constructor($el, obj = {}) {
        this.$el = $el;
        this.options = obj;
    }

    initialize() {
        const prefix = this.$el.attr('data-js-prefix');
        const $copyright = this.$el.find('.image__copyright');
        this.$el.parent().append('<div class="teaser-magazin__copyright"></div>');
        if (prefix) {
            $copyright
                .addClass('image__copyright--prefix')
                .prepend(`<span class="prefix">${prefix}</span> © `)
                .appendTo(this.$el.next());
        } else {
            $copyright.appendTo(this.$el.next());
        }

        console.log('initialized module magazin-teaser');
    }
}

// Returns the constructor
export default MagazinTeaser;
