<?php
namespace Tbs\TbsArticlesystem\Hooks\PageLayoutView;

/*
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

use Tbs\TbsProvider\Service\Image;
use \TYPO3\CMS\Backend\View\PageLayoutViewDrawItemHookInterface;
use \TYPO3\CMS\Backend\View\PageLayoutView;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;
use TYPO3\CMS\Fluid\View\StandaloneView;
use TYPO3\CMS\Core\Service\FlexFormService;


/**
 * Contains a preview rendering for the page module of CType="yourextensionkey_newcontentelement"
 */
class NewContentElementPreviewRenderer implements PageLayoutViewDrawItemHookInterface
{

    /**
     * Preprocesses the preview rendering of a content element of type "My new content element"
     *
     * @param \TYPO3\CMS\Backend\View\PageLayoutView $parentObject Calling parent object
     * @param bool $drawItem Whether to draw the item using the default functionality
     * @param string $headerContent Header content
     * @param string $itemContent Item content
     * @param array $row Record row of tt_content
     *
     * @return void
     */
    public function preProcess(
        PageLayoutView &$parentObject,
        &$drawItem,
        &$headerContent,
        &$itemContent,
        array &$row
    )
    {

        switch ($row['list_type']) {
            case 'tbsarticlesystem_tbsdatarecordsystemcurrent':
                $headerContent  =  "<h5><strong>" . \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate("tx_tbs_articlesystem_tbsdatarecordsystemcurrent.name" ,"tbs_articlesystem") . "</strong></h5>";
                $itemContent    = $this->getTbsDataRecordSystemCurrent($row);
                break;

            case 'tbsarticlesystem_tbsrubricoverview':
                $headerContent  =  "<h5><strong>" . \TYPO3\CMS\Extbase\Utility\LocalizationUtility::translate("tx_tbs_articlesystem_rubric_overview.name" ,"tbs_articlesystem") . "</strong></h5>";
                $itemContent    = $this->getTbsRubricOverview($row);
                break;

        }
        $drawItem = false;
    }



    /** Plugin Article System Current view Backend
     * @param $row
     * @return string
     */
    public function getTbsDataRecordSystemCurrent($row){



        $flexFormArray = \TYPO3\CMS\Core\Utility\GeneralUtility::xml2array($row['pi_flexform']);




        $translate = GeneralUtility::makeInstance(LocalizationUtility::class);

        $labelArticleTypePressRelease = $translate::translate('tx_tbs_articlesystem_tbsdatarecordsystem.type.press_release', 'tbs_articlesystem');
        $labelArticleTypeComment = $translate::translate('tx_tbs_articlesystem_tbsdatarecordsystem.type.comment','tbs_articlesystem');
        $labelArticleTypePositionPaper = $translate::translate('tx_tbs_articlesystem_tbsdatarecordsystem.type.position_paper', 'tbs_articlesystem');
        $labelArticleTypeStatement = $translate::translate('tx_tbs_articlesystem_tbsdatarecordsystem.type.statement','tbs_articlesystem');
        $labelLatestPageType = $translate::translate('flexforms_general.mode.articletype','tbs_articlesystem');

        switch ($flexFormArray['data']['sDEF']['lDEF']['switchableControllerActions']['vDEF']) {

            case 'CurrentDataRecords->latest':
                $labelArticleType =  $labelArticleType = $labelArticleTypePressRelease . ', ' . $labelArticleTypeComment . ', ' . $labelArticleTypePositionPaper . ', ' . $labelArticleTypeStatement;
                break;
            case 'CurrentDataRecords->latestPageType':
                $labelArticleType =  $labelLatestPageType;
                break;
        }


        $view = GeneralUtility::makeInstance(StandaloneView::class);
        $view->setTemplatePathAndFilename(GeneralUtility::getFileAbsFileName('EXT:tbs_articlesystem/Resources/Private/Templates/Backend/ArticleSystemDataRecordCurrent.html'));
        $view->assignMultiple([
            'labelArticleType' => $labelArticleType,
        ]);

        return $view->render();
    }


    public function getTbsRubricOverview($row){

        $ff = GeneralUtility::makeInstance(FlexFormService::class);
        $flex = $ff->convertFlexFormContentToArray($row['pi_flexform']);
        $view = GeneralUtility::makeInstance(StandaloneView::class);
        $view->setTemplatePathAndFilename(GeneralUtility::getFileAbsFileName('EXT:tbs_articlesystem/Resources/Private/Templates/Backend/Overview.html'));
        $view->assignMultiple([
            'headline' => $flex['settings']['headline'],
            'teasertext' => $flex['settings']['teasertext'],
        ]);
        return $view->render();
    }



}