<?php

namespace Tbs\TbsArticlesystem\Hooks;

use Tbs\TbsArticlesystem\Service\RequiredHandling;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;


class SaveHook
{


    // sys_file_reference => Alternative Text (require field) and Title only for articles teaserImage (require field)
    public function processDatamap_afterDatabaseOperations($status, $table, $id, array &$fieldArray, \TYPO3\CMS\Core\DataHandling\DataHandler &$pObj) {


        $sysFileReference = $pObj->datamap['sys_file_reference'];

        $formData = GeneralUtility::_GP('data');


        $value = 1;

        /*
         * requiredHandling of Article
         */
        $requiredHandlings = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(RequiredHandling::class);


        //image content
        if($table == 'tt_content'){
            if(is_array($formData['tt_content'])) {
                $ctypeId = key($formData['tt_content']);
                $cType = $formData['tt_content'][$ctypeId];
            }

            // video content element
            if($cType['CType'] == 'tbscontentelements_videocontent'){
                //filter array from sysFileReference for image field in tbscontentelements_videocontent
                $sysFileReference = $requiredHandlings->arrayFilter($sysFileReference, array($cType['image']));
            }
        }

        //article page types
        if($table == 'pages'){
            if(is_array($formData['pages'])){
                $pageseId = key($formData['pages']);
                $dokType = $formData['pages'][$pageseId];
            }

            //filter array from sysFileReference for image
            $teaserImage = $requiredHandlings->arrayFilter($sysFileReference, array($dokType['tx_tbs_articlesystem_teaser_image']));
            //filter array from sysFileReference for magazine footer teaser image
            $magazineTeaserImage = $requiredHandlings->arrayFilter($sysFileReference, array($dokType['tx_tbs_articlesystem_magazine_teaser_image']));
            if(is_array($magazineTeaserImage)) {
                $sysFileReference = array_merge($teaserImage, $magazineTeaserImage);
            }else{
                $sysFileReference = $teaserImage;
            }
        }


        // Alternative Text & Title for articles teaserImage and image element (require field)
        if($cType['CType'] == 'tbscontentelements_imagecontent' || $cType['CType'] == 'tbscontentelements_gallerycontent' || $cType['CType'] == 'tbscontentelements_videocontent' || $cType['CType'] == 'tbscontentelements_publications_teaser' || $cType['CType'] == 'tbscontentelements_application_teaser'
            || ($dokType['doktype'] >= 150 && $dokType['doktype'] <= 159)){
            if(is_array($sysFileReference)){
                foreach ($sysFileReference as $fileMetaData){
                    $requiredHandlings->requiredHandling('title', $fileMetaData, $value);
                    $requiredHandlings->requiredHandling('alternative', $fileMetaData, $value);
                }
            }
        }

    }


}

