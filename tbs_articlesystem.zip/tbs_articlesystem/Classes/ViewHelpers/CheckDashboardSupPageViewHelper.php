<?php

namespace Tbs\TbsArticlesystem\ViewHelpers;

use TYPO3\CMS\Core\Database\QueryGenerator;
use TYPO3\CMS\Core\Domain\Repository\PageRepository;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Extbase\Annotation as Extbase;


/**
 * View helper for rendering images in given format
 *
 * @package TYPO3
 * @subpackage tbs_dhaboard
 */
class CheckDashboardSupPageViewHelper extends \TYPO3Fluid\Fluid\Core\ViewHelper\AbstractViewHelper
{


    /**
     * pageRepository
     *
     * @var \TYPO3\CMS\Core\Domain\Repository\PageRepository
     * @TYPO3\CMS\Extbase\Annotation\Inject
     */
    protected $pageRepository;


    /**
     * pageTreeGenerator
     *
     * @var \TYPO3\CMS\Core\Database\QueryGenerator
     * @TYPO3\CMS\Extbase\Annotation\Inject
     */
    protected $pageTreeGenerator;


    /**
     * @var ObjectManager
     */
    protected $objectManager;



    /*
     * Initialize Arguments
     */
    public function initializeArguments()
    {
        $this->registerArgument('uid', 'integer', '');
    }

    public function render()
    {
        $dashboardPage = 3;
        $pageUnderDashboard = false ;
        $rootline = (array) $GLOBALS['TSFE']->rootLine;
        foreach ($rootline as  $dataArray) {
            $currentUid = $dataArray['uid'];
            if ($currentUid == $dashboardPage) $pageUnderDashboard = true;
        }
        return $pageUnderDashboard;
    }


}
