<?php

namespace Tbs\TbsArticlesystem\Service;

use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;


class KeyArrayArticleHandling implements \TYPO3\CMS\Core\SingletonInterface{

    //Key array handling for frontend
    public function keyArrayHandling($articleType,$data){


        $newData = [];

        // original values
        $newData['starttime'] = $data->getStarttime();
        $newData['endtime'] = $data->getEndtime();
        $newData['title'] = $data->getTitle();
        $newData['teaserText'] = $data->getTeaserText();
        $newData['leadText'] = $data->getLeadText();

        //Comment article
        if(($articleType == 'CommentDashboard') ||  ($articleType == 'Comment')){
            $newData['comment'] = $data->getComment();
            $newData['tx_tbs_articlesystem_roof_line'] = 'Statement';
            $date = $newData['starttime']->format('d.m.Y');
            if (strlen(trim($newData['leadText']))) {
                $newData['leadText'] = $date . ' – ' . $newData['leadText'];
            } else if (substr($newData['comment'], 0, 2) == '<p') {
                $newData['comment'] = '<p data-js-module="contentprefix" data-js-atom="' . $date . ' – "' . substr($newData['comment'], 2);
            }
            $newData['contact'] = $data->getContact();
        }

        //Statement article
        if(($articleType == 'StatementDashboard') ||  ($articleType == 'Statement')){
            $newData['statement'] = $data->getStatement();
            $newData['tx_tbs_articlesystem_roof_line'] = 'Stellungnahme';
            $newData['contact'] = $data->getContact();

        }

        //PositionPaper article
        if(($articleType == 'PositionPaperDashboard') ||  ($articleType == 'PositionPaper')){
            $newData['positionPaper'] = $data->getPositionPaper();
            $newData['images'] = $data->getImages();
            $newData['tx_tbs_articlesystem_roof_line'] = 'Positionspapier';
        }

        //Lense article
        if(($articleType == 'LenseDashboard') ||  ($articleType == 'Lense')){
            $newData['lense'] = $data->getLense();
            $newData['images'] = $data->getImages();
            $newData['tx_tbs_articlesystem_roof_line'] = 'Unter der Lupe';
        }

        //PressRelease article
        if(($articleType == 'PressReleaseDashboard') ||  ($articleType == 'PressRelease')){
            $newData['pressRelease'] = $data->getPressRelease();
            $date = $newData['starttime']->format('d.m.Y');
            if (strlen(trim($newData['leadText']))) {
                $newData['leadText'] = $date . ' – ' . $newData['leadText'];
            } else if (substr($newData['pressRelease'], 0, 2) == '<p') {
                $newData['pressRelease'] = '<p data-js-module="contentprefix" data-js-atom="' . $date . ' – "' . substr($newData['pressRelease'], 2);
            }
            $newData['tx_tbs_articlesystem_roof_line'] = 'Pressemitteilung';
            $newData['contact'] = $data->getContact();

        }

        $newData['isRevision'] = $data->getIsRevision();
        $newData['isNewsletter'] = $data->getIsNewsletter();
        $newData['isRss'] = $data->getIsRss();
        $newData['isSearches'] = $data->getIsSearches();
        $newData['keywords'] = $this->keywordsArray($data->getKeywords());
        $newData['downloads'] = $data->getDownloads();
        $newData['uid'] = $data->getUid();
        $newData['pid'] = $data->getPid();


        // create newsletter variables
        $newsletter = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['newsletter.'];
        $newData['newsletterLink'] = $newsletter['link'];
        $newData['newsletterHeadline'] = $newsletter['headline'];
        $newData['newsletterDescription'] = $newsletter['description'];
        $newData['newsletterButton'] = $newsletter['button'];

        // create hashtag variables
        $hashtags = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['hashtags.'];
        $newData['hashtagsLink'] = $hashtags['link'];

        // custom variables
        $newData['tx_tbs_articlesystem_date'] = $newData['starttime'];
        $newData['tx_tbs_articlesystem_lead_text'] = $newData['leadText'];
        $newData['tx_tbs_articlesystem_is_newsletter'] = $newData['isNewsletter'];

        return $newData;

    }

    //Keywords array for frontend
    public function keywordsArray($getKeywords){

        $keywords = [];
        // create keywords
        foreach($getKeywords as $val) {
            array_push($keywords, ['data' => [
                'uid' => $val->getUid(),
                'title' => $val->getTitle(),
                'pid' => $val->getPid()
            ]]);
        }

        return $keywords;
    }

    //get ArticleType from flexform
    public function getArticleType($flexform){

        $flexFormArray = \TYPO3\CMS\Core\Utility\GeneralUtility::xml2array($flexform);
        $switchableControllerActions = $flexFormArray['data']['sDEF']['lDEF']['switchableControllerActions']['vDEF'];
        $articleType = explode('->',$switchableControllerActions);

        return $articleType[0];
    }

}
