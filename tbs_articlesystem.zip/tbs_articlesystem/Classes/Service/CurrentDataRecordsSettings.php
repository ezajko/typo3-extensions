<?php

namespace Tbs\TbsArticlesystem\Service;



use Tbs\TbsArticlesystem\Service\ArticlePageSettings;
use TYPO3\CMS\Core\Domain\Repository\PageRepository;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Extbase\Annotation\Inject;
use TYPO3\CMS\Core\Context\Context;


class CurrentDataRecordsSettings implements \TYPO3\CMS\Core\SingletonInterface{

    /**
     * contentRepository
     *
     * @var \Tbs\TbsArticlesystem\Domain\Repository\ContentRepository
     * @inject
     */
    protected $contentRepository = null;


    public function __construct(){
        $this->cObj = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Frontend\\ContentObject\\ContentObjectRenderer');
        $this->articleSettings = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(ArticlePageSettings::class);
        $this->queryGenerator = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance( 'TYPO3\\CMS\\Core\\Database\\QueryGenerator' );
        $this->pageRepository = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(PageRepository::class);

    }

    // convert into array from object data records
    public function convertArray($dataRecords,$linkConfig,$dashboard = false){
        $currentArray = array();


        foreach($dataRecords as $key => $dataRecord) {
            $currentArray[$key]['uid'] = $dataRecord['uid'];
            $currentArray[$key]['starttime'] = $dataRecord['starttime'];
            $currentArray[$key]['title'] = $dataRecord['title'];
            $currentArray[$key]['teaserText'] = $dataRecord['teaser_text'];
            $linkConf = array(
                'parameter' => $linkConfig['parameter'],
                'forceAbsoluteUrl' => 1,
                'additionalParams' => \TYPO3\CMS\Core\Utility\GeneralUtility::implodeArrayForUrl(NULL, array(
                    'tx_tbsdashboard_tbsdashboardoverviewdetail[action]' => $linkConfig['action'],
                    'tx_tbsdashboard_tbsdashboardoverviewdetail[controller]' => $linkConfig['controller'],
                    'tx_tbsdashboard_tbsdashboardoverviewdetail['.$linkConfig['argument'].']' => $dataRecord['uid'],
                )),
                'linkAccessRestrictedPages' => 1
            );
            $links = $this->cObj->typolink_URL($linkConf);
            $currentArray[$key]['link'] = $links;
            $currentArray[$key]['type'] = $linkConfig['articleType'];
            $currentArray[$key]['argument'] = $linkConfig['argument'];

        }



        return $currentArray;
    }


    // array sort
    public function array_sort($array, $on, $order=SORT_ASC)
    {
        $new_array = array();
        $sortable_array = array();

        if (count($array) > 0) {
            foreach ($array as $k => $v) {
                if (is_array($v)) {
                    foreach ($v as $k2 => $v2) {
                        if ($k2 == $on) {
                            $sortable_array[$k] = $v2;
                        }
                    }
                } else {
                    $sortable_array[$k] = $v;
                }
            }

            switch ($order) {
                case SORT_ASC:
                    asort($sortable_array);
                    break;
                case SORT_DESC:
                    arsort($sortable_array);
                    break;
            }

            foreach ($sortable_array as $k => $v) {
                $new_array[$k] = $array[$k];
            }
        }

        return $new_array;
    }

    // array filter
    public function arrayFilter($array, $excludeId)
    {
        foreach ($excludeId as $arr) {
            $options[] = $arr;  // Converted to 1-d array
        }

        /* Filter $array and obtain those results for which ['uid'] value not matches with one of the values contained in $options */
        $result = array_filter($array, function($v) use ($options) {
            return !in_array($v['uid'], $options);
        });

        return array_values($result);
    }

    /**
     * get the Positionpaper Pages because the positionspaper is no longer a data record and it's a page Type
     *
     * @param  string  $positionpaperPagesIds             The page Uid for the Positionpaper
     * @param  array   $labelArticleTypePositionPaper     The page Label
     * @return array                                      Data Array of pages
     */
    public function positionpaperPagesHandling($positionpaperPagesIds,$labelArticleTypePositionPaper){
        $currentArray = array();
        $positionPapersPages = $this->contentRepository->findPositionPaperPages();

        if(!empty($positionPapersPages)){
            foreach($positionPapersPages as $key => $positionPaper) {
                $currentArray[$key]['uid'] =  $positionPaper['uid'];
                $currentArray[$key]['title'] = $positionPaper['title'];
                $currentArray[$key]['starttime'] = $positionPaper['tx_tbs_articlesystem_date'];
                $currentArray[$key]['teaserText'] = $positionPaper['tx_tbs_articlesystem_teaser_text'];
                $currentArray[$key]['leadText'] = $positionPaper['tx_tbs_articlesystem_lead_text'];
                $currentArray[$key]['type'] = $labelArticleTypePositionPaper;
                $currentArray[$key]['link'] = $url = $GLOBALS['TSFE']->cObj->typoLink_URL(
                    array(
                        'parameter' => $positionPaper['uid'],
                        'forceAbsoluteUrl' => true,
                    )
                );

            }

        }

        return $currentArray;
    }

    // get Article Type (Page) for Hero Teaser
    public function getPageTypeArticlesHeroTeaser($heroteaserIds){
        $mainnavigationPID = $GLOBALS['TSFE']->tmpl->setup_constants['page.']['mainnavigation'];
        $subPageIds = $this->queryGenerator->getTreeList($mainnavigationPID, 20, 1,'hidden=0');
        $subPageIdsArray = explode(',',$subPageIds);
        $subPageIdsArray = !empty($heroteaserIds) ? array($heroteaserIds) : $subPageIdsArray;
        $pagesArray = $this->pageRepository->getMenuForPages($subPageIdsArray,$fields = '*', $sortField = 'tx_tbs_articlesystem_date DESC', $additionalWhereClause = 't3ver_wsid = 0 AND (doktype = 150 || doktype = 151 || doktype = 152 || doktype = 153 || doktype = 155 || doktype = 156)');
        $currentArray = array();
        $i = 0;
        foreach($pagesArray as $key => $pages) {
            if($i == 0){
                $currentArray['uid'] =  $pages['uid'];
                if(empty($pages['tx_tbs_articlesystem_roof_line']) &&  $pages['doktype'] != 154  &&  $pages['doktype'] != 155 ){
                    $currentArray['tx_tbs_articlesystem_roof_line'] = $this->articleSettings->getTitleOfParentPage($pages['pid']);
                }else{
                    $currentArray['tx_tbs_articlesystem_roof_line'] = $pages['tx_tbs_articlesystem_roof_line'];
                }
                $currentArray['title'] = $pages['title'];
                $currentArray['starttime'] = $pages['tx_tbs_articlesystem_date'];
                $currentArray['teaserText'] = $pages['tx_tbs_articlesystem_teaser_text'];
                $currentArray['leadText'] = $pages['tx_tbs_articlesystem_lead_text'];
                if($pages['tx_tbs_articlesystem_teaser_image'] == 1){
                    $image = $this->articleSettings->getTeaserImage($currentArray['uid'], 'pages',
                        'tx_tbs_articlesystem_teaser_image');
                    $currentArray['teaserImage'] = $image;
                }
            }
            $i++;
        }
        return $currentArray;
    }


    // get Article Type (Page) for 3 Teaser
    public function getPageTypeArticlesTeaser($pagetypesIds,$heroteaserId){
        $mainnavigationPID = $GLOBALS['TSFE']->tmpl->setup_constants['page.']['mainnavigation'];
        $subPageIds = $this->queryGenerator->getTreeList($mainnavigationPID, 3, 1,'hidden=0');
        $subPageIdsArray = explode(',',$subPageIds);
        if(!empty($pagetypesIds)){
            $query = 'uid NOT IN('.$pagetypesIds.') AND ';
        }else{
            $query = '';
        }
        $pagesArray = $this->pageRepository->getMenuForPages($subPageIdsArray,$fields = '*', $sortField = 'tx_tbs_articlesystem_date DESC', $additionalWhereClause = ''.$query.'uid NOT IN('.$heroteaserId.') AND t3ver_wsid = 0 AND (doktype = 150 || doktype = 151 || doktype = 152 || doktype = 153 || doktype = 155 || doktype = 156)');

        $currentArray = array();
        $i = 0;
        foreach($pagesArray as $key => $pages) {
            if($i <= 2){
                $currentArray[$i]['uid'] =  $pages['uid'];
                if(empty($pages['tx_tbs_articlesystem_roof_line']) &&  $pages['doktype'] != 154  &&  $pages['doktype'] != 155 ){
                    $currentArray[$i]['tx_tbs_articlesystem_roof_line'] = $this->articleSettings->getTitleOfParentPage($pages['pid']);
                }else{
                    $currentArray[$i]['tx_tbs_articlesystem_roof_line'] = $pages['tx_tbs_articlesystem_roof_line'];
                }
                $currentArray[$i]['title'] = $pages['title'];
                $currentArray[$i]['starttime'] = $pages['tx_tbs_articlesystem_date'];
                $currentArray[$i]['teaserText'] = $pages['tx_tbs_articlesystem_teaser_text'];
                $currentArray[$i]['leadText'] = $pages['tx_tbs_articlesystem_lead_text'];
                if($pages['tx_tbs_articlesystem_teaser_image'] == 1){
                    $image = $this->articleSettings->getTeaserImage($pages['uid'], 'pages',
                        'tx_tbs_articlesystem_teaser_image');
                    $currentArray[$i]['teaserImage'] = $image;
                }
            }
            $i++;
        }
        return $currentArray;
    }

    // heroTeaser For Backend flexform
    public function heroTeaserForBackend(array &$config){
        $subPageIds = $this->queryGenerator->getTreeList(2, 20, 1,'hidden=0');
        $subPageIdsArray = explode(',',$subPageIds);
        $pagesArray = $this->pageRepository->getMenuForPages($subPageIdsArray,$fields = '*', $sortField = 'tx_tbs_articlesystem_date DESC', $additionalWhereClause = 't3ver_wsid = 0 AND (doktype = 150 || doktype = 151 || doktype = 152 || doktype = 153 || doktype = 155 || doktype = 156)');
        foreach($pagesArray as $key => $pages) {
            $config['items'][] = array($pages['title'],$pages['uid']);
        }
    }

    // pageTeaser For Backend flexform
    public function pageTeaserForBackend(array &$config){

        $excludedList = $config['row']['settings.pagetypes'];
        if(!empty($excludedList)){
            $query = 'uid NOT IN('.$excludedList.') AND ';
        }else{
            $query = '';
        }

        $subPageIds = $this->queryGenerator->getTreeList(2, 3, 1,'hidden=0');
        $subPageIdsArray = explode(',',$subPageIds);
        $pagesArrayIncludedList = $this->pageRepository->getMenuForPages($subPageIdsArray,$fields = '*', $sortField = 'tx_tbs_articlesystem_date DESC', $additionalWhereClause = ''.$query.'t3ver_wsid = 0 AND (doktype = 150 || doktype = 151 || doktype = 152 || doktype = 153 || doktype = 155 || doktype = 156)');
        if(!empty($excludedList)){
            $excludedLists = explode(',', $excludedList);
            $query = 'uid IN('.$excludedList.') AND ';
            $pagesArrayExcludedList = $this->pageRepository->getMenuForPages($subPageIdsArray,$fields = '*', $sortField = 'tx_tbs_articlesystem_date DESC', $additionalWhereClause = ''.$query.'t3ver_wsid = 0');
            $pagesArray = array_merge(array_values($pagesArrayExcludedList),array_values($pagesArrayIncludedList));
            $num = 1;
        }else{
            $pagesArray = $pagesArrayIncludedList;
            $num = 2;
        }

        $i = 0;
        foreach($pagesArray as $key => $pages) {
            if($num == 2){
                if($i <= 2){
                    $config['items'][] = array($pages['title'],$pages['uid']);
                }
            }
            if($num == 1){
                $nums = count($excludedLists);
                if($i <= (2+$nums)){
                    $config['items'][] = array($pages['title'],$pages['uid']);
                }
            }
            $i++;
        }

    }

}
