<?php

namespace Tbs\TbsArticlesystem\Service;

use Tbs\TbsArticlesystem\Domain\Repository\ContentRepository;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;


class MediaArticlePageSettings implements \TYPO3\CMS\Core\SingletonInterface{


    /**
     * pageRepository
     *
     * @var \TYPO3\CMS\Core\Domain\Repository\PageRepository
     * @TYPO3\CMS\Extbase\Annotation\Inject
     */
    protected $pageRepository;


    /**
     * @var ObjectManager
     */
    protected $objectManager;


    public function __construct(){
        $this->objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        $this->contentRepository = $this->objectManager->get(ContentRepository::class);
    }

    /**
     * contentRepository
     *
     * @var \Tbs\TbsArticlesystem\Domain\Repository\ContentRepository
     * @Inject
     */
    protected $contentRepository;


    /**
     * returns all the Media of an media article
     * @param $pageUid
     * @return array
     */
    public function getArticlesystemMediaData($pageUid)
    {
        $data = array();
        $articleSettings = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(ArticlePageSettings::class);
        $mediaData = $this->contentRepository->findAllMediaContent($pageUid);

        $foreignTable = 'tx_tbs_articlesystem_media_data' ;
        if(!empty($mediaData)){
            foreach ($mediaData as $key => $media){
                // --- Check the type of media ---
                switch ($media['tx_tbs_articlesystem_media_type']) {
                    // --- Download Element need to add key if they would be Multiple element ---
                    case 1:
                        $downloads = $this->getAllMediaArticle($media['uid'], $foreignTable, 'tx_tbs_articlesystem_media_download');
                        $data[$key]['downloads']['type'] = 1;
                        $data[$key]['downloads']['download']= $downloads;
                        break;
                    // --- Gallery Element ---
                    case 2:
                        $gallery = $this->getAllMediaArticle($media['uid'], $foreignTable, 'tx_tbs_articlesystem_media_gallery_image');
                        $data[$key]['galleries']['type'] = 2;
                        $data[$key]['galleries']['gallery'] = $gallery;
                        break;

                    // --- Audio Element ---
                    case 3:
                        $audio = $this->getAllMediaArticle($media['uid'], $foreignTable, 'tx_tbs_articlesystem_media_audio');
                        $data[$key]['audios']['type'] = 3;
                        $data[$key]['audios']['audio'] = $audio;
                        $data[$key]['audios']['audioType'] = $media['tx_tbs_articlesystem_media_audio_type'];
                        $data[$key]['audios']['audioTranscript'] = $media['tx_tbs_articlesystem_media_audio_transcript'];
                        $data[$key]['audios']['embededCode'] = $media['tx_tbs_articlesystem_media_audio_embeded'];
                        break;
                    // --- Video Element ---
                    case 4:
                        $video = $this->getAllMediaArticle($media['uid'], $foreignTable, 'tx_tbs_articlesystem_media_video');
                        $videoPoster = $this->getAllMediaArticle($media['uid'], $foreignTable, 'tx_tbs_articlesystem_media_video_poster');

                        $data[$key]['videos']['type'] = 4;
                        $data[$key]['videos']['video'] = $video;
                        $data[$key]['videos']['has_subtitle'] = $media['tx_tbs_articlesystem_media_video_has_subtitle'];
                        $data[$key]['videos']['videoPoster'] = $videoPoster;
                        $data[$key]['videos']['videotranscript'] =  $media['tx_tbs_articlesystem_media_video_transcript'];
                        break;

                    // --- Fotos Element ---
                    case 5:
                        $fotos = $this->getAllMediaArticle($media['uid'], $foreignTable, 'tx_tbs_articlesystem_media_image');
                        $data[$key]['fotos']['type'] = 5;
                        $data[$key]['fotos']['imagesObjects'] = $fotos;
                        break;
                }
            }
        }
        return $data ;
    }


    /**
     * returns All Media for Media Article
     * @param $contentUid
     * @param $foreignTable
     * @param $foreignField
     * @return array
     */
    public function getAllMediaArticle($contentUid, $foreignTable, $foreignField)
    {
        $medias = array();
        $mediasUids = $this->contentRepository->findAssetsIds($contentUid, $foreignTable, $foreignField);
        $new = array_filter($mediasUids, function ($var) {
            return ($var['t3ver_oid'] != 0);
        });
        $mediasUidsnew = count($new) > 0 ? array_values($new) : $mediasUids;

        $resourceFactory = \TYPO3\CMS\Core\Resource\ResourceFactory::getInstance();
        foreach ($mediasUidsnew as $key => $mediaUid){
            $media = $resourceFactory->getFileReferenceObject($mediaUid['uid']);
            $medias[$key] = $media;
        }
        return $medias;
    }



}
