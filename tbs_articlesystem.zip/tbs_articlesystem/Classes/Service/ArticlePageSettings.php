<?php

namespace Tbs\TbsArticlesystem\Service;

use Tbs\TbsArticlesystem\Domain\Repository\ContentRepository;
use TYPO3\CMS\Extbase\Service\ImageService;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Core\Domain\Repository\PageRepository;
use Tbs\TbsChartsExtended\Controller\ChartDataController;


class ArticlePageSettings implements \TYPO3\CMS\Core\SingletonInterface{


    /**
     * pageRepository
     *
     * @var \TYPO3\CMS\Core\Domain\Repository\PageRepository
     * @TYPO3\CMS\Extbase\Annotation\Inject
     */
    protected $pageRepository;


    /**
     * @var ObjectManager
     */
    protected $objectManager;


    public function __construct(){
        $this->objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        $this->contentRepository = $this->objectManager->get(ContentRepository::class);
        $this->resourceFactory = GeneralUtility::makeInstance(\TYPO3\CMS\Core\Resource\ResourceFactory::class);
    }


    /**
     * returns proccessed image for article teaser
     * @param $contentUid
     * @param $foreignTable
     * @param $foreignField
     * @deprecated
     * @return array
     */
    public function getContentImages($contentUid, $foreignTable, $foreignField)
    {

        $imageUids = $this->contentRepository->findAssetsIds($contentUid, $foreignTable, $foreignField);
        $imageService = $this->objectManager->get(ImageService::class);
        $imageUriArray = array();

        $processingInstructions = array(
            'maxWidth'  => 400,
            'maxHeight' => 200,
        );
        foreach ($imageUids as $key => $imageUid){
            $imageTitle = $this->contentRepository->findAssetsProperties($imageUid['uid_local']);
            $file = $this->resourceFactory->getFileReferenceObject($imageUid['uid'])->getPublicUrl();

            $image = $imageService->getImage($file, null, true);
            $processedImage = $imageService->applyProcessingInstructions($image, $processingInstructions);
            $imageUriArray[$key]['url'] = $imageService->getImageUri($processedImage);
            $imageUriArray[$key]['title'] = isset($imageUid['title']) ? $imageUid['title'] : $imageTitle[0]['title'];
            $imageUriArray[$key]['alternative'] = isset($imageUid['alternative']) ? $imageUid['alternative'] : $imageTitle[0]['alternative'];
            $imageUriArray[$key]['description'] = isset($imageUid['description']) ? $imageUid['description'] : $imageTitle[0]['description'];
            $imageUriArray[$key]['link'] = $imageUid['link'];

        }
        return $imageUriArray;
    }


    /**
     * returns proccessed file for article downloads
     * @param $contentUid
     * @param $foreignTable
     * @param $foreignField
     *
     * @return array
     */
    public function getContentFiles($contentUid, $foreignTable, $foreignField)
    {
        $assetUids = $this->contentRepository->findAssetsIds($contentUid, $foreignTable, $foreignField);

        $new = array_filter($assetUids, function ($var) {
            return ($var['t3ver_oid'] != 0);
        });
        $assetUidsnew = count($new) > 0 ? array_values($new) : $assetUids;


        $fileNameArray = array();
        foreach ($assetUidsnew as $key => $assetUid){
                $fileTitle = $this->contentRepository->findAssetsProperties($assetUid['uid_local']);
                $fileNameArray[$key]['url'] = $this->resourceFactory->getFileObject($assetUid['uid_local'])->getPublicUrl();
                $fileNameArray[$key]['title'] = isset($assetUid["title"]) ? $assetUid['title'] : $fileTitle[0]['title'];
                $fileNameArray[$key]['description'] = isset($assetUid['description']) ? $assetUid['description'] : $fileTitle[0]['description'];
        }

        return $fileNameArray;
    }





    /**
     * returns  image for article teaser and positionPaper
     * @param $contentUid
     * @param $foreignTable
     * @param $foreignField
     * @param $positionPaper
     *
     * @return array
     */
    public function getTeaserImage($contentUid, $foreignTable, $foreignField, $positionPaper = false)
    {
        $image = array();
        $imageArray = array();
        $imageUids = $this->contentRepository->findAssetsIds($contentUid, $foreignTable, $foreignField);
        if(!empty($imageUids)){
            foreach ($imageUids as $key => $imageUid){
                if(!empty($imageUid)){
                    // workspace
                    $imageUId['uid'] = $imageUid['t3ver_oid'] == 0 ? $imageUid['uid'] : $imageUid['t3ver_oid'];
                    $image = $this->resourceFactory->getFileReferenceObject($imageUId['uid']);
                    if($positionPaper == true){
                        $imageArray[$key] =$image;
                    }
                }
            }
            if($positionPaper == true){
                return $imageArray;
            }
            return $image;
        }
        return $image;
    }


    /**
     *
     * @param $parenttUid
     *
     * @return string
     */
    public function getTitleOfParentPage($parenttUid)
    {
        $title = '';
        $this->pageRepository = $this->objectManager->get(PageRepository::class);
        $page = $this->pageRepository->getPage($parenttUid);
        $title = $page['title'];
        return $title;
    }


    // get statistic diagram
    public function getStatistic($statisticUid)
    {
        $ChartDataController = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(ChartDataController::class);
        $chart = $ChartDataController->singleAction($statisticUid);
        return $chart;
    }
}
