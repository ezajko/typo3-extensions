<?php

namespace Tbs\TbsArticlesystem\Service;

use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Messaging\FlashMessage;
use TYPO3\CMS\Core\Messaging\FlashMessageService;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;


class RequiredHandling implements \TYPO3\CMS\Core\SingletonInterface{


    public function requiredHandling($metaDataField, $dataMap, $value){


        $translate = GeneralUtility::makeInstance(LocalizationUtility::class);
        $messageField = $translate::translate('sys_file_reference.' . $metaDataField, 'tbs_articlesystem');
        if(is_array($dataMap)){
            $attribute = $dataMap;
        }


        if(isset($attribute['uid_local'])){
            $uid_local = explode('_',$attribute['uid_local']);

            $connection = GeneralUtility::makeInstance(ConnectionPool::class)
                ->getConnectionForTable('sys_file_metadata');
            $queryBuilder = $connection->createQueryBuilder();
            $queryBuilder->quoteIdentifier('*');
        }


        if($uid_local[2] != NULL){

            $query = $queryBuilder
                ->select('uid', $metaDataField)
                ->from('sys_file_metadata')
                ->where('file = ' . $uid_local[2] .'');
            $rows = $query->execute()->fetchAll();

        }else{
            $rows[0][$metaDataField] = "1";
        }



        if (($attribute[$metaDataField] == "" && $rows[0][$metaDataField] == "" && $value == 1) || ($value == "" && $rows[0][$metaDataField] != "")) {

            $message = GeneralUtility::makeInstance(FlashMessage::class,
                'Required',
                $messageField, // [optional] the header
                FlashMessage::ERROR, // [optional] the severity defaults to \TYPO3\CMS\Core\Messaging\FlashMessage::OK
                false // [optional] whether the message should be stored in the session or only in the \TYPO3\CMS\Core\Messaging\FlashMessageQueue object (default is false)
            );

            $flashMessageService = GeneralUtility::makeInstance(FlashMessageService::class);
            $messageQueue = $flashMessageService->getMessageQueueByIdentifier();
            $messageQueue->addMessage($message);
        }
    }

    public function arrayFilter($sysFileReference, $fieldData){

        if(is_array($sysFileReference)) {
            $filtered = array_filter(
                $sysFileReference,
                function ($key) use ($fieldData) {
                    return in_array($key, $fieldData);
                },
                ARRAY_FILTER_USE_KEY
            );
        }
        return $filtered;
    }
}
