<?php
namespace Tbs\TbsArticlesystem\Controller;

use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Extbase\Annotation\Inject;
use TYPO3\CMS\Core\Context\Context;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;
use TYPO3\CMS\Core\Domain\Repository\PageRepository;


/***
 *
 * This file is part of the "TBS article system" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, THE BRETTINGHAMS GMBH
 *
 ***/

/**
 * CurrentDataRecordsController
 */
class CurrentDataRecordsController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * pageRepository
     *
     * @var \TYPO3\CMS\Core\Domain\Repository\PageRepository
     * @Inject
     */
    protected $pageRepository;

    /**
     * pressReleaseRepository
     *
     * @var \Tbs\TbsArticlesystem\Domain\Repository\PressReleaseRepository
     * @inject
     */
    protected $pressReleaseRepository = null;

    /**
     * commentRepository
     *
     * @var \Tbs\TbsArticlesystem\Domain\Repository\CommentRepository
     * @inject
     */
    protected $commentRepository = null;



    /**
     * statementRepository
     *
     * @var \Tbs\TbsArticlesystem\Domain\Repository\StatementRepository
     * @inject
     */
    protected $statementRepository = null;

    /**
     * currentDataRecordsSettings
     *
     * @var \Tbs\TbsArticlesystem\Service\CurrentDataRecordsSettings
     * @Inject
     */
    protected $currentDataRecordsSettings;

    /**
     * action latest
     *
     * @return void
     */
    public function latestAction()
    {
        //get selected articles uid from flexform
        $pressreleaseIds = $this->settings['pressrelease'];
        $commentIds = $this->settings['comment'];
        //change requirement
        $positionpaperPagesIds = $this->settings['positionpaper'];
        $statementIds = $this->settings['statement'];

        //-- get the constante
        $constante = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_dashboard.']['recordStoragePid.'];
        $pressreleaseDetailUid = $constante['pressreleaseDetailsPageUid'] ;
        $statementDetailUid = $constante['statementDetailsPageUid'] ;
        $commentDetailUid = $constante['commentDetailsPageUid'] ;

        $translate = GeneralUtility::makeInstance(LocalizationUtility::class);
        // localization label for article
        $labelArticleTypePressRelease = $translate::translate('tx_tbs_articlesystem_tbsdatarecordsystem.type.press_release', 'tbs_articlesystem');
        $labelArticleTypeComment = $translate::translate('tx_tbs_articlesystem_tbsdatarecordsystem.type.comment','tbs_articlesystem');
        $labelArticleTypeStatement = $translate::translate('tx_tbs_articlesystem_tbsdatarecordsystem.type.statement','tbs_articlesystem');
        $labelArticleTypePositionPaper = $translate::translate('tx_tbs_articlesystem_tbsdatarecordsystem.type.position_paper', 'tbs_articlesystem');

        // --- get all DATA ---
        $cObj = $this->configurationManager->getContentObject()->data;

        $pressReleasesLatest = $this->pressReleaseRepository->latestPressReleases();
        $commentsLatest = $this->commentRepository->latestComments();
        $statementsLatest = $this->statementRepository->latestStatements();
        $positionPapers = $this->currentDataRecordsSettings->positionpaperPagesHandling($positionpaperPagesIds,$labelArticleTypePositionPaper);

        //PressRelease linkConf
        $linkConfPressReleases = array(
            'parameter' => $pressreleaseDetailUid,
            'action' => 'detail',
            'controller' => 'PressReleaseDashboard',
            'argument' => 'pressRelease',
            'articleType' => $labelArticleTypePressRelease,
        );
        //PressRelease convert into Array
        $pressReleases = $this->currentDataRecordsSettings->convertArray($pressReleasesLatest,$linkConfPressReleases);

        //PressRelease exclude from latest by editor from backend
        if(!empty($pressreleaseIds) > 0){
            $pressreleaseIds = explode(',', $pressreleaseIds);
            $pressReleases = $this->currentDataRecordsSettings->arrayFilter($pressReleasesLatest,$pressreleaseIds);
            $pressReleases = $this->currentDataRecordsSettings->convertArray($pressReleases,$linkConfPressReleases);
        }

        //Comment linkConf
        $linkConfStatement = array(
            'parameter' => $commentDetailUid,
            'action' => 'detail',
            'controller' => 'CommentDashboard',
            'argument' => 'comment',
            'articleType' => $labelArticleTypeComment,
        );
        //Comment convert into Array
        $comments = $this->currentDataRecordsSettings->convertArray($commentsLatest,$linkConfStatement);

        //Comment exclude from latest by editor from backend
        if(!empty($commentIds)){
            $commentIds = explode(',', $commentIds);
            $comments = $this->currentDataRecordsSettings->arrayFilter($commentsLatest,$commentIds);
            $comments = $this->currentDataRecordsSettings->convertArray($comments,$linkConfStatement);
        }

        //Statement linkConf
        $linkConfStatement = array(
            'parameter' => $statementDetailUid,
            'action' => 'detail',
            'controller' => 'StatementDashboard',
            'argument' => 'statement',
            'articleType' => $labelArticleTypeStatement,
        );
        //Statement convert into Array
        $statements = $this->currentDataRecordsSettings->convertArray($statementsLatest,$linkConfStatement);

        //Statement exclude from latest by editor from backend
        if(!empty($statementIds)){
            $statementIds = explode(',', $statementIds);
            $statements = $this->currentDataRecordsSettings->arrayFilter($statementsLatest,$statementIds);
            $statements = $this->currentDataRecordsSettings->convertArray($statements,$linkConfStatement);
        }

        //positionPaper Page exclude from latest by editor from backend
        if(!empty($positionpaperPagesIds)){
            $positionpaperPagesIds = explode(',', $positionpaperPagesIds);
            $positionPapers = $this->currentDataRecordsSettings->arrayFilter($positionPapers,$positionpaperPagesIds);
        }

        //latest 5 articles sort by starttime
        $latestArticles = array_slice($this->currentDataRecordsSettings->array_sort(array_merge($pressReleases,$positionPapers,$comments,$statements), 'starttime', SORT_DESC), 0, 5, true);


        // --- General Data for the header ---
        $this->view->assign('header', $cObj['header']);
        $this->view->assign('latestArticles', $latestArticles);

    }


    /**
     * action latestPageType
     *
     * @return void
     */
    public function latestPageTypeAction()
    {
        //get selected article uid from flexform for hero Teaser
        $heroteaserIds = $this->settings['heroteaser'];
        $heroTeaser = $this->currentDataRecordsSettings->getPageTypeArticlesHeroTeaser($heroteaserIds);

        //get selected article uid from flexform for 3 Teaser
        $checkbox = $this->settings['checkbox'];
        $pagetypesIds = $this->settings['pagetypes'];
        $teasers = $this->currentDataRecordsSettings->getPageTypeArticlesTeaser($pagetypesIds,$heroTeaser['uid']);

        $this->view->assign('heroTeaser', $heroTeaser);
        $this->view->assign('teasers', $teasers);
        $this->view->assign('checkbox', $checkbox);
    }

}
