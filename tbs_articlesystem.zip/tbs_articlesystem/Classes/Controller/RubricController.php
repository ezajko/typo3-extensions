<?php
namespace Tbs\TbsArticlesystem\Controller;

use TYPO3\CMS\Core\Service\FlexFormService;
use TYPO3\CMS\Extbase\Annotation\Inject;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/***
 *
 * This file is part of the "TBS article system" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, THE BRETTINGHAMS GMBH
 *
 ***/

/**
 * StatementController
 */
class RubricController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * pageRepository
     *
     * @var \TYPO3\CMS\Core\Domain\Repository\PageRepository
     * @Inject
     */
    protected $pageRepository;


    /**
     * pageTreeGenerator
     *
     * @var \TYPO3\CMS\Core\Database\QueryGenerator
     * @Inject
     */
    protected $pageTreeGenerator;

    /**
     * contentRepository
     *
     * @var \Tbs\TbsContentElements\Domain\Repository\ContentRepository
     * @Inject
     */
    protected $contentRepository;

    /**
     * categoryRepository
     *
     * @var \TYPO3\CMS\Extbase\Domain\Repository\CategoryRepository
     * @Inject
     */
    protected $categoryRepository;

    /**
    * categoryRepository
    *
    * @var \TYPO3\CMS\Core\Resource\FileRepository
    * @Inject
    */
    protected $fileRepository;



    /**
     * action overview
     *
     * @return void
     */
    public function overviewAction()
    {
        // --- get all DATA ---
        $cObj = $this->configurationManager->getContentObject()->data;

        $subPages = $this->getSubPages($cObj['pid']);

        foreach ($subPages as $pageId => &$pageInformation){
            $fileName = $this->fileRepository->findByRelation('pages', 'tx_tbs_articlesystem_teaser_image', $pageId);
            $categoriesMmDataRecords = $this->contentRepository->findRlatedCategoriesAndArticles('pages', 'tx_tbs_articlesystem_keywords', $pageId, '');
            if(!empty($fileName)) {
                $pageInformation['articleImage'] = $fileName[0];
            }
            if(!empty($categoriesMmDataRecords)) {
                foreach ($categoriesMmDataRecords as $categoryMmDataRecord){

                    $category = $this->categoryRepository->findByUid($categoryMmDataRecord['uid_local']);

                    $pageInformation['hashtags'][] = $category;
                }
            }
        }

        $this->view->assign('subPages', $subPages);
        $this->view->assign('countSubPages', count($subPages));
        $this->view->assign('headline', $this->settings['headline']);
        $this->view->assign('teaserText', $this->settings['teasertext']);
    }

    /**
     * helper function to get sub page sorted by tx_tbs_articlesystem_date
     *
     * @param string $startPageId
     *
     * @return array
     */
    private function getSubPages($startPageId){

        $pagesArray = array();

        $fields = 'uid, pid, title, tx_tbs_articlesystem_date, tx_tbs_articlesystem_teaser_text, tx_tbs_articlesystem_lead_text';

        $subPageIds = $this->pageTreeGenerator->getTreeList($startPageId, 7, 1, 'hidden=0');
        $subPageIdsArray = explode(',',$subPageIds);
        $pagesArray = $this->pageRepository->getMenuForPages($subPageIdsArray, $fields,'tx_tbs_articlesystem_date DESC', 'doktype >=150');

        return $pagesArray;
    }
}
