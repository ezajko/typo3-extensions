<?php

namespace Tbs\TbsArticlesystem\Evaluation;

use Tbs\TbsArticlesystem\Service\RequiredHandling;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/**
 * Class for field value validation/evaluation to be used in 'eval' of TCA "Alternative"
 */
class AlternativeEvaluation {

    /**
     * When checkbox is checked then executed Server-side validation/evaluation on saving the record
     *
     * @param string $value The field value to be evaluated
     * @param string $is_in The "is_in" value of the field configuration from TCA
     * @param bool $set Boolean defining if the value is written to the database or not. Must be passed by reference and changed if needed.
     * @return string Evaluated field value
     */
    public function evaluateFieldValue($value, $is_in, &$set) {


        $formData = GeneralUtility::_GP('data');

        $sysFileReference = $formData['sys_file_reference'];

        /*
         * requiredHandling of Article
         */
        $requiredHandlings = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(RequiredHandling::class);

        // get table name
        if(is_array($formData)) {
            $table = array_keys($formData);
        }


        //article page types
        if(is_array($formData['pages'])){
            $pageseId = key($formData['pages']);
            $dokType = $formData['pages'][$pageseId];

            //filter array from sysFileReference for image
            $teaserImage = $requiredHandlings->arrayFilter($sysFileReference, array($dokType['tx_tbs_articlesystem_teaser_image']));
            //filter array from sysFileReference for magazine footer teaser image
            $magazineTeaserImage = $requiredHandlings->arrayFilter($sysFileReference, array($dokType['tx_tbs_articlesystem_magazine_teaser_image']));
            $sysFileReference = array_merge($teaserImage,$magazineTeaserImage);


        }

        //image content
        if($table[0] == 'tt_content'){
            $ctypeId = key($formData['tt_content']);
            $cType = $formData['tt_content'][$ctypeId];

            // video content element
            if($cType['CType'] == 'tbscontentelements_videocontent'){
                //filter array from sysFileReference for image field in tbscontentelements_videocontent
                $sysFileReference = $requiredHandlings->arrayFilter($sysFileReference, array($cType['image']));
            }
        }


        if($cType['CType'] == 'tbscontentelements_imagecontent' || $cType['CType'] == 'tbscontentelements_gallerycontent' || $cType['CType'] == 'tbscontentelements_videocontent' || $cType['CType'] == 'tbscontentelements_publications_teaser' || $cType['CType'] == 'tbscontentelements_application_teaser' || ($dokType['doktype'] >= 150 && $dokType['doktype'] <= 159)){
            if(is_array($sysFileReference)) {
                foreach ($sysFileReference as $fileMetaData) {
                    $requiredHandlings->requiredHandling('alternative', $fileMetaData, $value);
                }
            }
        }

        return $value;
    }

}
