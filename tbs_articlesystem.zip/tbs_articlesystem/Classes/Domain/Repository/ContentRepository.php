<?php
namespace Tbs\TbsArticlesystem\Domain\Repository;

use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;


/**
 * The repository for tt_content
 */
class ContentRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{
    /**
     * @var array
     */
    protected $defaultOrderings = [
        'sorting' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_ASCENDING
    ];


    /**
     * finds images uid
     * @param $contentUid
     * @param $foreignTable
     * @param $foreignColumn
     * @return array
     */
    public function findAssetsIds($contentUid, $foreignTable, $foreignColumn)
    {

        $connection = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getConnectionForTable('sys_file_reference');
        $queryBuilder = $connection->createQueryBuilder();
        $queryBuilder->quoteIdentifier('*');
        $query = $queryBuilder
            ->select('*')
            ->from('sys_file_reference')
            ->where('uid_foreign = ' . $contentUid .' AND tablenames = "' . $foreignTable . '" AND fieldname = "' . $foreignColumn . '"')
            ->orderBy('sorting_foreign','ASC');

        $rows = $query->execute()->fetchAll();
        return $rows;
    }


    /**
     * finds image properties
     */
    public function findAssetsProperties($uidLocal)
    {

        $connection = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getConnectionForTable('sys_file_metadata');
        $queryBuilder = $connection->createQueryBuilder();
        $queryBuilder->quoteIdentifier('*');
        $query = $queryBuilder
            ->select('*')
            ->from('sys_file_metadata')
            ->where('uid = ' . $uidLocal);


        $rows = $query->execute()->fetchAll();
        return $rows;
    }


    /**
     * finds findAllMediaContent
     */
    public function findAllMediaContent($pageUid)
    {
        $connection = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getConnectionForTable('tx_tbs_articlesystem_media_data');
        $queryBuilder = $connection->createQueryBuilder();
        $queryBuilder->quoteIdentifier('*');
        $query = $queryBuilder
            ->select('*')
            ->from('tx_tbs_articlesystem_media_data')
            ->where('pid = ' . $pageUid)
            ->orderBy('sorting','ASC');
        $rows = $query->execute()->fetchAll();
        return $rows;

    }

    /**
     * The latest PositionPaper articles Pages by sorting tx_tbs_articlesystem_date DESC
     * @param $doktype integer
     * @return Array
     */
    public function findPositionPaperPages($doktype = 154)
    {

        $connection = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getConnectionForTable('pages');
        $queryBuilder = $connection->createQueryBuilder();
        $queryBuilder->quoteIdentifier('*');
        $query = $queryBuilder
            ->select('uid','title','tx_tbs_articlesystem_date','tx_tbs_articlesystem_teaser_text','tx_tbs_articlesystem_lead_text')
            ->from('pages')
            ->where('doktype = ' . $doktype .' AND t3ver_wsid = 0')
            ->orderBy('tx_tbs_articlesystem_date', 'DESC')
            ->setMaxResults(5);

        $positionPaper = $query->execute()->fetchAll();
        return $positionPaper;
    }

}
