<?php
namespace Tbs\TbsArticlesystem\Domain\Repository;

use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
/***
 *
 * This file is part of the "TBS article system" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, THE BRETTINGHAMS GMBH
 *
 ***/

/**
 * The repository for Comment
 */
class CommentRepository extends \TYPO3\CMS\Extbase\Persistence\Repository
{


    // The comment articles by sorting starttime DESC
    public function findAll($storagePageIds = null) {

        $orderings = array(
            'starttime' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_DESCENDING
        );
        $query = $this->createQuery();
        $query->setOrderings($orderings);
        $query->getQuerySettings()->setRespectSysLanguage(TRUE);
        // storagePid ignore
        $query->getQuerySettings()->setStoragePageIds($storagePageIds);
        $result = $query->execute();

        return $result;
    }

    // The latest comment articles by sorting starttime DESC
    public function findByUidForDashboard($commentIds) {

        $orderings = array(
            'starttime' => \TYPO3\CMS\Extbase\Persistence\QueryInterface::ORDER_DESCENDING
        );
        $query = $this->createQuery();
        $query->setOrderings($orderings);
        $query->getQuerySettings()->setRespectSysLanguage(TRUE);
        // storagePid ignore
        $query->getQuerySettings()->setRespectStoragePage(FALSE);
        $query->matching(
            $query->logicalAnd(
                $query->in('uid', $commentIds)
            )
        );
        $result = $query->execute();
        return $result;
    }

    // The latest comments articles by sorting starttime DESC
    public function latestComments()
    {
        $connection = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getConnectionForTable('tx_tbsarticlesystem_domain_model_comment');
        $queryBuilder = $connection->createQueryBuilder();
        $queryBuilder->quoteIdentifier('*');
        $query = $queryBuilder
            ->select('uid','title','starttime','teaser_text')
            ->from('tx_tbsarticlesystem_domain_model_comment')
            ->where('t3ver_wsid = 0')
            ->orderBy('starttime', 'DESC')
            ->setMaxResults(5);

        $rows = $query->execute()->fetchAll();
        return $rows;
    }
}
