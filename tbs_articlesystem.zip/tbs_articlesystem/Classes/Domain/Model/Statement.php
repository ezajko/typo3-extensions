<?php
namespace Tbs\TbsArticlesystem\Domain\Model;

use phpDocumentor\Reflection\Types\Boolean;

/***
 *
 * This file is part of the "TBS article system" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <info@brettingham.de>, THE BRETTINGHAMS GMBH
 *
 ***/

/**
 * Statement
 */
class Statement extends \TYPO3\CMS\Extbase\DomainObject\AbstractEntity
{
    /**
     * @var \DateTime
     */
    protected $starttime;

    /**
     * @var \DateTime
     */
    protected $endtime;

    /**
     * title
     *
     * @var string
     */
    protected $title = '';

    /**
     * teaserText
     *
     * @var string
     */
    protected $teaserText = '';

    /**
     * leadText
     *
     * @var string
     */
    protected $leadText = '';

    /**
     * statement
     *
     * @var string
     */
    protected $statement = '';

    /**
     * isRevision
     *
     * @var bool
     */
    protected $isRevision = false;

    /**
     * isNewsletter
     *
     * @var bool
     */
    protected $isNewsletter = false;

    /**
     * isRss
     *
     * @var bool
     */
    protected $isRss = false;

    /**
     * isSearches
     *
     * @var bool
     */
    protected $isSearches = false;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Extbase\Domain\Model\Category>
     * @TYPO3\CMS\Extbase\Annotation\ORM\Cascade("remove")
     */
    protected $keywords;

    /**
     * downloads
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Extbase\Domain\Model\FileReference>
     * @TYPO3\CMS\Extbase\Annotation\ORM\Cascade("remove")
     */
    protected $downloads = null;

    /**
     * Contact
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsContact\Domain\Model\Contact>
     */
    protected $contact = null;

    /**
     * seoTitle
     *
     * @var string
     */
    protected $seoTitle = '';

    /**
     * seoDescription
     *
     * @var string
     */
    protected $seoDescription = '';

    /**
     * noIndex
     *
     * @var boolean
     */
    protected $noIndex = true;

    /**
     * noFollow
     *
     * @var boolean
     */
    protected $noFollow = true;

    /**
     * ogTitle
     *
     * @var string
     */
    protected $ogTitle = '';

    /**
     * ogDescription
     *
     * @var string
     */
    protected $ogDescription = '';

    /**
     * ogImage
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Extbase\Domain\Model\FileReference>
     * @TYPO3\CMS\Extbase\Annotation\ORM\Cascade("remove")
     */
    protected $ogImage = null;

    /**
     * twitterTitle
     *
     * @var string
     */
    protected $twitterTitle = '';

    /**
     * twitterDescription
     *
     * @var string
     */
    protected $twitterDescription = '';

    /**
     * twitterImage
     *
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Extbase\Domain\Model\FileReference>
     * @TYPO3\CMS\Extbase\Annotation\ORM\Cascade("remove")
     */
    protected $twitterImage = null;

    /**
     * twitterCard
     *
     * @var string
     */
    protected $twitterCard = '';

    /**
     * canonicalLink
     *
     * @var string
     */
    protected $canonicalLink = '';



    /**
     * __construct
     */
    public function __construct()
    {
        //Do not remove the next line: It would break the functionality
        $this->initStorageObjects();
    }

    /**
     * Initializes all ObjectStorage properties
     * Do not modify this method!
     * It will be rewritten on each save in the extension builder
     * You may modify the constructor of this class instead
     *
     * @return void
     */
    protected function initStorageObjects()
    {
        $this->contact = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->keywords = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->downloads = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->ogImage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
        $this->twitterImage = new \TYPO3\CMS\Extbase\Persistence\ObjectStorage();
    }

    /**
     * Get start time
     *
     * @return \DateTime
     */
    public function getStarttime()
    {
        return $this->starttime;
    }

    /**
     * Set start time
     *
     * @param int $starttime start time
     */
    public function setStarttime($starttime)
    {
        $this->starttime = $starttime;
    }

    /**
     * Get endtime
     *
     * @return \DateTime
     */
    public function getEndtime()
    {
        return $this->endtime;
    }

    /**
     * Set endtime
     *
     * @param int $endtime end time
     */
    public function setEndtime($endtime)
    {
        $this->endtime = $endtime;
    }


    /**
     * Returns the title
     *
     * @return string $title
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Sets the title
     *
     * @param string $title
     * @return void
     */
    public function setTitle($title)
    {
        $this->title = $title;
    }


    /**
     * Returns the teaserText
     *
     * @return string $teaserText
     */
    public function getTeaserText()
    {
        return $this->teaserText;
    }

    /**
     * Sets the teaserText
     *
     * @param string $teaserText
     * @return void
     */
    public function setTeaserText($teaserText)
    {
        $this->teaserText = $teaserText;
    }


    /**
     * Returns the leadText
     *
     * @return string $leadText
     */
    public function getLeadText()
    {
        return $this->leadText;
    }

    /**
     * Sets the leadText
     *
     * @param string $leadText
     * @return void
     */
    public function setLeadText($leadText)
    {
        $this->leadText = $leadText;
    }

    /**
     * Returns the statement
     *
     * @return string $statement
     */
    public function getStatement()
    {
        return $this->statement;
    }

    /**
     * Sets the statement
     *
     * @param string $statement
     * @return void
     */
    public function setStatement($statement)
    {
        $this->statement = $statement;
    }


    /**
     * Returns the isRevision
     *
     * @return bool $isRevision
     */
    public function getIsRevision()
    {
        return $this->isRevision;
    }

    /**
     * Sets the isRevision
     *
     * @param bool $isRevision
     * @return void
     */
    public function setIsRevision($isRevision)
    {
        $this->isRevision = $isRevision;
    }

    /**
     * Returns the boolean state of isRevision
     *
     * @return bool
     */
    public function isRevision()
    {
        return $this->isRevision;
    }


    /**
     * Returns the isNewsletter
     *
     * @return bool $isNewsletter
     */
    public function getIsNewsletter()
    {
        return $this->isNewsletter;
    }

    /**
     * Sets the isNewsletter
     *
     * @param bool $isNewsletter
     * @return void
     */
    public function setIsNewsletter($isNewsletter)
    {
        $this->isNewsletter = $isNewsletter;
    }

    /**
     * Returns the boolean state of isNewsletter
     *
     * @return bool
     */
    public function isNewsletter()
    {
        return $this->isNewsletter;
    }


    /**
     * Returns the isRss
     *
     * @return bool $isRss
     */
    public function getIsRss()
    {
        return $this->isRss;
    }

    /**
     * Sets the isRss
     *
     * @param bool $isRss
     * @return void
     */
    public function setIsRss($isRss)
    {
        $this->isRss = $isRss;
    }

    /**
     * Returns the boolean state of isRss
     *
     * @return bool
     */
    public function isRss()
    {
        return $this->isRss;
    }


    /**
     * Returns the isSearches
     *
     * @return bool $isSearches
     */
    public function getIsSearches()
    {
        return $this->isSearches;
    }

    /**
     * Sets the isSearches
     *
     * @param bool $isSearches
     * @return void
     */
    public function setIsSearches($isSearches)
    {
        $this->isSearches = $isSearches;
    }

    /**
     * Returns the boolean state of isSearches
     *
     * @return bool
     */
    public function isSearches()
    {
        return $this->isSearches;
    }


    /**
     * Get keywords
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getKeywords()
    {
        return $this->keywords;
    }

    /**
     * Set keywords
     *
     * @param  \TYPO3\CMS\Extbase\Persistence\ObjectStorage $keywords
     */
    public function setKeywords($keywords)
    {
        $this->keywords = $keywords;
    }


    /**
     * Returns the downloads
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Extbase\Domain\Model\FileReference> $downloads
     */
    public function getDownloads()
    {
        return $this->downloads;
    }

    /**
     * Sets the downloads
     *
     * @param \TYPO3\CMS\Extbase\Domain\Model\FileReference $downloads
     * @return void
     */
    public function setDownloads(\TYPO3\CMS\Extbase\Domain\Model\FileReference $downloads)
    {
        $this->downloads = $downloads;
    }

    /**
     * Adds a contact
     *
     * @param \Tbs\TbsContact\Domain\Model\Contact $contact
     * @return void
     */
    public function addContact(\Tbs\TbsContact\Domain\Model\Contact $contact)
    {
        $this->contact->attach($contact);
    }


    /**
     * Removes a Contact
     *
     * @param \Tbs\TbsContact\Domain\Model\Contact $contact The Contact to be removed
     * @return void
     */
    public function removeContact(\Tbs\TbsContact\Domain\Model\Contact $contact)
    {
        $this->contact->detach($contact);
    }

    /**
     * Returns the contact
     *
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsContact\Domain\Model\Contact> $contact
     */
    public function getContact()
    {
        return $this->contact;
    }

    /**
     * Sets the contact
     *
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\Tbs\TbsContact\Domain\Model\Contact> $contact
     * @return void
     */
    public function setContact(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $contact)
    {
        $this->contact = $contact;
    }

    /**
     * @return string
     */
    public function getSeoTitle(): string
    {
        return $this->seoTitle;
    }

    /**
     * @param string $seoTitle
     */
    public function setSeoTitle(string $seoTitle)
    {
        $this->seoTitle = $seoTitle;
    }

    /**
     * @return string
     */
    public function getSeoDescription(): string
    {
        return $this->seoDescription;
    }

    /**
     * @param string $seoDescription
     */
    public function setSeoDescription(string $seoDescription)
    {
        $this->seoDescription = $seoDescription;
    }

    /**
     * @return Boolean
     */
    public function getNoIndex(): Boolean
    {
        return $this->noIndex;
    }

    /**
     * @param Boolean $noIndex
     */
    public function setNoIndex(Boolean $noIndex)
    {
        $this->noIndex = $noIndex;
    }

    /**
     * @return Boolean
     */
    public function getNoFollow(): Boolean
    {
        return $this->noFollow;
    }

    /**
     * @param Boolean $noFollow
     */
    public function setNoFollow(Boolean $noFollow)
    {
        $this->noFollow = $noFollow;
    }

    /**
     * @return string
     */
    public function getOgTitle(): string
    {
        return $this->ogTitle;
    }

    /**
     * @param string $ogTitle
     */
    public function setOgTitle(string $ogTitle)
    {
        $this->ogTitle = $ogTitle;
    }

    /**
     * @return string
     */
    public function getOgDescription(): string
    {
        return $this->ogDescription;
    }

    /**
     * @param string $ogDescription
     */
    public function setOgDescription(string $ogDescription)
    {
        $this->ogDescription = $ogDescription;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getOgImage(): \TYPO3\CMS\Extbase\Persistence\ObjectStorage
    {
        return $this->ogImage;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $ogImage
     */
    public function setOgImage(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $ogImage)
    {
        $this->ogImage = $ogImage;
    }

    /**
     * @return string
     */
    public function getTwitterTitle(): string
    {
        return $this->twitterTitle;
    }

    /**
     * @param string $twitterTitle
     */
    public function setTwitterTitle(string $twitterTitle)
    {
        $this->twitterTitle = $twitterTitle;
    }

    /**
     * @return string
     */
    public function getTwitterDescription(): string
    {
        return $this->twitterDescription;
    }

    /**
     * @param string $twitterDescription
     */
    public function setTwitterDescription(string $twitterDescription)
    {
        $this->twitterDescription = $twitterDescription;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getTwitterImage(): \TYPO3\CMS\Extbase\Persistence\ObjectStorage
    {
        return $this->twitterImage;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $twitterImage
     */
    public function setTwitterImage(\TYPO3\CMS\Extbase\Persistence\ObjectStorage $twitterImage)
    {
        $this->twitterImage = $twitterImage;
    }

    /**
     * @return string
     */
    public function getTwitterCard(): string
    {
        return $this->twitterCard;
    }

    /**
     * @param string $twitterCard
     */
    public function setTwitterCard(string $twitterCard)
    {
        $this->twitterCard = $twitterCard;
    }

    /**
     * @return string
     */
    public function getCanonicalLink(): string
    {
        return $this->canonicalLink;
    }

    /**
     * @param string $canonicalLink
     */
    public function setCanonicalLink(string $canonicalLink)
    {
        $this->canonicalLink = $canonicalLink;
    }

    /**
     * @return int
     */
    public function getLocalizedUid()
    {
        return $this->_localizedUid;
    }

    /**
     * @param int $localizedUid
     */
    public function setLocalizedUid($localizedUid)
    {
        $this->_localizedUid = $localizedUid;
    }

}
