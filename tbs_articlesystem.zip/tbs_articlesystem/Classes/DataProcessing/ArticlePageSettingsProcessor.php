<?php
namespace Tbs\TbsArticlesystem\DataProcessing ;

/*
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */


use Tbs\TbsArticlesystem\Service\ArticlePageSettings;
use Tbs\TbsArticlesystem\Service\MediaArticlePageSettings;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Frontend\ContentObject\ContentObjectRenderer;
use TYPO3\CMS\Frontend\ContentObject\DataProcessorInterface;


class ArticlePageSettingsProcessor implements DataProcessorInterface
{

    /**
     * Teaserimage & downloads pdf object for article system
     */
    public function process(ContentObjectRenderer $cObj, array $contentObjectConfiguration, array $processorConfiguration, array $processedData)
    {

        if( $processedData['data']['doktype'] >= 150 && $processedData['data']['doktype'] <= 159) {

            $processedData['data']['hashtagsLink'] = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['hashtags.']['link'];

            // magazine article footer teaser from typoscript constant
            if($processedData['data']['doktype'] == 152){
                $processedData['data']['magazineLink'] = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['magazineNewsletter.']['link'];
                $processedData['data']['magazineHeadline'] = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['magazineNewsletter.']['headline'];
                $processedData['data']['magazineDescription'] = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['magazineNewsletter.']['description'];
                $processedData['data']['magazineButton'] = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['magazineNewsletter.']['button'];
                $processedData['data']['magazineUrlAppleAppStore'] = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['magazineNewsletter.']['urlAppleAppStore'];
                $processedData['data']['magazineUrlGooglePlayStore'] = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['magazineNewsletter.']['urlGooglePlayStore'];
            }else{
                $processedData['data']['newsletterLink'] = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['newsletter.']['link'];
                $processedData['data']['newsletterHeadline'] = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['newsletter.']['headline'];
                $processedData['data']['newsletterDescription'] = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['newsletter.']['description'];
                $processedData['data']['newsletterButton'] = $GLOBALS['TSFE']->tmpl->setup_constants['plugin.']['tx_tbs_articlesystem.']['newsletter.']['button'];
            }



            /*
             * processing settings of Article
             */
            $articleSettings = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(ArticlePageSettings::class);

            /*
             * Statistic Article
             */
            if($processedData['data']['doktype'] == 156){
                $processedData['data']['statisticChart'] = $articleSettings->getStatistic($processedData['data']['tx_tbs_articlesystem_statistic']);
            }

            /*
             * Teaser Image of Article
             */
            if ($processedData['data']['tx_tbs_articlesystem_teaser_image'] != null) {
                $image = $articleSettings->getTeaserImage($processedData['data']['uid'], 'pages',
                    'tx_tbs_articlesystem_teaser_image');
                $processedData['data']['teaserImage'] = $image;
            }

            /*
             * Donwloads for Article
             */
            if ($processedData['data']['tx_tbs_articlesystem_download'] != null) {
                $downloads = $articleSettings->getContentFiles($processedData['data']['uid'], 'pages',
                    'tx_tbs_articlesystem_download');
                $processedData['data']['downloads'] = $downloads;
            }

            /**
             * this field is added because of the requirement of change and there is no way to put it required
             * Donwloads for Article
            */
            if ($processedData['data']['tx_tbs_articlesystem_download_record'] != null) {
                $downloads = $articleSettings->getContentFiles($processedData['data']['uid'], 'pages',
                    'tx_tbs_articlesystem_download_record');
                $processedData['data']['downloads'] = $downloads;

            }

            /*
             * Roof line handling
             * Dynamic Roof line for positionpaper
             */
            if(empty($processedData['data']['tx_tbs_articlesystem_roof_line']) &&  $processedData['data']['doktype'] != 154  &&  $processedData['data']['doktype'] != 155 ){
                $roofLine = $articleSettings->getTitleOfParentPage($processedData['data']['pid']);
                $processedData['data']['tx_tbs_articlesystem_roof_line'] = $roofLine;
            }

            /*
            * Media article
            */
            if ($processedData['data']['tx_tbs_articlesystem_media_data'] != null) {

                // --- Process the elemenet of media article ---
                $mediaContentElement    = $this->getMediaArticle($processedData);
                $processedData['data']['mediasData'] = $mediaContentElement;
            }

            /*
             * Teaser Image of Magazine Article
             */
            if ($processedData['data']['tx_tbs_articlesystem_magazine_teaser_image'] != null) {
                $imageMagazine = $articleSettings->getTeaserImage($processedData['data']['uid'], 'pages',
                    'tx_tbs_articlesystem_magazine_teaser_image');
                $processedData['data']['magazineTeaserImage'] = $imageMagazine;
            }

            /*
            * Images for Positions Paper
            */
            if ($processedData['data']['tx_tbs_articlesystem_images'] != null) {
                $imageGallery = $articleSettings->getTeaserImage($processedData['data']['uid'], 'pages',
                    'tx_tbs_articlesystem_images',true);
                $processedData['data']['articleImages'] = $imageGallery;
            }
        }
        return $processedData;
    }


    /**
     * finds $processedData for the article Media
     * @param $processedData
     * @return array
     */
    public function getMediaArticle($processedData)
    {
        $medias = array();
        $mediaArticleSettings = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(MediaArticlePageSettings::class);
        $medias = $mediaArticleSettings->getArticlesystemMediaData($processedData['data']['uid']);
        return $medias;
    }


}
