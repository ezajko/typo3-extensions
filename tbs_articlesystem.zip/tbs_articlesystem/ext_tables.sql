#
# Table structure for table 'pages'
#
CREATE TABLE pages (
	tx_tbs_articlesystem_teaser_text text,
	tx_tbs_articlesystem_teaser_image tinyint(2) DEFAULT '0' NOT NULL,
    tx_tbs_articlesystem_date int(11) DEFAULT '0' NOT NULL,
    tx_tbs_articlesystem_is_revision smallint(5) unsigned DEFAULT '0' NOT NULL,
    tx_tbs_articlesystem_is_rss smallint(5) unsigned DEFAULT '0' NOT NULL,
    tx_tbs_articlesystem_download int(11) DEFAULT '0',
    -- this field is added because of the requirement of change and there is no way to put it required
    tx_tbs_articlesystem_download_record int(11) DEFAULT '0',
    tx_tbs_articlesystem_keywords int(11) DEFAULT '0' NOT NULL,
    tx_tbs_articlesystem_roof_line varchar(255) DEFAULT '' NOT NULL,
    tx_tbs_articlesystem_sub_headline text,
    tx_tbs_articlesystem_lead_text text,
    tx_tbs_articlesystem_media_data varchar(255) DEFAULT '' NOT NULL,
    tx_tbs_articlesystem_magazine_teaser_image tinyint(2) DEFAULT '0' NOT NULL,
    tx_tbs_articlesystem_images varchar(255) DEFAULT '' NOT NULL,
    tx_tbs_articlesystem_statistic int(11) DEFAULT '0',

);

#
# Table structure for table 'tx_tbs_articlesystem_media_data'
#
CREATE TABLE tx_tbs_articlesystem_media_data (
    uid int(11) NOT NULL auto_increment,
    pid int(11) DEFAULT '0' NOT NULL,
    tstamp int(11) DEFAULT '0' NOT NULL,
    crdate int(11) DEFAULT '0' NOT NULL,
    cruser_id int(11) DEFAULT '0' NOT NULL,
    sys_language_uid int(11) DEFAULT '0' NOT NULL,
    l10n_parent int(11) DEFAULT '0' NOT NULL,
    l10n_diffsource mediumtext,
    t3ver_oid int(11) DEFAULT '0' NOT NULL,
    t3ver_id int(11) DEFAULT '0' NOT NULL,
    t3_origuid int(11) DEFAULT '0' NOT NULL,
    t3ver_wsid int(11) DEFAULT '0' NOT NULL,
    t3ver_label varchar(30) DEFAULT '' NOT NULL,
    t3ver_state tinyint(4) DEFAULT '0' NOT NULL,
    t3ver_stage tinyint(4) DEFAULT '0' NOT NULL,
    t3ver_count int(11) DEFAULT '0' NOT NULL,
    t3ver_tstamp int(11) DEFAULT '0' NOT NULL,
    t3ver_move_id int(11) DEFAULT '0' NOT NULL,
    sorting int(10) DEFAULT '0' NOT NULL,
    deleted tinyint(4) DEFAULT '0' NOT NULL,
    hidden tinyint(4) DEFAULT '0' NOT NULL,
    parent int(11) DEFAULT '0' NOT NULL,

    tx_tbs_articlesystem_media_type smallint(1) DEFAULT '0' NOT NULL,
    tx_tbs_articlesystem_media_download int(11) DEFAULT '0',
    tx_tbs_articlesystem_media_gallery_image int(11) DEFAULT '0',
    tx_tbs_articlesystem_media_video_poster int(11) DEFAULT '0',
    tx_tbs_articlesystem_media_video int(11) DEFAULT '0' NOT NULL,
    tx_tbs_articlesystem_media_video_has_subtitle smallint(5),
    tx_tbs_articlesystem_media_video_transcript  text,
    tx_tbs_articlesystem_media_image int(11) DEFAULT '0',

    tx_tbs_articlesystem_media_audio_type smallint(5),
    tx_tbs_articlesystem_media_audio int(11) DEFAULT '0' NOT NULL,
    tx_tbs_articlesystem_media_audio_transcript  text,
    tx_tbs_articlesystem_media_audio_embeded  text,

    PRIMARY KEY (uid),
    KEY parent (pid)
);

#
# Table structure for table 'tx_tbsarticlesystem_domain_model_pressrelease'
#
CREATE TABLE tx_tbsarticlesystem_domain_model_pressrelease (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	title text,
	teaser_text text,
	lead_text text,
	press_release text,
    keywords int(11) DEFAULT '0' NOT NULL,
    is_revision smallint(5) unsigned DEFAULT '0' NOT NULL,
    is_rss smallint(5) unsigned DEFAULT '0' NOT NULL,
    downloads int(11) DEFAULT '0',
    contact int(11) unsigned DEFAULT '0' NOT NULL,
	slug varchar(255) DEFAULT '' NOT NULL,
	external_uid int(11) DEFAULT '0' NOT NULL,
	seo_title varchar(255) DEFAULT '' NOT NULL,
	seo_description text,
	og_title varchar(255) DEFAULT '' NOT NULL,
	og_description text,
	og_image int(11) unsigned DEFAULT '0' NOT NULL,
	twitter_title varchar(255) DEFAULT '' NOT NULL,
	twitter_description text,
	twitter_image int(11) unsigned DEFAULT '0' NOT NULL,
	twitter_card varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
	deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,
	starttime int(11) unsigned DEFAULT '0' NOT NULL,
	endtime int(11) unsigned DEFAULT '0' NOT NULL,

	t3ver_oid int(11) DEFAULT '0' NOT NULL,
	t3ver_id int(11) DEFAULT '0' NOT NULL,
	t3ver_wsid int(11) DEFAULT '0' NOT NULL,
	t3ver_label varchar(255) DEFAULT '' NOT NULL,
	t3ver_state smallint(6) DEFAULT '0' NOT NULL,
	t3ver_stage int(11) DEFAULT '0' NOT NULL,
	t3ver_count int(11) DEFAULT '0' NOT NULL,
	t3ver_tstamp int(11) DEFAULT '0' NOT NULL,
	t3ver_move_id int(11) DEFAULT '0' NOT NULL,
	sorting int(11) DEFAULT '0' NOT NULL,

	sys_language_uid int(11) DEFAULT '0' NOT NULL,
	l10n_parent int(11) DEFAULT '0' NOT NULL,
	l10n_diffsource mediumblob,
	l10n_state text,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY t3ver_oid (t3ver_oid,t3ver_wsid),
	KEY language (l10n_parent,sys_language_uid)

);



#
# Table structure for table 'tx_tbsarticlesystem_domain_model_statement'
#
CREATE TABLE tx_tbsarticlesystem_domain_model_statement (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	title text,
	teaser_text text,
	lead_text text,
	statement text,
    keywords int(11) DEFAULT '0' NOT NULL,
    is_revision smallint(5) unsigned DEFAULT '0' NOT NULL,
    is_rss smallint(5) unsigned DEFAULT '0' NOT NULL,
    downloads int(11) DEFAULT '0',
    contact int(11) unsigned DEFAULT '0' NOT NULL,
	slug varchar(255) DEFAULT '' NOT NULL,
	external_uid int(11) DEFAULT '0' NOT NULL,
	seo_title varchar(255) DEFAULT '' NOT NULL,
	seo_description text,
	og_title varchar(255) DEFAULT '' NOT NULL,
	og_description text,
	og_image int(11) unsigned DEFAULT '0' NOT NULL,
	twitter_title varchar(255) DEFAULT '' NOT NULL,
	twitter_description text,
	twitter_image int(11) unsigned DEFAULT '0' NOT NULL,
	twitter_card varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
	deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,
	starttime int(11) unsigned DEFAULT '0' NOT NULL,
	endtime int(11) unsigned DEFAULT '0' NOT NULL,

	t3ver_oid int(11) DEFAULT '0' NOT NULL,
	t3ver_id int(11) DEFAULT '0' NOT NULL,
	t3ver_wsid int(11) DEFAULT '0' NOT NULL,
	t3ver_label varchar(255) DEFAULT '' NOT NULL,
	t3ver_state smallint(6) DEFAULT '0' NOT NULL,
	t3ver_stage int(11) DEFAULT '0' NOT NULL,
	t3ver_count int(11) DEFAULT '0' NOT NULL,
	t3ver_tstamp int(11) DEFAULT '0' NOT NULL,
	t3ver_move_id int(11) DEFAULT '0' NOT NULL,
	sorting int(11) DEFAULT '0' NOT NULL,

	sys_language_uid int(11) DEFAULT '0' NOT NULL,
	l10n_parent int(11) DEFAULT '0' NOT NULL,
	l10n_diffsource mediumblob,
	l10n_state text,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY t3ver_oid (t3ver_oid,t3ver_wsid),
	KEY language (l10n_parent,sys_language_uid)

);




#
# Table structure for table 'tx_tbsarticlesystem_domain_model_comment'
#
CREATE TABLE tx_tbsarticlesystem_domain_model_comment (

	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	title text,
	teaser_text text,
	lead_text text,
	comment text,
    keywords int(11) DEFAULT '0' NOT NULL,
    is_revision smallint(5) unsigned DEFAULT '0' NOT NULL,
    is_rss smallint(5) unsigned DEFAULT '0' NOT NULL,
    downloads int(11) DEFAULT '0',
    contact int(11) unsigned DEFAULT '0' NOT NULL,
	slug varchar(255) DEFAULT '' NOT NULL,
	seo_title varchar(255) DEFAULT '' NOT NULL,
	seo_description text,
	og_title varchar(255) DEFAULT '' NOT NULL,
	og_description text,
	og_image int(11) unsigned DEFAULT '0' NOT NULL,
	twitter_title varchar(255) DEFAULT '' NOT NULL,
	twitter_description text,
	twitter_image int(11) unsigned DEFAULT '0' NOT NULL,
	twitter_card varchar(255) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
	deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,
	starttime int(11) unsigned DEFAULT '0' NOT NULL,
	endtime int(11) unsigned DEFAULT '0' NOT NULL,

	t3ver_oid int(11) DEFAULT '0' NOT NULL,
	t3ver_id int(11) DEFAULT '0' NOT NULL,
	t3ver_wsid int(11) DEFAULT '0' NOT NULL,
	t3ver_label varchar(255) DEFAULT '' NOT NULL,
	t3ver_state smallint(6) DEFAULT '0' NOT NULL,
	t3ver_stage int(11) DEFAULT '0' NOT NULL,
	t3ver_count int(11) DEFAULT '0' NOT NULL,
	t3ver_tstamp int(11) DEFAULT '0' NOT NULL,
	t3ver_move_id int(11) DEFAULT '0' NOT NULL,
	sorting int(11) DEFAULT '0' NOT NULL,

	sys_language_uid int(11) DEFAULT '0' NOT NULL,
	l10n_parent int(11) DEFAULT '0' NOT NULL,
	l10n_diffsource mediumblob,
	l10n_state text,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY t3ver_oid (t3ver_oid,t3ver_wsid),
	KEY language (l10n_parent,sys_language_uid)

);