<?php

/*
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

namespace Tbs\TbsExtranet\Domain\Model;

use TYPO3\CMS\Backend\Authentication\PasswordReset;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;
use TYPO3\CMS\Extbase\Annotation as Extbase;

class BackendUser extends \TYPO3\CMS\Extbase\Domain\Model\BackendUser
{




    /**
     * @var string
     */
    protected $userName = '';

    /**
     * @var string
     */
    protected $password = '';

    /**
     * @var string
     */
    protected $passwordRepeat = '';

    /**
     * firstname
     *
     * @var string
     */
    protected $firstName = '';

    /**
     * lastName
     *
     * @var string
     */
    protected $lastName = '';

    /**
     * position
     *
     * @var string
     */
    protected $position = '';

    /**
     * company
     *
     * @var string
     */
    protected $company = '';

    /**
     * street
     *
     * @var string
     */
    protected $street = '';

    /**
     * zip
     *
     * @var string
     */
    protected $zip = '';

    /**
     * city
     *
     * @var string
     */
    protected $city = '';

    /**
     * phone
     *
     * @var string
     */
    protected $phone = '';


    /**
     * dataPrivacy
     *
     * @var string
     * @Extbase\Validate("NotEmpty")
     */
    protected $dataPrivacy = false;

    /**
     * @var \TYPO3\CMS\Extbase\Persistence\ObjectStorage<\TYPO3\CMS\Beuser\Domain\Model\BackendUserGroup>
     */
    protected $backendUserGroups;

    /**
     * @var bool
     */
    protected $workspacePermission = false;

    /**
     * @var string
     */
    protected $options;


    /**
     * @var string
     */
    protected $workspaceId;

    /**
     * isUserFlag
     *
     * @var string
     */
    protected $isUserFlag = false;

    /**
     * isUserActiveNotificationFlag
     *
     * @var string
     */
    protected $isUserActiveNotificationFlag = false;

    /**
     * @var string
     */
    protected $lang = '';

    /**
     * @return string
     */
    public function getUserName()
    {
        return $this->userName;
    }

    /**
     * @param string $userName
     */
    public function setUserName($userName)
    {
        $this->userName = $userName;
    }

    /**
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param string $password
     */
    public function setPassword($password)
    {
        $this->password = $password;
    }

    /**
     * @return string
     */
    public function getPasswordRepeat()
    {
        return $this->passwordRepeat;
    }

    /**
     * @param string $passwordRepeat
     */
    public function setPasswordRepeat($passwordRepeat)
    {
        $this->passwordRepeat = $passwordRepeat;
    }



    /**
     * @return string
     */
    public function getFirstName()
    {
        return $this->firstName;
    }

    /**
     * @param string $firstName
     */
    public function setFirstName($firstName)
    {
        $this->firstName = $firstName;
    }

    /**
     * @return string
     */
    public function getLastName()
    {
        return $this->lastName;
    }

    /**
     * @param string $lastName
     */
    public function setLastName($lastName)
    {
        $this->lastName = $lastName;
    }

    /**
     * @return string
     */
    public function getPosition()
    {
        return $this->position;
    }

    /**
     * @param string $position
     */
    public function setPosition($position)
    {
        $this->position = $position;
    }

    /**
     * @return string
     */
    public function getCompany()
    {
        return $this->company;
    }

    /**
     * @param string $company
     */
    public function setCompany($company)
    {
        $this->company = $company;
    }

    /**
     * @return string
     */
    public function getStreet()
    {
        return $this->street;
    }

    /**
     * @param string $street
     */
    public function setStreet($street)
    {
        $this->street = $street;
    }

    /**
     * @return string
     */
    public function getZip()
    {
        return $this->zip;
    }

    /**
     * @param string $zip
     */
    public function setZip($zip)
    {
        $this->zip = $zip;
    }

    /**
     * @return string
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * @param string $city
     */
    public function setCity($city)
    {
        $this->city = $city;
    }

    /**
     * @return string
     */
    public function getPhone()
    {
        return $this->phone;
    }

    /**
     * @param string $phone
     */
    public function setPhone($phone)
    {
        $this->phone = $phone;
    }

    /**
     * @return string
     */
    public function getDataPrivacy()
    {
        return $this->dataPrivacy;
    }

    /**
     * @param string $dataPrivacy
     */
    public function setDataPrivacy($dataPrivacy)
    {
        $this->dataPrivacy = $dataPrivacy;
    }

    /**
     * @return \TYPO3\CMS\Extbase\Persistence\ObjectStorage
     */
    public function getBackendUserGroups()
    {
        return $this->backendUserGroups;
    }

    /**
     * @param \TYPO3\CMS\Extbase\Persistence\ObjectStorage $backendUserGroups
     */
    public function setBackendUserGroups($backendUserGroups)
    {
        $this->backendUserGroups = $backendUserGroups;
    }

    /**
     * @return bool
     */
    public function isWorkspacePermission()
    {
        return $this->workspacePermission;
    }

    /**
     * @param bool $workspacePermission
     */
    public function setWorkspacePermission($workspacePermission)
    {
        $this->workspacePermission = $workspacePermission;
    }

    /**
     * @return string
     */
    public function getOptions()
    {
        return $this->options;
    }

    /**
     * @param string $options
     */
    public function setOptions($options)
    {
        $this->options = $options;
    }

    /**
     * @return string
     */
    public function getWorkspaceId()
    {
        return $this->workspaceId;
    }

    /**
     * @param string $workspaceId
     */
    public function setWorkspaceId($workspaceId)
    {
        $this->workspaceId = $workspaceId;
    }

    /**
     * @return string
     */
    public function getIsUserFlag()
    {
        return $this->isUserFlag;
    }

    /**
     * @param string $isUserFlag
     */
    public function setIsUserFlag($isUserFlag)
    {
        $this->isUserFlag = $isUserFlag;
    }

    /**
     * @return string
     */
    public function getIsUserActiveNotificationFlag()
    {
        return $this->isUserActiveNotificationFlag;
    }

    /**
     * @param string $isUserActiveNotificationFlag
     */
    public function setIsUserActiveNotificationFlag($isUserActiveNotificationFlag)
    {
        $this->isUserActiveNotificationFlag = $isUserActiveNotificationFlag;
    }

    /**
     * @return string
     */
    public function getLang()
    {
        return $this->lang;
    }

    /**
     * @param string $lang
     */
    public function setLang($lang)
    {
        $this->lang = $lang;
    }




}
