<?php

/*
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

namespace Tbs\TbsExtranet\Domain\Repository;



use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Database\Query\Restriction\DefaultRestrictionContainer;

class BackendUserRepository extends \TYPO3\CMS\Extbase\Domain\Repository\BackendUserRepository
{

    // --- Check Username exists ---
    public function equalUserName($userName)
    {
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getQueryBuilderForTable('be_users');
        $queryBuilder
            ->getRestrictions()
            ->removeAll();
        $query = $queryBuilder
            ->select('*')
            ->from('be_users')
            ->where('deleted=0 AND username="'.$userName.'"');

        $rows = $query->execute()->fetchAll();
        return $rows;
    }

    // --- Check E-Mail exists ---
    public function equalEmail($email)
    {
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getQueryBuilderForTable('be_users');
        $queryBuilder
            ->getRestrictions()
            ->removeAll();
        $query = $queryBuilder
            ->select('*')
            ->from('be_users')
            ->where('deleted=0 AND email="'.$email.'"');

        $rows = $query->execute()->fetchAll();
        return $rows;
    }

    // --- find record by UID ---
    public function findByUID($uid)
    {
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getQueryBuilderForTable('be_users');
        $queryBuilder
            ->getRestrictions()
            ->removeAll();
        $query = $queryBuilder
            ->select('*')
            ->from('be_users')
            ->where('uid='.$uid);

        $rows = $query->execute()->fetchAll();
        return $rows[0];
    }

    /**
     * update user activate notification flage
     */
    public function updateActivationNotificaionFlag($uid)
    {
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)->getConnectionForTable('be_users')->createQueryBuilder();
        $affectedRows = $queryBuilder
            ->update('be_users')
            ->where(
                $queryBuilder->expr()->eq('uid', $uid)
            )
            ->set('tx_tbs_extranet_user_activate_notifiaction_flag', 1)
            ->execute();

        return $affectedRows;
    }

}
