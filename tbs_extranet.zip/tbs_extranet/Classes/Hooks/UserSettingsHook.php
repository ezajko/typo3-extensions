<?php
namespace Tbs\TbsExtranet\Hooks;

use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;
use TYPO3\CMS\Core\Messaging\FlashMessage;
use TYPO3\CMS\Core\Messaging\FlashMessageService;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use Tbs\TbsProvider\Service\PrivacyPolicyService;

class UserSettingsHook implements \TYPO3\CMS\Core\SingletonInterface
{

    public function processDatamap_preProcessFieldArray(array &$fieldArray, $table, $id, \TYPO3\CMS\Core\DataHandling\DataHandler &$pObj
    ) {

        $backendConfiguration = GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('tbs_extranet');
        if($fieldArray['tx_tbs_extranet_privacy'] == '0'
        && $GLOBALS['BE_USER']->user['usergroup'] == $backendConfiguration['setUserGroup']
        && $table == 'be_users' ){
            $title = 'Datenschutzbestimmungen';
            $message = 'Sie müssen die Datenschutzbestimmungen akzeptieren, wenn Sie Ihre Benutzereinstellungen ändern.';
            $foo = GeneralUtility::makeInstance(
                FlashMessage::class,
                $message,
                $title,
                FlashMessage::ERROR
            );

//            DebuggerUtility::var_dump($pObj);
            $flashMessageService = GeneralUtility::makeInstance(FlashMessageService::class);
            $defaultFlashMessageQueue = $flashMessageService->getMessageQueueByIdentifier();
            $defaultFlashMessageQueue->dequeue();
            $defaultFlashMessageQueue->enqueue($foo);


        }
    }

    public function processDatamap_postProcessFieldArray($status, $table, $id, array $fieldArray, \TYPO3\CMS\Core\DataHandling\DataHandler &$pObj){

        $flashMessageService = GeneralUtility::makeInstance(FlashMessageService::class);
        $defaultFlashMessageQueue = $flashMessageService->getMessageQueueByIdentifier();
        $defaultFlashMessageQueue->dequeue();

    }

    public function processDatamap_afterDatabaseOperations($status, $table, $id, array $fieldArray, \TYPO3\CMS\Core\DataHandling\DataHandler &$pObj) {


        $backendConfiguration = GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('tbs_extranet');
        
        if(!empty($pObj->datamap[$table][$id]['tx_tbs_extranet_privacy'])
            && $GLOBALS['BE_USER']->user['usergroup'] == $backendConfiguration['setUserGroup']
            && $table = 'be_users' ){

            $uri = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
            $data = array(
                'id'                        => $GLOBALS['BE_USER']->user['uid'],
                'username'                  => $GLOBALS['BE_USER']->user['username'],
                'email'                     => $GLOBALS['BE_USER']->user['email'],
                'tx_tbs_extranet_privacy'   => $GLOBALS['BE_USER']->user['tx_tbs_extranet_privacy'],
                'date'                      => date(DATE_ISO8601)
            );
            $tbsLogger = GeneralUtility::makeInstance(PrivacyPolicyService::class);
            if(!empty($tbsLogger)){
                $foo = $tbsLogger->setPrivacyPolicyProperties($data,$uri,$GLOBALS['BE_USER']->user['email'], 'backend_user_settings', $backendConfiguration['pageIdDataPrivacy']);
            }
        }
    }

}