<?php
namespace Tbs\TbsExtranet\Hooks\RecordListView;


use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Frontend\ContentObject\ContentObjectRenderer;



class ExtranetJobOfferRecordListPreviewLinkRenderer implements \TYPO3\CMS\Recordlist\RecordList\RecordListHookInterface{

    /**
     * Modifies Web>List clip icons (copy, cut, paste, etc.) of a displayed row
     *
     * @param string $table The current database table
     * @param array $row The current record row
     * @param array $cells The default clip-icons to get modified
     * @param object $parentObject Instance of calling object
     * @return array The modified clip-icons
     */
    public function makeClip($table, $row, $cells, &$parentObject){

        $backendConfiguration = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('tbs_extranet');
        $targetPageId = $backendConfiguration['setJobOfferDetailPid'];

        // set arguments
        $args = [
            'tx_tbsjoboffer_jobofferdetail[jobofferPreview]' => $row['uid'],
            'tx_tbsjoboffer_jobofferdetail[action]' => 'show',
            'tx_tbsjoboffer_jobofferdetail[controller]' => 'Joboffer',
            'tx_tbsjoboffer_jobofferdetail[preview]' => '1',
        ];

        // generate frontend preview link
        $uri = $this->getLink($targetPageId, $args);

        $hasAccess = false;
        $extranetUserFlag = $GLOBALS['BE_USER']->user['tx_tbs_extranet_user_flag'];

        if (!$hasAccess) {
            $cells['copy'] = $cells['copy'];
            $cells['cut'] = $cells['cut'];

            // set preview icon only for extranet users
            if($extranetUserFlag == 1){
                $cells['preview'] = '<a class="btn btn-default" href="'.$uri.'" target="_blank" title="Datensatz Preview"><span class="t3js-icon icon icon-size-small icon-state-default icon-actions-view-page"> 
                                    <span class="icon-markup"> <img src="/typo3/sysext/core/Resources/Public/Icons/T3Icons/actions/actions-view-page.svg" width="16" height="16" alt="" />
                                    </span> </span></a>';
            }

        }
        return $cells;
    }

    /**
     * Modifies Web>List control icons of a displayed row
     *
     * @param string $table The current database table
     * @param array $row The current record row
     * @param array $cells The default control-icons to get modified
     * @param object $parentObject Instance of calling object
     * @return array The modified control-icons
     */
    public function makeControl($table, $row, $cells, &$parentObject) {

        $hasAccess = false;
        if (!$hasAccess) {
            $cells['edit'] = $cells['edit'];
            $cells['hide'] = $cells['hide'];
            $cells['delete'] = $cells['delete'];
            $cells['viewBig'] = $cells['viewBig'];
            $cells['history'] = $cells['history'];
        }
        return $cells;
    }

    /**
     * Modifies Web>List header row columns/cells
     *
     * @param string $table The current database table
     * @param array $currentIdList Array of the currently displayed uids of the table
     * @param array $headerColumns An array of rendered cells/columns
     * @param object $parentObject Instance of calling (parent) object
     * @return array Array of modified cells/columns
     */
    public function renderListHeader($table, $currentIdList, $headerColumns, &$parentObject){

    }

    /**
     * Modifies Web>List header row clipboard/action icons
     *
     * @param string $table The current database table
     * @param array $currentIdList Array of the currently displayed uids of the table
     * @param array $cells An array of the current clipboard/action icons
     * @param object $parentObject Instance of calling (parent) object
     * @return array Array of modified clipboard/action icons
     */
    public function renderListHeaderActions($table, $currentIdList, $cells, &$parentObject){
        return $cells;
    }

    private function getLink($targetPageId, $args){

        // create uri by typolink helper
        $cObj = GeneralUtility::makeInstance(ContentObjectRenderer::class);
        $uri = $cObj->typolink_URL([
            'parameter' => $targetPageId,
            'linkAccessRestrictedPages' => 1,
            'additionalParams' => GeneralUtility::implodeArrayForUrl(NULL, $args),
        ]);

        return $uri;
    }

}