<?php
namespace Tbs\TbsExtranet\Hooks\RecordListView;



use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use Tbs\TbsExtranet\Domain\Repository\BackendUserRepository;
use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;
use Tbs\TbsExtranet\Service\SentTemplateEmailExtranet;


class ExtranetUsersNotificationEmailAndUserStorage
{

    public function __construct()
    {
        $this->objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        $this->backendUserRepository = $this->objectManager->get(BackendUserRepository::class);
        $this->backendConfiguration = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('tbs_extranet');
        $this->sentTemplateEmailExtranet = $this->objectManager->get(SentTemplateEmailExtranet::class);
    }


    // Activate User Confirmation notification email
    public function processDatamap_afterDatabaseOperations($status, $table, $id, array &$fieldArray, \TYPO3\CMS\Core\DataHandling\DataHandler &$pObj)
    {
        $translate = GeneralUtility::makeInstance(LocalizationUtility::class);


        if($status == 'update' && $table == 'be_users'){
            $beUsers = $this->backendUserRepository->findByUID($id);
            $baseUrl = 'https://'.$_SERVER['HTTP_HOST'];

            // --- set recipient ---
            $recipient = array(
                'email' => $beUsers['email'],
                'name' =>  $beUsers['tx_tbs_extranet_first_name'].' '.$beUsers['tx_tbs_extranet_last_name']
            );
            $sender = array(
                'email' => $this->backendConfiguration['setSenderEmail'],
                'name' => $this->backendConfiguration['setSenderName']
            );

            $subject = $translate::translate('ActivateUserConfirmation', 'tbs_extranet');
            $templateName = 'Extranet/ActivateUserConfirmation';

            $variables = array(
                'baseUrl' => $baseUrl,
                'extension' => 'extranet'
            );


            /*
             * flag get set at the activation, does the be user get deactivated and actevated again, email not send
             */
            if($beUsers['tx_tbs_extranet_user_flag'] == 1 && $beUsers['tx_tbs_extranet_user_activate_notifiaction_flag'] == 0){
                $this->backendUserRepository->updateActivationNotificaionFlag($id);
                /*
                 * send feedback email to user
                 */
                $this->sentTemplateEmailExtranet->sentTemplateEmailExtranet($recipient, $sender, $subject, $templateName, $beUsers, $variables);

                /*
                 * set extranet user home storage
                 */
                $extranetUserStorageUid = $this->backendConfiguration['storageUidExtranetHR'];

                $createUserHomeFolderService = GeneralUtility::makeInstance(\Tbs\TbsExtranet\Service\CreateUserHomeStorage::class);
                $createUserHomeFolderService->createUserStorageFolder($extranetUserStorageUid, $beUsers['uid']);

            }
        }
    }

    // Delete User confirmation notification email
    public function processCmdmap_postProcess($command, $table, $id, $value, $dataHandler)
    {
        $translate = GeneralUtility::makeInstance(LocalizationUtility::class);


        if($command == 'delete' && $table == 'be_users'){
            $beUsers = $this->backendUserRepository->findByUID($id);
            $baseUrl = '';
            // --- set recipient ---
            $recipient = array(
                'email' => $beUsers['email'],
                'name' =>  $beUsers['tx_tbs_extranet_first_name'].' '.$beUsers['tx_tbs_extranet_last_name']
            );
            $sender = array(
                'email' => $this->backendConfiguration['setSenderEmail'],
                'name' => $this->backendConfiguration['setSenderName']
            );
            $subject = $translate::translate('DeleteUserConfirmation', 'tbs_extranet');
            $templateName = 'Extranet/DeleteUserConfirmation';

            $variables = array(
                'baseUrl' => $baseUrl,
                'extension' => 'extranet'
            );
            if($beUsers['tx_tbs_extranet_user_flag'] == 1){

                // send feedback email to user ---
                $this->sentTemplateEmailExtranet->sentTemplateEmailExtranet($recipient, $sender, $subject, $templateName, $beUsers, $variables);
            }
        }
    }

}