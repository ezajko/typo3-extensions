<?php
namespace Tbs\TbsExtranet\Hooks\RecordListView;

use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;

class ExtranetJobOfferRecordListRenderer implements \TYPO3\CMS\Backend\RecordList\RecordListGetTableHookInterface{

    /**
     * modifies the DB list query
     *
     * @param string $table The current database table
     * @param int $pageId The record's page ID
     * @param string $additionalWhereClause An additional WHERE clause
     * @param string $selectedFieldsList Comma separated list of selected fields
     * @param \TYPO3\CMS\Recordlist\RecordList\DatabaseRecordList $parentObject Parent \TYPO3\CMS\Recordlist\RecordList\DatabaseRecordList object
     */
    public function getDBlistQuery($table, $pageId, &$additionalWhereClause, &$selectedFieldsList, &$parentObject){

        $selectedFieldsList = 'stellenbezeichnung,uid,pid,hidden,starttime,endtime';
        $backendConfiguration = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('tbs_extranet');


        if(!$GLOBALS['BE_USER']->isAdmin()
            && $table == 'tx_tbsjoboffer_domain_model_joboffer'
            && strpos($GLOBALS['BE_USER']->user['usergroup'], $backendConfiguration['setUserGroup']) !== false){

            $userAdditionalWhereClause = ' AND cruser_id=' . $GLOBALS['BE_USER']->user['uid'];
            $additionalWhereClause .= $userAdditionalWhereClause;

        }

    }
}