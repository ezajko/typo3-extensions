<?php
namespace Tbs\TbsExtranet\Hooks\PageLayoutView;


use \TYPO3\CMS\Backend\View\PageLayoutViewDrawItemHookInterface;
use \TYPO3\CMS\Backend\View\PageLayoutView;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;
use TYPO3\CMS\Fluid\View\StandaloneView;

/**
 * Contains a preview rendering for the page module of CType="yourextensionkey_newcontentelement"
 */
class ExtranetPreviewRenderer implements PageLayoutViewDrawItemHookInterface
{
    /**
     * Preprocesses the preview rendering of a content element of type "My new content element"
     *
     * @param \TYPO3\CMS\Backend\View\PageLayoutView $parentObject Calling parent object
     * @param bool $drawItem Whether to draw the item using the default functionality
     * @param string $headerContent Header content
     * @param string $itemContent Item content
     * @param array $row Record row of tt_content
     *
     * @return void
     */
    public function preProcess(
        PageLayoutView &$parentObject,
        &$drawItem,
        &$headerContent,
        &$itemContent,
        array &$row
    )
    {
        switch ($row['list_type']) {
            case 'tbsextranet_tbsextranet':
                $itemContent    = $this->getContactPreviewBackend($row);
                break;
        }

        $drawItem = false;
    }

    /** Extranet Preview
     * @param $row
     * @return string
     */
    public function getContactPreviewBackend($row){

        $view = GeneralUtility::makeInstance(StandaloneView::class);
        $view->setTemplatePathAndFilename(GeneralUtility::getFileAbsFileName('EXT:tbs_extranet/Resources/Private/Templates/Backend/ExtranetPreview.html'));
        $view->assignMultiple([
            'headline' => $row['header'],
        ]);
        return $view->render();
    }

}
