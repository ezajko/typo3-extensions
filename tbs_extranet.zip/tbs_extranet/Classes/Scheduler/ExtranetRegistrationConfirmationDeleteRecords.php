<?php

namespace Tbs\TbsExtranet\Scheduler;


use TYPO3\CMS\Scheduler\Task\AbstractTask;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Database\Query\QueryBuilder;
use TYPO3\CMS\Core\Database\Query\Restriction\StartTimeRestriction;
use TYPO3\CMS\Core\Database\Query\Restriction\EndTimeRestriction;
use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/**
 * Scheduler Task for If the confirmation link is not confirmed within five working days, the registration will be automatically deleted.
 * @license http://www.gnu.org/licenses/gpl.html
 *
 */
class ExtranetRegistrationConfirmationDeleteRecords extends AbstractTask
{

    public function execute()
    {
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getQueryBuilderForTable('be_users');
        $queryBuilder
            ->getRestrictions()
            ->removeAll()
            ->add(GeneralUtility::makeInstance(StartTimeRestriction::class))
            ->add(GeneralUtility::makeInstance(EndTimeRestriction::class));
        $rows = $queryBuilder
            ->select('*')
            ->from('be_users')
            ->where('disable = 1 AND tx_tbs_extranet_user_flag = 1 AND tx_tbs_extranet_user_activate_notifiaction_flag = 0')
            ->execute()
            ->fetchAll();

        if(count($rows) > 0){
            $execute = $this->deleteUsers($rows);
        }

        return true;
    }

    public function deleteUsers($rows)
    {
        $sentTemplateEmailExtranet = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Tbs\\TbsExtranet\\Service\\SentTemplateEmailExtranet');
        $translate = GeneralUtility::makeInstance(LocalizationUtility::class);
        $backendConfiguration = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('tbs_extranet');
        foreach ($rows as $row){

            $tsTamp = $row['tstamp'];
            $currentTime = strtotime(date('Y-m-d H:i:s'));

            // count days between startdate to current date without saturday/sunday
            $days = $this->getWeekDaysCount($tsTamp, $currentTime);

            // If the confirmation link is not confirmed within five working days, the registration will be automatically deleted.
            if($days > 5){

                // --- set recipient ---
                $recipient = array(
                    'email' => $row['email'],
                    'name' =>  $row['tx_tbs_extranet_first_name'].' '.$row['tx_tbs_extranet_last_name']
                );
                $sender = array(
                    'email' => $backendConfiguration['setSenderEmail'],
                    'name' => $backendConfiguration['setSenderName']
                );


                $subject = $translate::translate('eMail.subject.NotifyAutomatedDeleteUserConfirmation', 'tbs_extranet');
                $templateName = 'Extranet/NotifyAutomatedDeleteUserConfirmation';

                $variables = array(
                    'email' => $backendConfiguration['setSenderEmail'],
                    'extension' => 'extranet'
                );
                // send feedback email to user ---
                $sentTemplateEmailExtranet->sentTemplateEmailExtranet($recipient, $sender, $subject, $templateName, $row, $variables);

                // delete extranet users record
                $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
                    ->getQueryBuilderForTable('be_users');
                $executionSucceeded = $queryBuilder
                    ->delete('be_users')
                    ->where('uid ='.$row['uid'])
                    ->execute();
            }
        }

        return $executionSucceeded;
    }


    /**
     * Getting the Weekdays count[ Excludes : Weekends]
     *
     * @param type $fromDateTimestamp
     * @param type $toDateTimestamp
     * @return int
     */
    public function getWeekDaysCount($fromDateTimestamp = null, $toDateTimestamp=null) {

        $startDateString   = date('Y-m-d', $fromDateTimestamp);
        $timestampTomorrow = strtotime('+1 day', $toDateTimestamp);
        $endDateString     = date("Y-m-d", $timestampTomorrow);
        $objStartDate      = new \DateTime($startDateString);    //intialize start date
        $objEndDate        = new \DateTime($endDateString);    //initialize end date
        $interval          = new \DateInterval('P1D');    // set the interval as 1 day
        $dateRange         = new \DatePeriod($objStartDate, $interval, $objEndDate);

        $count = 0;

        foreach ($dateRange as $eachDate) {
            if (    $eachDate->format("w") != 6
                &&  $eachDate->format("w") != 0
            ) {
                ++$count;
            }
        }
        return $count;
    }

}
