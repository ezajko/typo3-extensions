<?php

namespace Tbs\TbsExtranet\Scheduler;


use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;
use TYPO3\CMS\Core\Database\Query\Restriction\HiddenRestriction;
use TYPO3\CMS\Scheduler\Task\AbstractTask;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Database\Query\QueryBuilder;


/**
 * Scheduler Task for set hidden flag for JobOffers after 6 weeks of no changes and delete it after 24 months
 *
 */
class DeleteOutdatedExtranetJobOffers extends AbstractTask
{


    public function execute()
    {
        $backendConfiguration = GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('tbs_extranet');
        $deactivatedJobOffers = $this->getDeactivatedExtranetJobOffers($backendConfiguration['extranetJobOfferFolderPageId']);
        $toDeletedJoboffersCsv = '';

        if (!empty($deactivatedJobOffers)) {
            foreach ($deactivatedJobOffers as $deactivatedJobOffer) {
                $toDeletedJoboffersCsv .= $deactivatedJobOffer['uid'] . ',';
            }
            $toDeletedJoboffersCsv = rtrim($toDeletedJoboffersCsv, ',');

            $deleteResult = $this->deleteDeactivatedExtranetJobOffers($toDeletedJoboffersCsv);
            return $deleteResult;
        }

        return true;
    }

    /**
     * @param int $pageIdExtranetJobOffer
     * @return array
     */
    private function getDeactivatedExtranetJobOffers(int $pageIdExtranetJobOffer)
    {

        // timespamp of 24 months ago
        $tstamp24MonthAgo = strtotime("-24 month");
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getQueryBuilderForTable('tx_tbsjoboffer_domain_model_joboffer');
        $queryBuilder
            ->getRestrictions()
            ->removeByType(HiddenRestriction::class);
        $outdatedJobOffersRecords = $queryBuilder
            ->select('*')
            ->from('tx_tbsjoboffer_domain_model_joboffer')
            ->where('pid = ' . $pageIdExtranetJobOffer . ' AND tstamp < '. $tstamp24MonthAgo)
            ->execute()
            ->fetchAll();

        return $outdatedJobOffersRecords;
    }

    /**
     * @param string $toDeactivatedJoboffersCsv
     * @return bool
     */
    private function deleteDeactivatedExtranetJobOffers(string $todeletedJoboffersCsv)
    {

        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getQueryBuilderForTable('tx_tbsjoboffer_domain_model_joboffer');
        $toDeactivatedJoboffersRecords = $queryBuilder
            ->delete('tx_tbsjoboffer_domain_model_joboffer')
            ->where('uid IN (' . $todeletedJoboffersCsv . ')')
            ->execute();

        return $toDeactivatedJoboffersRecords;
    }
}
