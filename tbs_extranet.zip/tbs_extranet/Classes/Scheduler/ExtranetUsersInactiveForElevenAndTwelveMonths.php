<?php

namespace Tbs\TbsExtranet\Scheduler;


use TYPO3\CMS\Scheduler\Task\AbstractTask;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Database\Query\QueryBuilder;
use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/**
 * Scheduler Task for If a registered user is inactive for eleven months (= no login), they will receive an automatic notification by email
 * @license http://www.gnu.org/licenses/gpl.html
 *
 */
class ExtranetUsersInactiveForElevenAndTwelveMonths extends AbstractTask
{

    public function execute()
    {
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getQueryBuilderForTable('be_users');
        $rows = $queryBuilder
            ->select('*')
            ->from('be_users')
            ->where('lastlogin != 0 AND tx_tbs_extranet_user_flag = 1 AND tx_tbs_extranet_user_activate_notifiaction_flag = 1')
            ->execute()
            ->fetchAll();

        if(count($rows) > 0){
            $execute = $this->notificationInactiveElevenAndTwelveMonthsUsers($rows);
        }

        return true;
    }


    public function notificationInactiveElevenAndTwelveMonthsUsers($rows)
    {
        $sentTemplateEmailExtranet = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Tbs\\TbsExtranet\\Service\\SentTemplateEmailExtranet');
        $translate = GeneralUtility::makeInstance(LocalizationUtility::class);
        $backendConfiguration = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('tbs_extranet');

        // --- set sender ---
        $sender = array(
            'email' => $backendConfiguration['setSenderEmail'],
            'name' => $backendConfiguration['setSenderName']
        );

        // --- set email template ---
        $templateName = 'Extranet/NotifyAutomatedInactiveForElevenAndTwelveMonthsUsers';


        foreach ($rows as $row){

            $lastLogin = $row['lastlogin'];
            $currentTime = strtotime(date('Y-m-d H:i:s'));


            // Calculate months and days
            $cal = $this->dateDifference($lastLogin, $currentTime);
            $days = $cal[1];
            $months = $cal[0];

            // If a registered user is inactive for eleven months (= no login), they will receive an automatic notification by email
            if($months == 11 && $days == 0){
                // --- set recipient ---
                $recipient = array(
                    'email' => $row['email'],
                    'name' =>  $row['tx_tbs_extranet_first_name'].' '.$row['tx_tbs_extranet_last_name']
                );

                $subject = $translate::translate('eMail.subject.NotifyAutomatedInactiveForElevenMonthsUsers', 'tbs_extranet');
                $variables = array(
                    'flag' => 1,
                    'extension' => 'extranet'
                );

                // --- send notifcation email to user ---
                $executionSucceeded = $sentTemplateEmailExtranet->sentTemplateEmailExtranet($recipient, $sender, $subject, $templateName, $row, $variables);
            }

            // If a registered user is inactive for 12 months and 10 days, the user account is automatically deleted. In this case, the user receives an automated email
            if($months == 12 && $days == 10){
                // --- set recipient ---
                $recipient = array(
                    'email' => $row['email'],
                    'name' =>  $row['tx_tbs_extranet_first_name'].' '.$row['tx_tbs_extranet_last_name']
                );
                $subject = $translate::translate('eMail.subject.NotifyAutomatedInactiveForTwelveMonthsUsers', 'tbs_extranet');
                $variables = array(
                    'flag' => 2,
                    'extension' => 'extranet'
                );

                // --- send notifcation email to user ---
                $sentTemplateEmailExtranet->sentTemplateEmailExtranet($recipient, $sender, $subject, $templateName, $row, $variables);

                // delete extranet users record
                $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
                    ->getQueryBuilderForTable('be_users');
                $executionSucceeded = $queryBuilder
                    ->delete('be_users')
                    ->where('uid ='.$row['uid'])
                    ->execute();
            }

        }

        return $executionSucceeded;
    }

    // Calculate years, months and days
    public function dateDifference($startDate, $endDate)
    {
        $months = 0;
        while (strtotime('+1 MONTH', $startDate) < $endDate) {
            $months++;
            $startDate = strtotime('+1 MONTH', $startDate);
        }
        $days = round(($endDate - $startDate) / (60*60*24));

        return array($months, $days);
    }


}
