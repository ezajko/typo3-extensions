<?php

namespace Tbs\TbsExtranet\Scheduler;


use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;
use TYPO3\CMS\Scheduler\Task\AbstractTask;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Database\Query\QueryBuilder;


/**
 * Scheduler Task for set hidden flag for JobOffers after 6 weeks of no changes and delete it after 24 months
 *
 */
class DeactivateOutdatedExtranetJobOffers extends AbstractTask
{


    public function execute()
    {
        $backendConfiguration = GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('tbs_extranet');
        $outdatedJobOffers = $this->getOutdatedExtranetJobOffers($backendConfiguration['extranetJobOfferFolderPageId']);
        $toDeactivatedJoboffersCsv = '';

        if (!empty($outdatedJobOffers)) {
            foreach ($outdatedJobOffers as $outdatedJobOffer) {
                $toDeactivatedJoboffersCsv .= $outdatedJobOffer['uid'] . ',';
            }
            $toDeactivatedJoboffersCsv = rtrim($toDeactivatedJoboffersCsv, ',');

            $updateResult = $this->deactivateOutdatedExtranetJobOffers($toDeactivatedJoboffersCsv);

            return $updateResult;
        }

        return true;
    }

    /**
     * @param int $pageIdExtranetJobOffer
     * @return array
     */
    private function getOutdatedExtranetJobOffers(int $pageIdExtranetJobOffer)
    {

        // timespamp of 6 weeks ago
        $tstampSixWeeksAgo = strtotime("-6 weeks");
        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getQueryBuilderForTable('tx_tbsjoboffer_domain_model_joboffer');
        $outdatedJobOffersRecords = $queryBuilder
            ->select('*')
            ->from('tx_tbsjoboffer_domain_model_joboffer')
            ->where('pid = ' . $pageIdExtranetJobOffer . ' AND tstamp < '. $tstampSixWeeksAgo)
            ->execute()
            ->fetchAll();

        return $outdatedJobOffersRecords;
    }

    /**
     * @param string $toDeactivatedJoboffersCsv
     * @return bool
     */
    private function deactivateOutdatedExtranetJobOffers(string $toDeactivatedJoboffersCsv)
    {

        $queryBuilder = GeneralUtility::makeInstance(ConnectionPool::class)
            ->getQueryBuilderForTable('tx_tbsjoboffer_domain_model_joboffer');
        $toDeactivatedJoboffersRecords = $queryBuilder
            ->update('tx_tbsjoboffer_domain_model_joboffer')
            ->set('hidden', 1)
            ->where('uid IN(' . $toDeactivatedJoboffersCsv . ')')
            ->execute();

        return $toDeactivatedJoboffersRecords;
    }
}
