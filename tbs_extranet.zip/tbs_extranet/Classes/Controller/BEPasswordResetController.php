<?php
namespace Tbs\TbsExtranet\Controller;




use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use TYPO3\CMS\Backend\Authentication\PasswordReset;
use TYPO3\CMS\Core\Http\HtmlResponse;
use TYPO3\CMS\Core\Context\Context;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;

/***
 *
 * This file is part of the "TBS Extranet" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <tarang_56@rediffmail.com>,
 *
 ***/

/**
 * BEPasswordResetController
 */
class BEPasswordResetController extends \TYPO3\CMS\Backend\Controller\LoginController
{


    /**
     * Validates the link and show a form to enter the new password.
     *
     * @param ServerRequestInterface $request
     * @return ResponseInterface
     */
    public function passwordResetAction(ServerRequestInterface $request): ResponseInterface
    {

        // Only allow to execute this if not logged in as a user right now
        $context = GeneralUtility::makeInstance(Context::class);
        if ($context->getAspect('backend.user')->isLoggedIn()) {
            return $this->formAction($request);
        }
        $this->init($request);
        $passwordReset = GeneralUtility::makeInstance(PasswordReset::class);
        $this->view->setTemplatePathAndFilename('typo3conf/ext/tbs_extranet/Resources/Private/Templates/Login/ResetPasswordForm.html');
        $this->view->assign('enablePasswordReset', $passwordReset->isEnabled());
        if (!$passwordReset->isValidResetTokenFromRequest($request)) {
            $this->view->assign('invalidToken', true);
        }
        $this->view->assign('token', $request->getQueryParams()['t'] ?? '');
        $this->view->assign('identity', $request->getQueryParams()['i'] ?? '');
        $this->view->assign('expirationDate', $request->getQueryParams()['e'] ?? '');
        $this->moduleTemplate->setContent($this->view->render());
        return new HtmlResponse($this->moduleTemplate->renderContent());
    }


    /**
     * Updates the password in the database.
     *
     * @param ServerRequestInterface $request
     * @return ResponseInterface
     */
    public function passwordResetFinishAction(ServerRequestInterface $request): ResponseInterface
    {

        $translate = GeneralUtility::makeInstance(LocalizationUtility::class);
        $newPassword = (string)$request->getParsedBody()['password'];

        // Only allow to execute this if not logged in as a user right now
        $context = GeneralUtility::makeInstance(Context::class);
        if ($context->getAspect('backend.user')->isLoggedIn()) {
            return $this->formAction($request);
        }
        $passwordReset = GeneralUtility::makeInstance(PasswordReset::class);
        // Token is invalid
        if ($request->getMethod() !== 'POST' || !$passwordReset->isValidResetTokenFromRequest($request)) {
            return $this->passwordResetAction($request);
        }
        $this->init($request);
        $this->view->setTemplatePathAndFilename('typo3conf/ext/tbs_extranet/Resources/Private/Templates/Login/ResetPasswordForm.html');
        $this->view->assign('enablePasswordReset', $passwordReset->isEnabled());
        $this->view->assign('token', $request->getQueryParams()['t'] ?? '');
        $this->view->assign('identity', $request->getQueryParams()['i'] ?? '');
        $this->view->assign('expirationDate', $request->getQueryParams()['e'] ?? '');

        if ($passwordReset->resetPassword($request, $context)) {
            $this->view->assign('resetExecuted', true);
        } else {
            $this->view->assign('error', true);
        }

        $this->moduleTemplate->setContent($this->view->render());
        return new HtmlResponse($this->moduleTemplate->renderContent());
    }



}
