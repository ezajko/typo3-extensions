<?php
namespace Tbs\TbsExtranet\Controller;



use Psr\Http\Message\ServerRequestInterface;
use TYPO3\CMS\Core\Mail\FluidEmail;
use TYPO3\CMS\Core\Mail\Mailer;
use TYPO3\CMS\Extbase\Annotation\Inject;
use TYPO3\CMS\Core\Context\Context;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;
use TYPO3\CMS\Core\Crypto\PasswordHashing\PasswordHashFactory;
use TYPO3\CMS\Core\Configuration\ExtensionConfiguration;
use TYPO3\CMS\Extbase\Utility\LocalizationUtility;
use Tbs\TbsProvider\Service\PrivacyPolicyService;

/***
 *
 * This file is part of the "TBS Extranet" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <tarang_56@rediffmail.com>,
 *
 ***/

/**
 * RegistrationController
 */
class RegistrationController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{

    /**
     * backendUserRepository
     *
     * @var \Tbs\TbsExtranet\Domain\Repository\BackendUserRepository
     * @inject
     */
    protected $backendUserRepository = null;


    /**
     * action form
     *
     * @return void
     */
    public function formAction()
    {

        $request = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('tx_tbsextranet_tbsextranet');
        $checkfield = $request['checkfield'];
        $newBackendUser = $request['newBackendUser'];
        // --- Check Fields (mandatory, email, ...) ---
        if (isset ($checkfield) && !empty($checkfield))
        {
            $result = $this->checkFormFields($checkfield, $newBackendUser);
            $check_form = $result['check_form'];
            $error = $result['error'];
        }

        // --- get all DATA ---
        $cObj = $this->configurationManager->getContentObject()->data;
        $this->view->assign('header', $cObj['header']);
        $this->view->assignMultiple(array(
            'error' => $error
        ));

    }



    /**
     * action register
     * @param \Tbs\TbsExtranet\Domain\Model\BackendUser $newBackendUser
     * @param array $checkfield
     * @return void
     */
    public function registerAction($newBackendUser, $checkfield = null)
    {
        $sentTemplateEmailExtranet = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('Tbs\\TbsExtranet\\Service\\SentTemplateEmailExtranet');
        $translate = GeneralUtility::makeInstance(LocalizationUtility::class);
        $check_form = true;

        $request = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('tx_tbsextranet_tbsextranet');
        $checkfield = $request['checkfield'];
        $data = $request['newBackendUser'];

        // --- Check Fields (mandatory, email, ...) ---
        if (isset ($checkfield) && !empty($checkfield))
        {
            $result = $this->checkFormFields($checkfield, $data);
            $check_form = $result['check_form'];
            $error = $result['error'];
        }

        // --- Check mandatory fields ---
        if ($check_form)
        {
            // --- Check Username & Email address exists ---
            $tbs_registration_user_result = $this->backendUserRepository->equalUserName($data['userName']);
            $tbs_registration_email_result = $this->backendUserRepository->equalEmail($data['email']);

            if((count($tbs_registration_user_result) < 1) && (count($tbs_registration_email_result) < 1))
            {
                $isUserFlag = 1;
                $lang = 'de';
                $backendConfiguration = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(ExtensionConfiguration::class)->get('tbs_extranet');

                //hash password
                $hashInstance = GeneralUtility::makeInstance(PasswordHashFactory::class)->getDefaultHashInstance('BE');
                $hashedPassword = $hashInstance->getHashedPassword($newBackendUser->getPassword());

                $newBackendUser->setLang($lang);
                $newBackendUser->setPassword($hashedPassword);
                $newBackendUser->setUserName($newBackendUser->getUserName());
                $newBackendUser->setIsDisabled($backendConfiguration['IsDisabled']);
                $newBackendUser->setBackendUserGroups($backendConfiguration['setUserGroup']);
                $newBackendUser->setWorkspacePermission($backendConfiguration['WorkspacePermission']);
                $newBackendUser->setOptions(3);
                $newBackendUser->setIsUserFlag($isUserFlag);
                $newBackendUser->setWorkspaceId($backendConfiguration['WorkspaceId']);

                $this->backendUserRepository->add($newBackendUser);
                $persistenceManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\CMS\Extbase\Persistence\Generic\PersistenceManager');
                $persistenceManager->persistAll();


                // --- Save the registration in Privacy Policy ---
                $this->saveRegistrationForPrivacy($newBackendUser);

                // --- set recipient ---
                $senderName = \TYPO3\CMS\Core\Utility\MailUtility::getSystemFromName();
                $senderEmail = \TYPO3\CMS\Core\Utility\MailUtility::getSystemFromAddress();
                $recipient = array(
                    'email' => $backendConfiguration['setSenderEmail'],
                    'name' => $backendConfiguration['setSenderName']
                );
                $sender = array(
                    'email' => $senderEmail,
                    'name' => $senderName
                );

                $variables = array(
                    'extension' => 'extranet'
                );

                $subject = $translate::translate('NotifyAdminConfirmation', 'tbs_extranet');
                $templateName = 'Extranet/NotifyAdminConfirmation';

                $sentTemplateEmailExtranet->sentTemplateEmailExtranet($recipient, $sender, $subject, $templateName, $newBackendUser, $variables);

            }else{

                if(count($tbs_registration_user_result) > 0 || count($tbs_registration_email_result) > 0)
                {
                    $error['messages'][] = $translate::translate('error_creation_failed', 'tbs_extranet');
                }

                $this->view->assignMultiple(array(
                    'registration' => $newBackendUser,
                    'error' => $error
                ));
                $this->view->setTemplatePathAndFilename('typo3conf/ext/tbs_extranet/Resources/Private/Templates/Registration/Form.html');
            }
        }else{

            $this->view->assignMultiple(array(
                'registration' => $newBackendUser,
                'error' => $error
            ));
            $this->view->setTemplatePathAndFilename('typo3conf/ext/tbs_extranet/Resources/Private/Templates/Registration/Form.html');
        }

        // --- get all DATA ---
        $cObj = $this->configurationManager->getContentObject()->data;
        $this->view->assign('header', $cObj['header']);
    }


    protected function checkFormFields($checkfield, $object)
    {
        $translate = GeneralUtility::makeInstance(LocalizationUtility::class);
        $result['check_form'] = true;
        $creation_failed = false; // set to true, of email or user is not unique
        // --- Loop all check fields ---
        foreach ($checkfield AS $key => $value)
        {
            $check = true;
            $check_array = explode(',', $value);
            foreach ($check_array AS $check_type)
            {
                $field_value = $object[$key];

                if ($check_type == 'mandatory')
                {
                    if ($field_value == '' || $field_value == '0')
                    {
                        $result['check_form'] = false;
                        $result['error'][$key] = 'error';
                        $result['error']['messages'][] = $translate::translate('error_' . $key . '_empty', 'tbs_extranet');

                        $check = false;
                    }
                }
                if ($check_type == 'email' && $check)
                {
                    if (!filter_var($field_value, FILTER_VALIDATE_EMAIL))
                    {
                        $result['check_form'] = false;
                        $result['error'][$key] = 'error';
                        $result['error']['messages'][] = $translate::translate('error_' . $key . '_wrong', 'tbs_extranet');
                    }
                }

                /**
                 * $creation_failed is set to true, when the email or username is already used.
                 * Error messages is added after the for-loop to show error message only once.
                 */
                if ($check_type == 'emailexists' && $check)
                {
                    $tbs_registration_email_result = $this->backendUserRepository->equalEmail($object['email']);
                    if(count($tbs_registration_email_result) > 0)
                    {
                        $result['check_form'] = false;
                        $creation_failed = true;
                    }
                }

                if ($check_type == 'usernameexists' && $check && !$creation_failed)
                {
                    $tbs_registration_user_result = $this->backendUserRepository->equalUserName($object['userName']);
                    if(count($tbs_registration_user_result) > 0)
                    {
                        $result['check_form'] = false;
                        $creation_failed = true;
                    }
                }

                if ($check_type == 'password' && $check)
                {
                    if (strlen($field_value) < 8 || strlen($field_value) > 40)
                    {
                        $result['check_form'] = false;
                        $result['error'][$key] = 'error';
                        $result['error']['messages'][] = $translate::translate('error_' . $key . '_length', 'tbs_extranet');
                    }
                    if(!preg_match("#[0-9]+#",$field_value) || !preg_match("#[A-Z]+#",$field_value)
                     || !preg_match("#[a-z]+#",$field_value) || !preg_match("#[\W]+#",$field_value)) {
                        $result['check_form'] = false;
                        $result['error'][$key] = 'error';
                        $result['error']['messages'][] = $translate::translate('error_' . $key . '_validation', 'tbs_extranet');
                    }
                }
                if ($check_type == 'passwordRepeat' && $check)
                {
                    $field_password_value = $object['password'];

                    if ($field_value != $field_password_value)
                    {
                        $result['check_form'] = false;
                        $result['error'][$key] = 'error';
                        $result['error']['messages'][] = $translate::translate('error_' . $key . '_wrong', 'tbs_extranet');
                    }
                }
            }
        }

        /**
         * $creation_failed is set to true, when the email or username is already used.
         * The message will only appear once.
         */
        if ($creation_failed)
        {
            $result['check_form'] = false;
            $result['error']['creation'] = 'error';
            $result['error']['messages'][] = $translate::translate('error_creation_failed', 'tbs_extranet');
        }

        return $result;
    }

    /**
     * saveRegistrationForPrivacy
     * This function will save the data inside in Privacy Table
     * related to Service PrivacyPolicyService
     */
    public function saveRegistrationForPrivacy($newBackendUser)
    {
        $save = false;
        $url = $this->uriBuilder->getRequest()->getRequestUri() ?? null ;
        //-- get the user - Extension - Plugin
        $data = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('tx_tbsextranet_tbsextranet');
        $email= $newBackendUser->getEmail() ?? null;
        $privacyPolicyService = GeneralUtility::makeInstance(PrivacyPolicyService::class);
        if(!empty($privacyPolicyService)){
            $privacyPolicyService->setPrivacyPolicyProperties($data,$url,$email,'tbs_extranet');
            $save = true;
        }
        return $save;
    }
}
