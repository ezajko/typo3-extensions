<?php

namespace Tbs\TbsExtranet\Service;


use TYPO3\CMS\Core\Resource\Exception\ExistingTargetFolderException;
use TYPO3\CMS\Core\Resource\Exception\InsufficientFolderAccessPermissionsException;
use TYPO3\CMS\Core\Resource\Exception\InsufficientFolderWritePermissionsException;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Object\ObjectManager;


class CreateUserHomeStorage implements \TYPO3\CMS\Core\SingletonInterface{


    /**
     * userHomeRoot
     * @var string
     */
    protected $userHomeRoot;



    public function __construct(){

        $this->objectManager = GeneralUtility::makeInstance(ObjectManager::class);
        $this->storageRepository = $this->objectManager->get(\TYPO3\CMS\Core\Resource\StorageRepository::class);
        /*
         * in $GLOBALS['TYPO3_CONF_VARS']['BE']['userHomePath'] is storageId and user home path stored 2:user_home/
         */
       $this->userHomeRoot = substr(strrchr($GLOBALS['TYPO3_CONF_VARS']['BE']['userHomePath'], ":"), 1);
    }


    /**
     * create user storage folder
     * @param $storageUid
     * @param $backendUserId
     * @throws ExistingTargetFolderException
     * @throws InsufficientFolderAccessPermissionsException
     * @throws InsufficientFolderWritePermissionsException
     */
    public function createUserStorageFolder($storageUid, $backendUserId)
    {
        if(!empty($storageUid) && !empty($backendUserId)){

            // get the storage Object
            $storageObj = $this->storageRepository->findByUid($storageUid);

            // get the user home root as folder object
            $userFolderRootObj = $storageObj->getFolder($this->userHomeRoot);

            // create a folder (uid of backend user) in the user home root
            $storageObj->createFolder($backendUserId, $userFolderRootObj);
        }
    }
}
