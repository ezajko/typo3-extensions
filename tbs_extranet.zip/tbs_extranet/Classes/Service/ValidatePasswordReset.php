<?php
namespace Tbs\TbsExtranet\Service;





use Psr\Http\Message\ServerRequestInterface;
use Symfony\Component\Mime\Address;
use TYPO3\CMS\Core\Database\ConnectionPool;
use TYPO3\CMS\Core\Context\Context;
use TYPO3\CMS\Core\Http\NormalizedParams;
use TYPO3\CMS\Core\Mail\FluidEmail;
use TYPO3\CMS\Core\Mail\Mailer;
use TYPO3\CMS\Core\SysLog\Action\Login as SystemLogLoginAction;
use TYPO3\CMS\Core\SysLog\Error as SystemLogErrorClassification;
use TYPO3\CMS\Core\Utility\GeneralUtility;
use TYPO3\CMS\Extbase\Utility\DebuggerUtility;

/***
 *
 * This file is part of the "TBS Extranet" Extension for TYPO3 CMS.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 *  (c) 2020 Tarang Patel <tarang_56@rediffmail.com>,
 *
 ***/

/**
 * ValidatePasswordReset
 */
class ValidatePasswordReset extends \TYPO3\CMS\Backend\Authentication\PasswordReset
{


    /**
     * Update the password in the database if the password matches and the token is valid.
     *
     * @param ServerRequestInterface $request
     * @param Context $context current context
     * @return bool whether the password was reset or not
     */
    public function resetPassword(ServerRequestInterface $request, Context $context): bool
    {
        $expirationTimestamp = (int)($request->getQueryParams()['e'] ?? '');
        $identityHash = (string)($request->getQueryParams()['i'] ?? '');
        $token = (string)($request->getQueryParams()['t'] ?? '');
        $newPassword = (string)$request->getParsedBody()['password'];

        $newPasswordRepeat = (string)$request->getParsedBody()['passwordrepeat'];
        if (strlen($newPassword) < 8 || $newPassword !== $newPasswordRepeat) {
            $this->logger->debug('Password reset not possible due to weak password');
            return false;
        }
        elseif(!preg_match("#[0-9]+#",$newPassword)) {
            return false;
        }
        elseif(!preg_match("#[A-Z]+#",$newPassword)) {
            return false;
        }
        elseif(!preg_match("#[a-z]+#",$newPassword)) {
            return false;
        }
        elseif(!preg_match("#[\W]+#",$newPassword)) {
            return false;
        }

        $user = $this->findValidUserForToken($token, $identityHash, $expirationTimestamp);
        if ($user === null) {
            $this->logger->warning('Password reset not possible. Valid user for token not found.');
            return false;
        }
        $userId = (int)$user['uid'];

        GeneralUtility::makeInstance(ConnectionPool::class)
            ->getConnectionForTable('be_users')
            ->update('be_users', ['password_reset_token' => '', 'password' => $this->getHasher()->getHashedPassword($newPassword)], ['uid' => $userId]);

        $this->logger->info('Password reset successful for user ' . $userId);
        $this->log(
            'Password reset successful for user %s',
            SystemLogLoginAction::PASSWORD_RESET_ACCOMPLISHED,
            SystemLogErrorClassification::SECURITY_NOTICE,
            $userId,
            [
                'email' => $user['email'],
                'user' => $userId
            ],
            NormalizedParams::createFromRequest($request)->getRemoteAddress(),
            $context
        );
        return true;
    }

    /**
     * Determine the right user and send out an email. If multiple users are found with the same email address
     * an alternative email is sent.
     *
     * If no user is found, this is logged to the system (but not to sys_log).
     *
     * The method intentionally does not return anything to avoid any information disclosure or exposure.
     *
     * @param ServerRequestInterface $request
     * @param Context $context
     * @param string $emailAddress
     */
    public function initiateReset(ServerRequestInterface $request, Context $context, string $emailAddress): void
    {

        if (!GeneralUtility::validEmail($emailAddress)) {
            return;
        }
        if ($this->hasExceededMaximumAttemptsForReset($context, $emailAddress)) {
            $this->logger->alert('Password reset requested for email "' . $emailAddress . '" . but was requested too many times.');
            return;
        }
        $queryBuilder = $this->getPreparedQueryBuilder();
        $users = $queryBuilder
            ->select('uid', 'email', 'username', 'realName', 'uc', 'lang')
            ->from('be_users')
            ->andWhere(
                $queryBuilder->expr()->eq('email', $queryBuilder->createNamedParameter($emailAddress))
            )
            ->execute()
            ->fetchAll();
        if (!is_array($users) || count($users) === 0) {
            // No user found, do nothing, also no log to sys_log in order avoid log flooding
            $this->logger->warning('Password reset requested for email but no valid users');
        } elseif (count($users) > 1) {
            // More than one user with the same email address found, send out the email that one cannot send out a reset link
            $this->sendAmbiguousEmail($request, $context, $emailAddress);
        } else {
            $user = reset($users);
            $this->sendResetEmail($request, $context, (array)$user, $emailAddress);
        }
    }

    /**
     * Send out an email to a user that does have an email address added to his account, containing a reset link.
     *
     * @param ServerRequestInterface $request
     * @param Context $context
     * @param array $user
     * @param string $emailAddress
     */
    protected function sendResetEmail(ServerRequestInterface $request, Context $context, array $user, string $emailAddress): void
    {

        $uc = unserialize($user['uc'] ?? '', ['allowed_classes' => false]);
        $resetLink = $this->generateResetLinkForUser($context, (int)$user['uid'], (string)$user['email']);
        $emailObject = GeneralUtility::makeInstance(FluidEmail::class);
        $emailObject
            ->to(new Address((string)$user['email'], $user['realName']))
            ->setRequest($request)
            ->assign('name', $user['realName'])
            ->assign('email', $user['email'])
            ->assign('language', $uc['lang'] ?? $user['lang'] ?: 'default')
            ->assign('resetLink', $resetLink)
            ->setTemplate('PasswordReset/ResetRequested');

        /** embed logo inside of e-mail as cid image */
        $emailObject->embedFromPath($_SERVER["DOCUMENT_ROOT"] . '/typo3conf/ext/tbs_provider/Resources/Public/Icons/bkk-logo.png', 'logo-bkk-dv');

        GeneralUtility::makeInstance(Mailer::class)->send($emailObject);
        $this->logger->info('Sent password reset email to email address ' . $emailAddress . ' for user ' . $user['username']);
        $this->log(
            'Sent password reset email to email address %s',
            SystemLogLoginAction::PASSWORD_RESET_REQUEST,
            SystemLogErrorClassification::SECURITY_NOTICE,
            (int)$user['uid'],
            [
                'email' => $user['email']
            ],
            NormalizedParams::createFromRequest($request)->getRemoteAddress(),
            $context
        );
    }
}
