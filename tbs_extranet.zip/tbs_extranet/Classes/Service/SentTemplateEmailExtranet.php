<?php

namespace Tbs\TbsExtranet\Service;



use Psr\Http\Message\ServerRequestInterface;
use Symfony\Component\Mime\Address;
use TYPO3\CMS\Core\Mail\FluidEmail;
use TYPO3\CMS\Core\Mail\Mailer;
use TYPO3\CMS\Core\Utility\GeneralUtility;


class SentTemplateEmailExtranet implements \TYPO3\CMS\Core\SingletonInterface{


    /**
     * Send Email for Extranet.
     *
     * @param array $recipient
     * @param array $sender
     * @param string $subject
     * @param string $templateName
     * @param array $data
     * @param array $variables
     */
    public function sentTemplateEmailExtranet($recipient, $sender, $subject, $templateName, $data, $variables = null)
    {
        $email = GeneralUtility::makeInstance(FluidEmail::class)
            ->from(new Address($sender['email'], $sender['name']))
            ->to(new Address($recipient['email'], $recipient['name']))
            ->subject($subject)
            ->setTemplate($templateName)
            ->assign('user', $data)
            ->assign('obj', $variables);

        /** embed logo inside of e-mail as cid image */
        $email->embedFromPath($_SERVER["DOCUMENT_ROOT"] . '/typo3conf/ext/tbs_provider/Resources/Public/Icons/bkk-logo.png', 'logo-bkk-dv');

        if ($GLOBALS['TYPO3_REQUEST'] instanceof ServerRequestInterface) {
            $email->setRequest($GLOBALS['TYPO3_REQUEST']);
        }

        /** @var  $mailer Mailer */
        $mailer = GeneralUtility::makeInstance(Mailer::class);
        $mailer->send($email);
        return $mailer->getSentMessage();
    }

}
