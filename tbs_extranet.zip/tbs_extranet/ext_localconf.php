<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function()
    {
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
            'Tbs.TbsExtranet',
            'Tbsextranet',
            [
                'Registration' => 'form, register',
            ],
            // non-cacheable actions
            [
                'Registration' => 'form, register',
            ]
        );



        // wizards
        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addPageTSConfig(
            'mod {
            wizards.newContentElement.wizardItems.plugins {
                elements {    
                    tbsextranet {
                        iconIdentifier = tbs_extranet-plugin-tbsextranet
                        title = LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:tx_tbsextranet.title
                        description = LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:tx_tbsextranet.descriptions
                        tt_content_defValues {
                            CType = list
                            list_type = tbsextranet_tbsextranet
                        }
                    }
                    
                }
                show = *
            }
       }'
        );
        $iconRegistry = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\TYPO3\CMS\Core\Imaging\IconRegistry::class);

        $iconRegistry->registerIcon(
            'tbs_extranet-plugin-tbsextranet',
            \TYPO3\CMS\Core\Imaging\IconProvider\SvgIconProvider::class,
            ['source' => 'EXT:tbs_extranet/Resources/Public/Icons/Extension.svg']
        );

        // Register Hook for tracking apply of data privacy and error msg if accept data privacy is not checked
        $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['t3lib/class.t3lib_tcemain.php']['processDatamapClass']['tbs_extranet'] = Tbs\TbsExtranet\Hooks\UserSettingsHook::class;
        $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['t3lib/class.t3lib_tcemain.php']['processCmdmapClass']['tbs_extranet'] = Tbs\TbsExtranet\Hooks\UserSettingsHook::class;

        // Register Scheduler set hidden flag for JobOffers after 6 weeks of no changes and delete it after 24 months
        $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Tbs\TbsExtranet\Scheduler\DeactivateOutdatedExtranetJobOffers'] = array(
            'extension' => 'tbs_extranet',
            'title' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:scheduler.deactivate_outdated_job_offers.title',
            'description' =>
                'LLL:EXT:extbase/Resources/Private/Language/locallang_db.xlf:scheduler.deactivate_outdated_job_offers.description',
        );

        // Register Scheduler delete outdated JobOffers which are older than 24 months
        $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Tbs\TbsExtranet\Scheduler\DeleteOutdatedExtranetJobOffers'] = array(
            'extension' => 'tbs_extranet',
            'title' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:scheduler.delete_outdated_job_offers.title',
            'description' =>
                'LLL:EXT:extbase/Resources/Private/Language/locallang_db.xlf:scheduler.delete_outdated_job_offers.description',
        );

        // Register Scheduler Task for extranet users. If the confirmation link is not confirmed within five working days, the registration will be automatically deleted.
        $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Tbs\TbsExtranet\Scheduler\ExtranetRegistrationConfirmationDeleteRecords'] = array(
            'extension' => 'tbs_extranet',
            'title' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:scheduler.registration.confirmation.delete.records.title',
            'description' =>
                'LLL:EXT:extbase/Resources/Private/Language/locallang_db.xlf:scheduler.registration.confirmation.delete.records',
        );

        // Register Scheduler Task for extranet users inactive for eleven months (= no login) automatic notification by email.
        $GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['scheduler']['tasks']['Tbs\TbsExtranet\Scheduler\ExtranetUsersInactiveForElevenAndTwelveMonths'] = array(
            'extension' => 'tbs_extranet',
            'title' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:scheduler.extranet.users.inactive.title',
            'description' =>
                'LLL:EXT:extbase/Resources/Private/Language/locallang_db.xlf:scheduler.registration.confirmation.delete.records',
        );

        // XCLASS - add secure password instructions in ResetPasswordForm
        $GLOBALS['TYPO3_CONF_VARS']['SYS']['Objects']['TYPO3\\CMS\\Backend\\Controller\\LoginController'] = [
            'className' => 'Tbs\\TbsExtranet\\Controller\\BEPasswordResetController'
        ];

        // XCLASS - Extranet users secure password validation
        $GLOBALS['TYPO3_CONF_VARS']['SYS']['Objects']['TYPO3\\CMS\\Backend\\Authentication\\PasswordReset'] = [
            'className' => 'Tbs\\TbsExtranet\\Service\\ValidatePasswordReset'
        ];

    }
);


// Register for hook to show preview of tt_content element of CType="tbsextranet_tbsextranet" in page module
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['cms/layout/class.tx_cms_layout.php']['tt_content_drawItem']['tbsextranet_tbsextranet'] =
    \Tbs\TbsExtranet\Hooks\PageLayoutView\ExtranetPreviewRenderer::class;

// Register for Hook to show only records of the logged in Extranet user
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['typo3/class.db_list_extra.inc']['getTable']['tbs_extranet'] =
    \Tbs\TbsExtranet\Hooks\RecordListView\ExtranetJobOfferRecordListRenderer::class;


$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['typo3/class.db_list_extra.inc']['actions']['tbs_extranet']  =
    \Tbs\TbsExtranet\Hooks\RecordListView\ExtranetJobOfferRecordListPreviewLinkRenderer::class;

/***************
 * UserTS
 */
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addUserTSConfig('<INCLUDE_TYPOSCRIPT: source="FILE:EXT:tbs_extranet/Configuration/TsConfig/User.tsconfig">');

// register SaveHook
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['t3lib/class.t3lib_tcemain.php']['processDatamapClass'][] =  \Tbs\TbsExtranet\Hooks\RecordListView\ExtranetUsersNotificationEmailAndUserStorage::class;
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['t3lib/class.t3lib_tcemain.php']['processCmdmapClass'][] =  \Tbs\TbsExtranet\Hooks\RecordListView\ExtranetUsersNotificationEmailAndUserStorage::class;

