<?php
defined('TYPO3_MODE') || die('Access denied.');

call_user_func(
    function($extKey)
    {

        \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile('tbs_extranet', 'Configuration/TypoScript', 'TBS Extranet');

        ## Extranet frontend plugin
        \TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
            'Tbs.TbsExtranet',
            'Tbsextranet',
            'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:tx_tbsextranet.title'
        );


    },
    'tbs_extranet'
);

// Extending the User Settings for extranet registration user
$GLOBALS['TYPO3_USER_SETTINGS']['columns']['tx_tbs_extranet_first_name'] = array(
    'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_first_name',
    'type' => 'text',
    'eval' => 'required',
    'table' => 'be_users',
);

$GLOBALS['TYPO3_USER_SETTINGS']['columns']['tx_tbs_extranet_last_name'] = array(
    'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_last_name',
    'type' => 'text',
    'table' => 'be_users',
);

$GLOBALS['TYPO3_USER_SETTINGS']['columns']['tx_tbs_extranet_position'] = array(
    'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_position',
    'type' => 'text',
    'table' => 'be_users',
);

$GLOBALS['TYPO3_USER_SETTINGS']['columns']['tx_tbs_extranet_company'] = array(
    'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_company',
    'type' => 'text',
    'table' => 'be_users',
);

$GLOBALS['TYPO3_USER_SETTINGS']['columns']['tx_tbs_extranet_street'] = array(
    'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_street',
    'type' => 'text',
    'table' => 'be_users',
);

$GLOBALS['TYPO3_USER_SETTINGS']['columns']['tx_tbs_extranet_zipcode'] = array(
    'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_zipcode',
    'type' => 'text',
    'table' => 'be_users',
);

$GLOBALS['TYPO3_USER_SETTINGS']['columns']['tx_tbs_extranet_city'] = array(
    'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_city',
    'type' => 'text',
    'table' => 'be_users',
);

$GLOBALS['TYPO3_USER_SETTINGS']['columns']['tx_tbs_extranet_telephone'] = array(
    'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_telephone',
    'type' => 'text',
    'table' => 'be_users',
);


$GLOBALS['TYPO3_USER_SETTINGS']['columns']['tx_tbs_extranet_privacy'] = array(
    'label' => "LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_privacy" ,
    'type' => 'check',
    'table' => 'be_users',
    'required' => true
);


\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addFieldsToUserSettings('tx_tbs_extranet_first_name,tx_tbs_extranet_last_name', 'before:realName');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addFieldsToUserSettings('tx_tbs_extranet_position', 'after:realName');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addFieldsToUserSettings('tx_tbs_extranet_company,tx_tbs_extranet_street,tx_tbs_extranet_zipcode,tx_tbs_extranet_city,tx_tbs_extranet_telephone,tx_tbs_extranet_privacy', 'after:email');