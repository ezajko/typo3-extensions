<?php

declare(strict_types=1);

return [
    \Tbs\TbsExtranet\Domain\Model\BackendUser::class => [
        'tableName' => 'be_users',
        'properties' => [
            'firstName' => [
                'fieldName' => 'tx_tbs_extranet_first_name'
            ],
            'lastName' => [
                'fieldName' => 'tx_tbs_extranet_last_name'
            ],
            'position' => [
                'fieldName' => 'tx_tbs_extranet_position'
            ],
            'company' => [
                'fieldName' => 'tx_tbs_extranet_company'
            ],
            'street' => [
                'fieldName' => 'tx_tbs_extranet_street'
            ],
            'zip' =>[
                'fieldName' => 'tx_tbs_extranet_zipcode'
            ],
            'city' =>[
                'fieldName' => 'tx_tbs_extranet_city'
            ],
            'phone' =>[
                'fieldName' => 'tx_tbs_extranet_telephone'
            ],
            'dataPrivacy' =>[
                'fieldName' => 'tx_tbs_extranet_privacy'
            ],
            'options' =>[
                'fieldName' => 'options'
            ],
            'workspaceId' =>[
                'fieldName' => 'workspace_id'
            ],
            'backendUserGroups' =>[
                'fieldName' => 'usergroup'
            ],
            'workspacePermission' =>[
                'fieldName' => 'workspace_perms'
            ],
            'isUserFlag' => [
                'fieldName' => 'tx_tbs_extranet_user_flag'
            ],
            'isUserActiveNotificationFlag' => [
                'fieldName' => 'tx_tbs_extranet_user_activate_notifiaction_flag'
            ],
            'lang' => [
                'fieldName' => 'lang'
            ],
        ],
    ],
];
