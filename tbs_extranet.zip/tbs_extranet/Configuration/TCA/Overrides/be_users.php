<?php

defined('TYPO3_MODE') or die();

$tempColumnsBackend = array(
    'tx_tbs_extranet_first_name' => array(
        'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_first_name',
        'config' => array(
            'type' => 'input',
            'size' => 20,
            'eval' => 'required'
        )
    ),
    'tx_tbs_extranet_last_name' => array(
        'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_last_name',
        'config' => array(
            'type' => 'input',
            'size' => 20
        )
    ),
    'tx_tbs_extranet_position' => array(
        'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_position',
        'config' => array(
            'type' => 'input',
            'size' => 20
        )
    ),
    'tx_tbs_extranet_company' => array(
        'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_company',
        'config' => array(
            'type' => 'input',
            'size' => 20
        )
    ),
    'tx_tbs_extranet_street' => array(
        'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_street',
        'config' => array(
            'type' => 'input',
            'size' => 20
        )
    ),
    'tx_tbs_extranet_zipcode' => array(
        'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_zipcode',
        'config' => array(
            'type' => 'input',
            'size' => 20
        )
    ),
    'tx_tbs_extranet_city' => array(
        'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_city',
        'config' => array(
            'type' => 'input',
            'size' => 20
        )
    ),
    'tx_tbs_extranet_telephone' => array(
        'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_telephone',
        'config' => array(
            'type' => 'input',
            'size' => 20
        )
    ),
    'tx_tbs_extranet_privacy' => array(
        'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_privacy',
        'config' => array(
            'type' => 'check',
            'eval' => 'required',
            'required' => true,
        )
    ),
    'tx_tbs_extranet_user_flag' => array(
        'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_user_flag',
        'config' => array(
            'type' => 'check',

        )
    ),
    'tx_tbs_extranet_user_activate_notifiaction_flag' => array(
        'label' => 'LLL:EXT:tbs_extranet/Resources/Private/Language/locallang_db.xlf:be_users.tx_tbs_extranet_user_activate_notifiaction_flag',
        'config' => array(
            'type' => 'check',

        )
    ),
);

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addTCAcolumns('be_users', $tempColumnsBackend, TRUE);
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes('be_users', 'tx_tbs_extranet_first_name,tx_tbs_extranet_last_name', '', 'after:usergroup');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes('be_users', 'tx_tbs_extranet_position', '', 'after:realName');
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addToAllTCAtypes('be_users', 'tx_tbs_extranet_company,tx_tbs_extranet_street,tx_tbs_extranet_zipcode,tx_tbs_extranet_city,tx_tbs_extranet_telephone,tx_tbs_extranet_privacy', '', 'after:email');


