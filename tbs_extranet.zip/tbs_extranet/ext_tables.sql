#
# Table structure for table 'be_users'
#
CREATE TABLE be_users (
    tx_tbs_extranet_first_name varchar(255) DEFAULT '' NOT NULL,
    tx_tbs_extranet_last_name varchar(255) DEFAULT '' NOT NULL,
    tx_tbs_extranet_position varchar(255) DEFAULT '' NOT NULL,
	tx_tbs_extranet_company varchar(255) DEFAULT '' NOT NULL,
	tx_tbs_extranet_street varchar(255) DEFAULT '' NOT NULL,
	tx_tbs_extranet_zipcode varchar(255) DEFAULT '' NOT NULL,
	tx_tbs_extranet_city varchar(255) DEFAULT '' NOT NULL,
	tx_tbs_extranet_telephone varchar(255) DEFAULT '' NOT NULL,
	tx_tbs_extranet_privacy varchar(255) DEFAULT '' NOT NULL,
	tx_tbs_extranet_user_flag tinyint(4) unsigned DEFAULT '0' NOT NULL,
	tx_tbs_extranet_user_activate_notifiaction_flag tinyint(4) unsigned DEFAULT '0' NOT NULL,
);
